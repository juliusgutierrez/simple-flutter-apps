package ph.com.sunlife.wms.dto;

import java.util.List;
import java.util.Vector;

public class PSReportColumnMapDTO implements DataAccessInterface{

	private List ObjectList = new Vector();
	private String REPORT_ID;
	private String COLUMN_NAME;
	private String PRCV_COL_NAME;
	private String FNCE_PROPERTY_NAME;
	private String FNPE_PROPERTY_NAME;
	private Integer OFFSET;
	private Integer LENGTH;

	public void add(DataAccessInterface dataAccessInterface) {
	}

	public void add(PSReportColumnMapDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}

	public String getCOLUMN_NAME() {
		return COLUMN_NAME;
	}

	public void setCOLUMN_NAME(String column_name) {
		COLUMN_NAME = column_name;
	}

	public String getFNCE_PROPERTY_NAME() {
		return FNCE_PROPERTY_NAME;
	}

	public void setFNCE_PROPERTY_NAME(String fnce_property_name) {
		FNCE_PROPERTY_NAME = fnce_property_name;
	}

	public Integer getLENGTH() {
		return LENGTH;
	}

	public void setLENGTH(Integer length) {
		LENGTH = length;
	}

	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}

	public Integer getOFFSET() {
		return OFFSET;
	}

	public void setOFFSET(Integer offset) {
		OFFSET = offset;
	}

	public String getREPORT_ID() {
		return REPORT_ID;
	}

	public void setREPORT_ID(String report_id) {
		REPORT_ID = report_id;
	}

	public String getFNPE_PROPERTY_NAME() {
		return FNPE_PROPERTY_NAME;
	}

	public void setFNPE_PROPERTY_NAME(String fnpe_property_name) {
		FNPE_PROPERTY_NAME = fnpe_property_name;
	}

	public String getPRCV_COL_NAME() {
		return PRCV_COL_NAME;
	}

	public void setPRCV_COL_NAME(String prcv_col_name) {
		PRCV_COL_NAME = prcv_col_name;
	}
	
	
	
}
