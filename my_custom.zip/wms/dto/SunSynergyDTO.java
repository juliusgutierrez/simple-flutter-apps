package ph.com.sunlife.wms.dto;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Vector;

public class SunSynergyDTO implements DataAccessInterface{
	protected String POL_ID;
	protected String LOB_CD;
	protected String POL_CRCY_CD;
	protected Date POL_ISS_EFF_DT;   //Date
	protected String POL_STAT_CD;
	protected String POL_BILL_MODE_CD;
	protected String OWNER_CLIENT_NO;
	protected String OWNER_FIRST_NAME;
	protected String OWNER_MIDDLE_NAME;
	protected String OWNER_LAST_NAME;
	protected Date OWNER_BIRTH_DT;    //Date
	protected String ADDRESS;
	protected String INSURED_CLIENT_NO;
	protected String INSURED_FIRST_NAME;
	protected String INSURED_MIDDLE_NAME;
	protected String INSURED_LAST_NAME;
	protected Date INSURED_BIRTHDATE;    //Date
	protected String AGENT_CODE;
	protected String AGENT_FIRST_NAME;
	protected String AGENT_MIDDLE_NAME;
	protected String AGENT_LAST_NAME;
	protected String AGENT_NBO_CODE;
	protected String BASIC_PLAN_ID;
	protected BigDecimal POL_TPREM_AMT;
	protected BigDecimal CVG_FACE_AMT;
	
	
	protected List<SunSynergyDTO> ObjectList = new Vector<SunSynergyDTO>();
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add((SunSynergyDTO) dataAccessInterface);
	}

	public void add(ILifePlanViewDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}
	
	public void add(PNeedPlanViewDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}

	public String getADDRESS() {
		return ADDRESS;
	}

	public void setADDRESS(String address) {
		ADDRESS = address;
	}

	public String getAGENT_CODE() {
		return AGENT_CODE;
	}

	public void setAGENT_CODE(String agent_code) {
		AGENT_CODE = agent_code;
	}

	public String getAGENT_FIRST_NAME() {
		return AGENT_FIRST_NAME;
	}

	public void setAGENT_FIRST_NAME(String agent_first_name) {
		AGENT_FIRST_NAME = agent_first_name;
	}

	public String getAGENT_LAST_NAME() {
		return AGENT_LAST_NAME;
	}

	public void setAGENT_LAST_NAME(String agent_last_name) {
		AGENT_LAST_NAME = agent_last_name;
	}

	public String getAGENT_MIDDLE_NAME() {
		return AGENT_MIDDLE_NAME;
	}

	public void setAGENT_MIDDLE_NAME(String agent_middle_name) {
		AGENT_MIDDLE_NAME = agent_middle_name;
	}

	public String getAGENT_NBO_CODE() {
		return AGENT_NBO_CODE;
	}

	public void setAGENT_NBO_CODE(String agent_nbo_code) {
		AGENT_NBO_CODE = agent_nbo_code;
	}

	public String getBASIC_PLAN_ID() {
		return BASIC_PLAN_ID;
	}

	public void setBASIC_PLAN_ID(String basic_plan_id) {
		BASIC_PLAN_ID = basic_plan_id;
	}

	public BigDecimal getCVG_FACE_AMT() {
		return CVG_FACE_AMT;
	}

	public void setCVG_FACE_AMT(BigDecimal cvg_face_amt) {
		CVG_FACE_AMT = cvg_face_amt;
	}

	public Date getINSURED_BIRTHDATE() {
		return INSURED_BIRTHDATE;
	}

	public void setINSURED_BIRTHDATE(Date insured_birthdate) {
		INSURED_BIRTHDATE = insured_birthdate;
	}

	public String getINSURED_CLIENT_NO() {
		return INSURED_CLIENT_NO;
	}

	public void setINSURED_CLIENT_NO(String insured_client_no) {
		INSURED_CLIENT_NO = insured_client_no;
	}

	public String getINSURED_FIRST_NAME() {
		return INSURED_FIRST_NAME;
	}

	public void setINSURED_FIRST_NAME(String insured_first_name) {
		INSURED_FIRST_NAME = insured_first_name;
	}

	public String getINSURED_LAST_NAME() {
		return INSURED_LAST_NAME;
	}

	public void setINSURED_LAST_NAME(String insured_last_name) {
		INSURED_LAST_NAME = insured_last_name;
	}

	public String getINSURED_MIDDLE_NAME() {
		return INSURED_MIDDLE_NAME;
	}

	public void setINSURED_MIDDLE_NAME(String insured_middle_name) {
		INSURED_MIDDLE_NAME = insured_middle_name;
	}

	public String getLOB_CD() {
		return LOB_CD;
	}

	public void setLOB_CD(String lob_cd) {
		LOB_CD = lob_cd;
	}

	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}

	public Date getOWNER_BIRTH_DT() {
		return OWNER_BIRTH_DT;
	}

	public void setOWNER_BIRTH_DT(Date owner_birth_dt) {
		OWNER_BIRTH_DT = owner_birth_dt;
	}

	public String getOWNER_CLIENT_NO() {
		return OWNER_CLIENT_NO;
	}

	public void setOWNER_CLIENT_NO(String owner_client_no) {
		OWNER_CLIENT_NO = owner_client_no;
	}

	public String getOWNER_FIRST_NAME() {
		return OWNER_FIRST_NAME;
	}

	public void setOWNER_FIRST_NAME(String owner_first_name) {
		OWNER_FIRST_NAME = owner_first_name;
	}

	public String getOWNER_LAST_NAME() {
		return OWNER_LAST_NAME;
	}

	public void setOWNER_LAST_NAME(String owner_last_name) {
		OWNER_LAST_NAME = owner_last_name;
	}

	public String getOWNER_MIDDLE_NAME() {
		return OWNER_MIDDLE_NAME;
	}

	public void setOWNER_MIDDLE_NAME(String owner_middle_name) {
		OWNER_MIDDLE_NAME = owner_middle_name;
	}

	public String getPOL_BILL_MODE_CD() {
		return POL_BILL_MODE_CD;
	}

	public void setPOL_BILL_MODE_CD(String pol_bill_mode_cd) {
		POL_BILL_MODE_CD = pol_bill_mode_cd;
	}

	public String getPOL_CRCY_CD() {
		return POL_CRCY_CD;
	}

	public void setPOL_CRCY_CD(String pol_crcy_cd) {
		POL_CRCY_CD = pol_crcy_cd;
	}

	public String getPOL_ID() {
		return POL_ID;
	}

	public void setPOL_ID(String pol_id) {
		POL_ID = pol_id;
	}

	public Date getPOL_ISS_EFF_DT() {
		return POL_ISS_EFF_DT;
	}

	public void setPOL_ISS_EFF_DT(Date pol_iss_eff_dt) {
		POL_ISS_EFF_DT = pol_iss_eff_dt;
	}

	public String getPOL_STAT_CD() {
		return POL_STAT_CD;
	}

	public void setPOL_STAT_CD(String pol_stat_cd) {
		POL_STAT_CD = pol_stat_cd;
	}

	public BigDecimal getPOL_TPREM_AMT() {
		return POL_TPREM_AMT;
	}

	public void setPOL_TPREM_AMT(BigDecimal pol_tprem_amt) {
		POL_TPREM_AMT = pol_tprem_amt;
	}
}

