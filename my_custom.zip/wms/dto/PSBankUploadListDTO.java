package ph.com.sunlife.wms.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PSBankUploadListDTO implements DataAccessInterface{

	private List objectList = new ArrayList();
	private String bankShortName;
	private String bankName;
	private Boolean isLife;
	private Boolean isPreneed;
	private Boolean runOnWeekEnds;
	private String createdBy;
	private Date dateCreated;
	private String updatedBy;
	private Date dateModified; 
	private Boolean isActive;
	
	public List getObjectList() {
		return objectList;
	}

	public void setObjectList(List objectList) {
		this.objectList = objectList;
	}

	public String getBankShortName() {
		return bankShortName;
	}

	public void setBankShortName(String bankShortName) {
		this.bankShortName = bankShortName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public Boolean getIsLife() {
		return isLife;
	}

	public void setIsLife(Boolean isLife) {
		this.isLife = isLife;
	}

	public Boolean getIsPreneed() {
		return isPreneed;
	}

	public void setIsPreneed(Boolean isPreneed) {
		this.isPreneed = isPreneed;
	}

	public Boolean getRunOnWeekEnds() {
		return runOnWeekEnds;
	}

	public void setRunOnWeekEnds(Boolean runOnWeekEnds) {
		this.runOnWeekEnds = runOnWeekEnds;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public void add(PSBankUploadListDTO dataAccessInterface) {
		objectList.add(dataAccessInterface);
	}

	public void add(DataAccessInterface dataAccessInterface) {
		objectList.add(dataAccessInterface);
	}

}
