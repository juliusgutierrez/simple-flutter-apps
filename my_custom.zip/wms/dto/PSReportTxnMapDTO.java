package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class PSReportTxnMapDTO implements DataAccessInterface{

	private List ObjectList = new Vector();
	private String REPORT_ID;
	private String REPORT_NAME;
	private String PSTXNTYPE_TRANS_ID;
	private String CREATED_BY;
	private Date DATE_CREATED;
	private String UPDATED_BY;
	private Date DATE_MODIFIED;
	
	public void add(DataAccessInterface dataAccessInterface) {
		// TODO Auto-generated method stub
		
	}

	public void add(PSReportTxnMapDTO dataAccessInterface) {
		// TODO Auto-generated method stub
		ObjectList.add(dataAccessInterface);
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String created_by) {
		CREATED_BY = created_by;
	}

	public Date getDATE_CREATED() {
		return DATE_CREATED;
	}

	public void setDATE_CREATED(Date date_created) {
		DATE_CREATED = date_created;
	}

	public Date getDATE_MODIFIED() {
		return DATE_MODIFIED;
	}

	public void setDATE_MODIFIED(Date date_modified) {
		DATE_MODIFIED = date_modified;
	}

	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}

	public String getPSTXNTYPE_TRANS_ID() {
		return PSTXNTYPE_TRANS_ID;
	}

	public void setPSTXNTYPE_TRANS_ID(String pstxntype_trans_id) {
		PSTXNTYPE_TRANS_ID = pstxntype_trans_id;
	}

	public String getREPORT_ID() {
		return REPORT_ID;
	}

	public void setREPORT_ID(String report_id) {
		REPORT_ID = report_id;
	}

	public String getREPORT_NAME() {
		return REPORT_NAME;
	}

	public void setREPORT_NAME(String report_name) {
		REPORT_NAME = report_name;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String updated_by) {
		UPDATED_BY = updated_by;
	}

}
