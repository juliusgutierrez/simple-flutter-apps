package ph.com.sunlife.wms.dto;

import java.util.List;
import java.util.Vector;

public class PSReportColumnValuesDTO implements DataAccessInterface{

	
	private String APO_AMOUNT_DUE;
	private String APO_EFFECTIVE_DATE;
	private String APO_INST_END_DATE;
	private String BANK_INITIAL;
	private String BILLING_TYPE_CODE;
	private String CASHIER_ID;
	private String CHECK_AMOUNT;
	private String CHECK_ISSUE_DATE;
	private String CHECK_NUMBER;
	private String COMMENTS;
	private String COMPANY_CODE;
	private String CURRENCY_CODE;
	private String DIVIDEND_OPTION;
	private String DUE_DATE;
	private String EFFECTIVE_DATE;
	private String LISTBILL_CLIENT_ID;
	private String MESSAGE_TEXT;
	private String MISCELLANEOUS_SUSPENSE_AMOUNT;
	private String MISCELLANEOUS_SUSPENSE_DATE;
	private String NET_FUND_AMOUNT;
	private String NOTICE_TYPE;
	private String OS_DISBURSEMENT;
	private String OWNER_CLIENT_ID;
	private String OWNER_NAME;
	private String PAID_TO_DATE;
	private String PAYMENT_CODE;
	private String PDF_AMOUNT;
	private String POLICY_ID;
	private String POLICY_INSURANCE_TYPE_CODE;
	private String PREMIUM_AMOUNT;
	private String PREMIUM_DUE_DATE;
	private String PREMIUM_SUSPENSE;
	private String PREMIUM_SUSPENSE_AMOUNT;
	private String REASON;
	private String REPORT_DATE;
	private String REPORT_ID;
	private String REPORT_TYPE_CODE;
	private String RUN_DATE;
	private String SERVICING_AGENT_BRANCH_ID;
	private String SERVICING_AGENT_ID;
	private String SOURCE_SYSTEM;
	private String STATUS_CODE;
	private String SUB_COMPANY_ID;
	private String SUNDRY_AMOUNT;
	private String TRANSACTION_TYPE_CODE;
	private String TRUE_PREMIUM_AMOUNT;
	private String INSURED_CLIENT_ID;
	private String INSURED_CLIENT_NAME;
	private String CREATION_DATE;
	private String DEPOSIT_AMOUNT;
	private String MODE;
	private String DATE_LOGGED;
	private String POLICY_OWNER;
	private String GROUP_NAME;
	private String GROSS_AMT;
	private String SERVFEE_AMT;
	private String VAT_AMT;
	private String TAX_WHELD;
	private String NET_AMT;
	private String ISSUE_DT;
	private String BASE_FACE_AMOUNT;
	private String NFO_CODE;
	private String DOD_AMOUNT;
	private String AE_FUND_AMOUNT;
	private String CUR;
	private String CASE_CV;
	private String PUA_CV;
	private String LOAN_PLUS_INT;
	private String APL_PLUS_INT;
	private String ETI_EXP_DT;
	private String AMOUNT;
	private String BASE_CV;
	private String CSV_FOR_OVERLOAN;
	private String STATUS;
	private String REMARKS;
	private String POLICY_STATUS;
	private String PLAN_ID;
	private String T_BAR;
	private String EFFECTIVE_DATE_TERMINATION;
	private String C_NO;
	private String COV_PROD_CD;
	private String CURR_STAT;
	private String PREV_STAT;
	private String COV_STAT_CHANGE_DATE;
	private String COV_ISS_DT;
	private String COV_MAT_EXP_DT;
	private String COV_DUR;
	private String POLICY_MODAL_PREMIUM;
	private String PTD;
	private String BRANCH_NAME;
	private String COV_NUM;
	private String CASH_VALUE;
	private String ISSUE_EFFECTIVE_DATE;
	private String OS_AMOUNT;
	private String WORKITEM_CREATE_DATE;
	private String BASIC_FACE_AMOUNT;
	private String DISB_DATE;
	private String PROCESS_DATE;
	private String ACF2ID;
	private String ADDR_STAT_CODE;
	private String REINSURED_STAT_CODE;

	private List ObjectList = new Vector();
	
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
		
	}
	
	public void add(PSReportColumnValuesDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
		
	}


	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(Vector objectList) {
		ObjectList = objectList;
	}

	public String getAPO_AMOUNT_DUE() {
		return APO_AMOUNT_DUE;
	}


	public void setAPO_AMOUNT_DUE(String apo_amount_due) {
		APO_AMOUNT_DUE = apo_amount_due;
	}


	public String getAPO_EFFECTIVE_DATE() {
		return APO_EFFECTIVE_DATE;
	}


	public void setAPO_EFFECTIVE_DATE(String apo_effective_date) {
		APO_EFFECTIVE_DATE = apo_effective_date;
	}


	public String getAPO_INST_END_DATE() {
		return APO_INST_END_DATE;
	}


	public void setAPO_INST_END_DATE(String apo_inst_end_date) {
		APO_INST_END_DATE = apo_inst_end_date;
	}


	public String getBANK_INITIAL() {
		return BANK_INITIAL;
	}


	public void setBANK_INITIAL(String bank_initial) {
		BANK_INITIAL = bank_initial;
	}


	public String getBILLING_TYPE_CODE() {
		return BILLING_TYPE_CODE;
	}


	public void setBILLING_TYPE_CODE(String billing_type_code) {
		BILLING_TYPE_CODE = billing_type_code;
	}


	public String getCASHIER_ID() {
		return CASHIER_ID;
	}


	public void setCASHIER_ID(String cashier_id) {
		CASHIER_ID = cashier_id;
	}


	public String getCHECK_AMOUNT() {
		return CHECK_AMOUNT;
	}


	public void setCHECK_AMOUNT(String check_amount) {
		CHECK_AMOUNT = check_amount;
	}


	public String getCHECK_ISSUE_DATE() {
		return CHECK_ISSUE_DATE;
	}


	public void setCHECK_ISSUE_DATE(String check_issue_date) {
		CHECK_ISSUE_DATE = check_issue_date;
	}


	public String getCHECK_NUMBER() {
		return CHECK_NUMBER;
	}


	public void setCHECK_NUMBER(String check_number) {
		CHECK_NUMBER = check_number;
	}


	public String getCOMMENTS() {
		return COMMENTS;
	}


	public void setCOMMENTS(String comments) {
		COMMENTS = comments;
	}


	public String getCOMPANY_CODE() {
		return COMPANY_CODE;
	}


	public void setCOMPANY_CODE(String company_code) {
		COMPANY_CODE = company_code;
	}


	public String getCURRENCY_CODE() {
		return CURRENCY_CODE;
	}


	public void setCURRENCY_CODE(String currency_code) {
		CURRENCY_CODE = currency_code;
	}


	public String getDIVIDEND_OPTION() {
		return DIVIDEND_OPTION;
	}


	public void setDIVIDEND_OPTION(String dividend_option) {
		DIVIDEND_OPTION = dividend_option;
	}


	public String getDUE_DATE() {
		return DUE_DATE;
	}


	public void setDUE_DATE(String due_date) {
		DUE_DATE = due_date;
	}


	public String getEFFECTIVE_DATE() {
		return EFFECTIVE_DATE;
	}


	public void setEFFECTIVE_DATE(String effective_date) {
		EFFECTIVE_DATE = effective_date;
	}


	public String getLISTBILL_CLIENT_ID() {
		return LISTBILL_CLIENT_ID;
	}


	public void setLISTBILL_CLIENT_ID(String listbill_client_id) {
		LISTBILL_CLIENT_ID = listbill_client_id;
	}


	public String getMESSAGE_TEXT() {
		return MESSAGE_TEXT;
	}


	public void setMESSAGE_TEXT(String message_text) {
		MESSAGE_TEXT = message_text;
	}


	public String getMISCELLANEOUS_SUSPENSE_AMOUNT() {
		return MISCELLANEOUS_SUSPENSE_AMOUNT;
	}


	public void setMISCELLANEOUS_SUSPENSE_AMOUNT(String miscellaneous_suspense_amount) {
		MISCELLANEOUS_SUSPENSE_AMOUNT = miscellaneous_suspense_amount;
	}


	public String getMISCELLANEOUS_SUSPENSE_DATE() {
		return MISCELLANEOUS_SUSPENSE_DATE;
	}


	public void setMISCELLANEOUS_SUSPENSE_DATE(String miscellaneous_suspense_date) {
		MISCELLANEOUS_SUSPENSE_DATE = miscellaneous_suspense_date;
	}


	public String getNET_FUND_AMOUNT() {
		return NET_FUND_AMOUNT;
	}


	public void setNET_FUND_AMOUNT(String net_fund_amount) {
		NET_FUND_AMOUNT = net_fund_amount;
	}


	public String getNOTICE_TYPE() {
		return NOTICE_TYPE;
	}


	public void setNOTICE_TYPE(String notice_type) {
		NOTICE_TYPE = notice_type;
	}


	public String getOS_DISBURSEMENT() {
		return OS_DISBURSEMENT;
	}


	public void setOS_DISBURSEMENT(String os_disbursement) {
		OS_DISBURSEMENT = os_disbursement;
	}


	public String getOWNER_CLIENT_ID() {
		return OWNER_CLIENT_ID;
	}


	public void setOWNER_CLIENT_ID(String owner_client_id) {
		OWNER_CLIENT_ID = owner_client_id;
	}


	public String getOWNER_NAME() {
		return OWNER_NAME;
	}


	public void setOWNER_NAME(String owner_name) {
		OWNER_NAME = owner_name;
	}


	public String getPAID_TO_DATE() {
		return PAID_TO_DATE;
	}


	public void setPAID_TO_DATE(String paid_to_date) {
		PAID_TO_DATE = paid_to_date;
	}


	public String getPAYMENT_CODE() {
		return PAYMENT_CODE;
	}


	public void setPAYMENT_CODE(String payment_code) {
		PAYMENT_CODE = payment_code;
	}


	public String getPDF_AMOUNT() {
		return PDF_AMOUNT;
	}


	public void setPDF_AMOUNT(String pdf_amount) {
		PDF_AMOUNT = pdf_amount;
	}


	public String getPOLICY_ID() {
		return POLICY_ID;
	}


	public void setPOLICY_ID(String policy_id) {
		POLICY_ID = policy_id;
	}


	public String getPOLICY_INSURANCE_TYPE_CODE() {
		return POLICY_INSURANCE_TYPE_CODE;
	}


	public void setPOLICY_INSURANCE_TYPE_CODE(String policy_insurance_type_code) {
		POLICY_INSURANCE_TYPE_CODE = policy_insurance_type_code;
	}


	public String getPREMIUM_AMOUNT() {
		return PREMIUM_AMOUNT;
	}


	public void setPREMIUM_AMOUNT(String premium_amount) {
		PREMIUM_AMOUNT = premium_amount;
	}


	public String getPREMIUM_DUE_DATE() {
		return PREMIUM_DUE_DATE;
	}


	public void setPREMIUM_DUE_DATE(String premium_due_date) {
		PREMIUM_DUE_DATE = premium_due_date;
	}


	public String getPREMIUM_SUSPENSE() {
		return PREMIUM_SUSPENSE;
	}


	public void setPREMIUM_SUSPENSE(String premium_suspense) {
		PREMIUM_SUSPENSE = premium_suspense;
	}


	public String getPREMIUM_SUSPENSE_AMOUNT() {
		return PREMIUM_SUSPENSE_AMOUNT;
	}


	public void setPREMIUM_SUSPENSE_AMOUNT(String premium_suspense_amount) {
		PREMIUM_SUSPENSE_AMOUNT = premium_suspense_amount;
	}


	public String getREASON() {
		return REASON;
	}


	public void setREASON(String reason) {
		REASON = reason;
	}


	public String getREPORT_DATE() {
		return REPORT_DATE;
	}


	public void setREPORT_DATE(String report_date) {
		REPORT_DATE = report_date;
	}


	public String getREPORT_ID() {
		return REPORT_ID;
	}


	public void setREPORT_ID(String report_id) {
		REPORT_ID = report_id;
	}


	public String getREPORT_TYPE_CODE() {
		return REPORT_TYPE_CODE;
	}


	public void setREPORT_TYPE_CODE(String report_type_code) {
		REPORT_TYPE_CODE = report_type_code;
	}


	public String getRUN_DATE() {
		return RUN_DATE;
	}


	public void setRUN_DATE(String run_date) {
		RUN_DATE = run_date;
	}


	public String getSERVICING_AGENT_BRANCH_ID() {
		return SERVICING_AGENT_BRANCH_ID;
	}


	public void setSERVICING_AGENT_BRANCH_ID(String servicing_agent_branch_id) {
		SERVICING_AGENT_BRANCH_ID = servicing_agent_branch_id;
	}


	public String getSERVICING_AGENT_ID() {
		return SERVICING_AGENT_ID;
	}


	public void setSERVICING_AGENT_ID(String servicing_agent_id) {
		SERVICING_AGENT_ID = servicing_agent_id;
	}


	public String getSOURCE_SYSTEM() {
		return SOURCE_SYSTEM;
	}


	public void setSOURCE_SYSTEM(String source_system) {
		SOURCE_SYSTEM = source_system;
	}


	public String getSTATUS_CODE() {
		return STATUS_CODE;
	}


	public void setSTATUS_CODE(String status_code) {
		STATUS_CODE = status_code;
	}


	public String getSUB_COMPANY_ID() {
		return SUB_COMPANY_ID;
	}


	public void setSUB_COMPANY_ID(String sub_company_id) {
		SUB_COMPANY_ID = sub_company_id;
	}


	public String getSUNDRY_AMOUNT() {
		return SUNDRY_AMOUNT;
	}


	public void setSUNDRY_AMOUNT(String sundry_amount) {
		SUNDRY_AMOUNT = sundry_amount;
	}


	public String getTRANSACTION_TYPE_CODE() {
		return TRANSACTION_TYPE_CODE;
	}


	public void setTRANSACTION_TYPE_CODE(String transaction_type_code) {
		TRANSACTION_TYPE_CODE = transaction_type_code;
	}


	public String getTRUE_PREMIUM_AMOUNT() {
		return TRUE_PREMIUM_AMOUNT;
	}


	public void setTRUE_PREMIUM_AMOUNT(String true_premium_amount) {
		TRUE_PREMIUM_AMOUNT = true_premium_amount;
	}

	public String getINSURED_CLIENT_ID() {
		return INSURED_CLIENT_ID;
	}

	public void setINSURED_CLIENT_ID(String iNSURED_CLIENT_ID) {
		INSURED_CLIENT_ID = iNSURED_CLIENT_ID;
	}

	public String getINSURED_CLIENT_NAME() {
		return INSURED_CLIENT_NAME;
	}

	public void setINSURED_CLIENT_NAME(String iNSURED_CLIENT_NAME) {
		INSURED_CLIENT_NAME = iNSURED_CLIENT_NAME;
	}

	public String getCREATION_DATE() {
		return CREATION_DATE;
	}

	public void setCREATION_DATE(String cREATION_DATE) {
		CREATION_DATE = cREATION_DATE;
	}

	public String getDEPOSIT_AMOUNT() {
		return DEPOSIT_AMOUNT;
	}

	public void setDEPOSIT_AMOUNT(String dEPOSIT_AMOUNT) {
		DEPOSIT_AMOUNT = dEPOSIT_AMOUNT;
	}
	
	public String getMODE() {
		return MODE;
	}

	public void setMODE(String mode) {
		MODE = mode;
	}

	public String getPOLICY_OWNER() {
		return POLICY_OWNER;
	}

	public void setPOLICY_OWNER(String policy_owner) {
		POLICY_OWNER = policy_owner;
	}

	public String getDATE_LOGGED() {
		return DATE_LOGGED;
	}

	public void setDATE_LOGGED(String date_logged) {
		DATE_LOGGED = date_logged;
	}
	
	public String getGROUP_NAME() {
		return GROUP_NAME;
	}

	public void setGROUP_NAME(String group_name) {
		GROUP_NAME = group_name;
	}
	
	public String getGROSS_AMT() {
		return GROSS_AMT;
	}

	public void setGROSS_AMT(String gross_amt) {
		GROSS_AMT = gross_amt;
	}

	public String getSERVFEE_AMT() {
		return SERVFEE_AMT;
	}

	public void setSERVFEE_AMT(String servfee_amt) {
		SERVFEE_AMT = servfee_amt;
	}

	public String getVAT_AMT() {
		return VAT_AMT;
	}

	public void setVAT_AMT(String vat_amt) {
		VAT_AMT = vat_amt;
	}

	public String getTAX_WHELD() {
		return TAX_WHELD;
	}

	public void setTAX_WHELD(String tax_wheld) {
		TAX_WHELD = tax_wheld;
	}	

	public String getNET_AMT() {
		return NET_AMT;
	}

	public void setNET_AMT(String net_amt) {
		NET_AMT = net_amt;
	}

	public String getISSUE_DT() {
		return ISSUE_DT;
	}

	public void setISSUE_DT(String issue_dt) {
		ISSUE_DT = issue_dt;
	}
	
	public String getBASE_FACE_AMOUNT() {
		return BASE_FACE_AMOUNT;
	}

	public void setBASE_FACE_AMOUNT(String base_face_amount) {
		BASE_FACE_AMOUNT = base_face_amount;
	}

	public String getNFO_CODE() {
		return NFO_CODE;
	}

	public void setNFO_CODE(String nfo_code) {
		NFO_CODE = nfo_code;
	}

	public String getDOD_AMOUNT() {
		return DOD_AMOUNT;
	}

	public void setDOD_AMOUNT(String dod_amount) {
		DOD_AMOUNT = dod_amount;
	}

	public String getAE_FUND_AMOUNT() {
		return AE_FUND_AMOUNT;
	}

	public void setAE_FUND_AMOUNT(String ae_fund_amount) {
		AE_FUND_AMOUNT = ae_fund_amount;
	}

	public String getCUR() {
		return CUR;
	}

	public void setCUR(String cur) {
		CUR = cur;
	}

	public String getCASE_CV() {
		return CASE_CV;
	}

	public void setCASE_CV(String case_cv) {
		CASE_CV = case_cv;
	}

	public String getPUA_CV() {
		return PUA_CV;
	}

	public void setPUA_CV(String pua_cv) {
		PUA_CV = pua_cv;
	}

	public String getLOAN_PLUS_INT() {
		return LOAN_PLUS_INT;
	}

	public void setLOAN_PLUS_INT(String loan_plus_int) {
		LOAN_PLUS_INT = loan_plus_int;
	}

	public String getAPL_PLUS_INT() {
		return APL_PLUS_INT;
	}

	public void setAPL_PLUS_INT(String apl_plus_int) {
		APL_PLUS_INT = apl_plus_int;
	}

	public String getETI_EXP_DT() {
		return ETI_EXP_DT;
	}

	public void setETI_EXP_DT(String eti_exp_dt) {
		ETI_EXP_DT = eti_exp_dt;
	}

	public String getAMOUNT() {
		return AMOUNT;
	}

	public void setAMOUNT(String amount) {
		AMOUNT = amount;
	}

	public String getBASE_CV() {
		return BASE_CV;
	}

	public void setBASE_CV(String base_cv) {
		BASE_CV = base_cv;
	}
	
	public String getCSV_FOR_OVERLOAN() {
		return CSV_FOR_OVERLOAN;
	}

	public void setCSV_FOR_OVERLOAN(String csv_for_overloan) {
		CSV_FOR_OVERLOAN = csv_for_overloan;
	}

	public String getSTATUS() {
		return STATUS;
	}

	public void setSTATUS(String status) {
		STATUS = status;
	}

	public String getREMARKS() {
		return REMARKS;
	}

	public void setREMARKS(String remarks) {
		REMARKS = remarks;
	}

	public String getPOLICY_STATUS() {
		return POLICY_STATUS;
	}

	public void setPOLICY_STATUS(String policy_status) {
		POLICY_STATUS = policy_status;
	}

	public String getPLAN_ID() {
		return PLAN_ID;
	}

	public void setPLAN_ID(String plan_id) {
		PLAN_ID = plan_id;
	}

	public String getT_BAR() {
		return T_BAR;
	}

	public void setT_BAR(String t_bar) {
		T_BAR = t_bar;
	}

	public String getEFFECTIVE_DATE_TERMINATION() {
		return EFFECTIVE_DATE_TERMINATION;
	}

	public void setEFFECTIVE_DATE_TERMINATION(String effective_date_termination) {
		EFFECTIVE_DATE_TERMINATION = effective_date_termination;
	}

	public String getC_NO() {
		return C_NO;
	}

	public void setC_NO(String c_no) {
		C_NO = c_no;
	}

	public String getCOV_PROD_CD() {
		return COV_PROD_CD;
	}

	public void setCOV_PROD_CD(String cov_prod_cd) {
		COV_PROD_CD = cov_prod_cd;
	}

	public String getCURR_STAT() {
		return CURR_STAT;
	}

	public void setCURR_STAT(String curr_stat) {
		CURR_STAT = curr_stat;
	}

	public String getPREV_STAT() {
		return PREV_STAT;
	}

	public void setPREV_STAT(String prev_stat) {
		PREV_STAT = prev_stat;
	}

	public String getCOV_STAT_CHANGE_DATE() {
		return COV_STAT_CHANGE_DATE;
	}

	public void setCOV_STAT_CHANGE_DATE(String cov_stat_change_date) {
		COV_STAT_CHANGE_DATE = cov_stat_change_date;
	}

	public String getCOV_ISS_DT() {
		return COV_ISS_DT;
	}

	public void setCOV_ISS_DT(String cov_iss_dt) {
		COV_ISS_DT = cov_iss_dt;
	}

	public String getCOV_MAT_EXP_DT() {
		return COV_MAT_EXP_DT;
	}

	public void setCOV_MAT_EXP_DT(String cov_mat_exp_dt) {
		COV_MAT_EXP_DT = cov_mat_exp_dt;
	}

	public String getCOV_DUR() {
		return COV_DUR;
	}

	public void setCOV_DUR(String cov_dur) {
		COV_DUR = cov_dur;
	}

	public String getPOLICY_MODAL_PREMIUM() {
		return POLICY_MODAL_PREMIUM;
	}

	public void setPOLICY_MODAL_PREMIUM(String policy_modal_premium) {
		POLICY_MODAL_PREMIUM = policy_modal_premium;
	}

	public String getPTD() {
		return PTD;
	}

	public void setPTD(String ptd) {
		PTD = ptd;
	}

	public String getBRANCH_NAME() {
		return BRANCH_NAME;
	}

	public void setBRANCH_NAME(String branch_name) {
		BRANCH_NAME = branch_name;
	}

	public String getCOV_NUM() {
		return COV_NUM;
	}

	public void setCOV_NUM(String cov_num) {
		COV_NUM = cov_num;
	}

	public String getCASH_VALUE() {
		return CASH_VALUE;
	}

	public void setCASH_VALUE(String cash_value) {
		CASH_VALUE = cash_value;
	}

	public String getISSUE_EFFECTIVE_DATE() {
		return ISSUE_EFFECTIVE_DATE;
	}

	public void setISSUE_EFFECTIVE_DATE(String issue_effective_date) {
		ISSUE_EFFECTIVE_DATE = issue_effective_date;
	}

	public String getOS_AMOUNT() {
		return OS_AMOUNT;
	}

	public void setOS_AMOUNT(String os_amount) {
		OS_AMOUNT = os_amount;
	}

	public String getWORKITEM_CREATE_DATE() {
		return WORKITEM_CREATE_DATE;
	}

	public void setWORKITEM_CREATE_DATE(String workitem_create_date) {
		WORKITEM_CREATE_DATE = workitem_create_date;
	}

	public String getBASIC_FACE_AMOUNT() {
		return BASIC_FACE_AMOUNT;
	}

	public void setBASIC_FACE_AMOUNT(String BASIC_FACE_AMOUNT) {
		this.BASIC_FACE_AMOUNT = BASIC_FACE_AMOUNT;
	}


	public String getDISB_DATE() {
		return DISB_DATE;
	}

	public void setDISB_DATE(String DISB_DATE) {
		this.DISB_DATE = DISB_DATE;
	}

	public String getPROCESS_DATE() {
		return PROCESS_DATE;
	}

	public void setPROCESS_DATE(String PROCESS_DATE) {
		this.PROCESS_DATE = PROCESS_DATE;
	}

	public String getACF2ID() {
		return ACF2ID;
	}

	public void setACF2ID(String ACF2ID) {
		this.ACF2ID = ACF2ID;
	}

	public String getADDR_STAT_CODE() {
		return ADDR_STAT_CODE;
	}

	public void setADDR_STAT_CODE(String ADDR_STAT_CODE) {
		this.ADDR_STAT_CODE = ADDR_STAT_CODE;
	}

	public String getREINSURED_STAT_CODE() {
		return REINSURED_STAT_CODE;
	}

	public void setREINSURED_STAT_CODE(String REINSURED_STAT_CODE) {
		this.REINSURED_STAT_CODE = REINSURED_STAT_CODE;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}
}
