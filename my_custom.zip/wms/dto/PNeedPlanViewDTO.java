package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class PNeedPlanViewDTO extends SunSynergyDTO{
	

}
