package ph.com.sunlife.wms.dto;

import java.util.Vector;

public class WMSParam implements DataAccessInterface {
	private String WMSP_Desc;
	private String WMSP_Format;
	private String WMSP_ParamField;
	private String WMSP_Value;
	private Vector ObjectList = new Vector();	
	public void add(DataAccessInterface dataAccessInterface) {
		// TODO Auto-generated method stub
		ObjectList.add(dataAccessInterface);
	}
	public Vector getObjectList() {
		return ObjectList;
	}
	public void setObjectList(Vector objectList) {
		ObjectList = objectList;
	}
	public String getWMSP_Desc() {
		return WMSP_Desc;
	}
	public void setWMSP_Desc(String desc) {
		WMSP_Desc = desc;
	}
	public String getWMSP_Format() {
		return WMSP_Format;
	}
	public void setWMSP_Format(String format) {
		WMSP_Format = format;
	}
	public String getWMSP_ParamField() {
		return WMSP_ParamField;
	}
	public void setWMSP_ParamField(String paramField) {
		WMSP_ParamField = paramField;
	}
	public String getWMSP_Value() {
		return WMSP_Value;
	}
	public void setWMSP_Value(String value) {
		WMSP_Value = value;
	}
	public void add(WMSParam dataAccessInterface) {
		// TODO Auto-generated method stub
		ObjectList.add(dataAccessInterface);
	}
}
