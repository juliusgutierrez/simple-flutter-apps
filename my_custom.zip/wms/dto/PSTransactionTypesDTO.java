// PS_TRANSACTION_TYPES - Andre Ceasar Dacanay
package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class PSTransactionTypesDTO implements DataAccessInterface {
	private List ObjectList = new Vector();
	
	private String TRANS_ID;
	private String TRANS_DESC;
	private String TRANS_CATEGORY;
	private String TRANS_LOB;
	private String TRANS_DOC_ID;
	private String TRANS_SITE;
	private Boolean TRANS_ACTIVE;
	private String TRANS_CRE_USER;
	private Date TRANS_CRE_DATE;
	private String TRANS_UPD_USER;
	private Date TRANS_UPD_DATE;
	private String TRANS_PROD;
	private String TRANS_QUEUE;
	
	public String getTRANS_QUEUE() {
		return TRANS_QUEUE;
	}

	public void setTRANS_QUEUE(String trans_queue) {
		TRANS_QUEUE = trans_queue;
	}

	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}
	
	public void add(PSTransactionTypesDTO dto) {
		ObjectList.add(dto);
	}

	public Boolean getTRANS_ACTIVE() {
		return TRANS_ACTIVE;
	}

	public void setTRANS_ACTIVE(Boolean trans_active) {
		TRANS_ACTIVE = trans_active;
	}

	public String getTRANS_CATEGORY() {
		return TRANS_CATEGORY;
	}

	public void setTRANS_CATEGORY(String trans_category) {
		TRANS_CATEGORY = trans_category;
	}

	public Date getTRANS_CRE_DATE() {
		return TRANS_CRE_DATE;
	}

	public void setTRANS_CRE_DATE(Date trans_cre_date) {
		TRANS_CRE_DATE = trans_cre_date;
	}

	public String getTRANS_CRE_USER() {
		return TRANS_CRE_USER;
	}

	public void setTRANS_CRE_USER(String trans_cre_user) {
		TRANS_CRE_USER = trans_cre_user;
	}

	public String getTRANS_DESC() {
		return TRANS_DESC;
	}

	public void setTRANS_DESC(String trans_desc) {
		TRANS_DESC = trans_desc;
	}

	public String getTRANS_DOC_ID() {
		return TRANS_DOC_ID;
	}

	public void setTRANS_DOC_ID(String trans_doc_id) {
		TRANS_DOC_ID = trans_doc_id;
	}

	public String getTRANS_ID() {
		return TRANS_ID;
	}

	public void setTRANS_ID(String trans_id) {
		TRANS_ID = trans_id;
	}

	public String getTRANS_LOB() {
		return TRANS_LOB;
	}

	public void setTRANS_LOB(String trans_lob) {
		TRANS_LOB = trans_lob;
	}

	public String getTRANS_PROD() {
		return TRANS_PROD;
	}

	public void setTRANS_PROD(String trans_prod) {
		TRANS_PROD = trans_prod;
	}

	public String getTRANS_SITE() {
		return TRANS_SITE;
	}

	public void setTRANS_SITE(String trans_site) {
		TRANS_SITE = trans_site;
	}

	public Date getTRANS_UPD_DATE() {
		return TRANS_UPD_DATE;
	}

	public void setTRANS_UPD_DATE(Date trans_upd_date) {
		TRANS_UPD_DATE = trans_upd_date;
	}

	public String getTRANS_UPD_USER() {
		return TRANS_UPD_USER;
	}

	public void setTRANS_UPD_USER(String trans_upd_user) {
		TRANS_UPD_USER = trans_upd_user;
	}
}