package ph.com.sunlife.wms.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Vector;

public class PrismCreateWorkItemDTO implements DataAccessInterface{
	
	private String PLAN_NUMBER;
	private String CLIENT_FIRST_NAME;
	private String CLIENT_LAST_NAME;
	private String CLIENT_MIDDLE_NAME;
	private String CLIENT_NUMBER;
	private String AGE_INF_CODE;
	private Vector ObjectList = new Vector();
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add(dataAccessInterface);		
	}
	
	public void add(PrismCreateWorkItemDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
		
	}

	public String getCLIENT_NUMBER() {
		return CLIENT_NUMBER;
	}

	public void setCLIENT_NUMBER(String client_number) {
		CLIENT_NUMBER = client_number;
	}

	public String getCLIENT_FIRST_NAME() {
		return CLIENT_FIRST_NAME;
	}

	public void setCLIENT_FIRST_NAME(String client_first_name) {
		CLIENT_FIRST_NAME = client_first_name;
	}

	public String getCLIENT_LAST_NAME() {
		return CLIENT_LAST_NAME;
	}

	public void setCLIENT_LAST_NAME(String client_last_name) {
		CLIENT_LAST_NAME = client_last_name;
	}

	public String getCLIENT_MIDDLE_NAME() {
		return CLIENT_MIDDLE_NAME;
	}

	public void setCLIENT_MIDDLE_NAME(String client_middle_name) {
		CLIENT_MIDDLE_NAME = client_middle_name;
	}

	public Vector getObjectList() {
		return ObjectList;
	}

	public void setObjectList(Vector objectList) {
		ObjectList = objectList;
	}

	public String getPLAN_NUMBER() {
		return PLAN_NUMBER;
	}

	public void setPLAN_NUMBER(String plan_number) {
		PLAN_NUMBER = plan_number;
	}

	public String getAGE_INF_CODE() {
		return AGE_INF_CODE;
	}

	public void setAGE_INF_CODE(String age_inf_code) {
		AGE_INF_CODE = age_inf_code;
	}










	
	
}
