package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class PSSunSynergyListDTO implements DataAccessInterface{

	private String POLICY_PLAN_NUM;
	private String LOB;
	private Date ISSUE_DATE;
	private String PAYMENT_MODE;
	private String CREATED_BY;
	private Date DATE_CREATED;
	private String UPDATED_BY;
	private Date DATE_MODIFIED;
	private String MF_ACCOUNT_NUM;
	private List ObjectList = new Vector();
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}

	public void add(PSSunSynergyListDTO dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}
	
	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String created_by) {
		CREATED_BY = created_by;
	}

	public Date getDATE_CREATED() {
		return DATE_CREATED;
	}

	public void setDATE_CREATED(Date date_created) {
		DATE_CREATED = date_created;
	}

	public Date getDATE_MODIFIED() {
		return DATE_MODIFIED;
	}

	public void setDATE_MODIFIED(Date date_modified) {
		DATE_MODIFIED = date_modified;
	}

	public Date getISSUE_DATE() {
		return ISSUE_DATE;
	}

	public void setISSUE_DATE(Date issue_date) {
		ISSUE_DATE = issue_date;
	}

	public String getLOB() {
		return LOB;
	}

	public void setLOB(String lob) {
		LOB = lob;
	}

	public List getObjectList() {
		return ObjectList;
	}

	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}

	public String getPAYMENT_MODE() {
		return PAYMENT_MODE;
	}

	public void setPAYMENT_MODE(String payment_mode) {
		PAYMENT_MODE = payment_mode;
	}

	public String getPOLICY_PLAN_NUM() {
		return POLICY_PLAN_NUM;
	}

	public void setPOLICY_PLAN_NUM(String policy_plan_num) {
		POLICY_PLAN_NUM = policy_plan_num;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String updated_by) {
		UPDATED_BY = updated_by;
	}

	public String getMF_ACCOUNT_NUM() {
		return MF_ACCOUNT_NUM;
	}

	public void setMF_ACCOUNT_NUM(String mf_account_num) {
		MF_ACCOUNT_NUM = mf_account_num;
	}


	

}
