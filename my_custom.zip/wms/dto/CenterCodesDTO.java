package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class CenterCodesDTO implements DataAccessInterface{
	private String CC_ID;
	private String CC_Name;
	private String CC_Desc;
	private Boolean CC_AutoIdx;
	private Boolean CC_CanEncode;
	private Boolean CC_ViewImage;
	private Boolean CC_ZoomZone;
	private Boolean CC_Active;
	private String CC_CRE_User;
	private Date CC_CRE_Date;
	private String CC_UPD_User;
	private Date CC_UPD_Date;
	private String CC_AbbrevName;
	private List ObjectList = new Vector();

	public String getCC_ID(){
		 return CC_ID;
	}
	public void setCC_ID(String CC_ID){
		 this.CC_ID = CC_ID;
	}
	public String getCC_Name(){
		 return CC_Name;
	}
	public void setCC_Name(String CC_Name){
		 this.CC_Name = CC_Name;
	}
	public String getCC_Desc(){
		 return CC_Desc;
	}
	public void setCC_Desc(String CC_Desc){
		 this.CC_Desc = CC_Desc;
	}
	public Boolean getCC_AutoIdx(){
		 return CC_AutoIdx;
	}
	public void setCC_AutoIdx(Boolean CC_AutoIdx){
		 this.CC_AutoIdx = CC_AutoIdx;
	}
	public void setCC_Active(Boolean CC_Active){
		 this.CC_Active = CC_Active;
	}
	public Boolean getCC_Active(){
		 return CC_Active;
	}
	public Boolean getCC_CanEncode(){
		 return CC_CanEncode;
	}
	public void setCC_CanEncode(Boolean CC_CanEncode){
		 this.CC_CanEncode = CC_CanEncode;
	}
	public Boolean getCC_ViewImage(){
		 return CC_ViewImage;
	}
	public void setCC_ViewImage(Boolean CC_ViewImage){
		 this.CC_ViewImage = CC_ViewImage;
	}
	public Boolean getCC_ZoomZone(){
		 return CC_ZoomZone;
	}
	public void setCC_ZoomZone(Boolean CC_ZoomZone){
		 this.CC_ZoomZone = CC_ZoomZone;
	}
	public String getCC_CRE_User(){
		 return CC_CRE_User;
	}
	public void setCC_CRE_User(String CC_CRE_User){
		 this.CC_CRE_User = CC_CRE_User;
	}
	public Date getCC_CRE_Date(){
		 return CC_CRE_Date;
	}
	public void setCC_CRE_Date(Date CC_CRE_Date){
		 this.CC_CRE_Date = CC_CRE_Date;
	}
	public String getCC_UPD_User(){
		 return CC_UPD_User;
	}
	public void setCC_UPD_User(String CC_UPD_User){
		 this.CC_UPD_User = CC_UPD_User;
	}
	public Date getCC_UPD_Date(){
		 return CC_UPD_Date;
	}
	public void setCC_UPD_Date(Date CC_UPD_Date){
		 this.CC_UPD_Date = CC_UPD_Date;
	}
	public void add(DataAccessInterface dataAccessInterface) {
		// TODO Auto-generated method stub
		ObjectList.add(dataAccessInterface);
	}
	public void add( CenterCodesDTO dataAccessInterface) {
		ObjectList.add( dataAccessInterface );
	}
	public List get(){
		return ObjectList;
	}
	public String getCC_AbbrevName() {
		return CC_AbbrevName;
	}
	public void setCC_AbbrevName(String abbrevName) { 
		CC_AbbrevName = abbrevName;
	}
}
