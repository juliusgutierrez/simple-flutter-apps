package ph.com.sunlife.wms.dto;

import java.util.Date;

public class LifeDTO {
    private String policyNumber;
    private String ownerClientNumber;
    private String ownerIcifClientNumber;
    private String ownerFirstName;
    private String ownerMiddleName;
    private String ownerLastName;
    private String insuredClientNumber;
    private String insuredIcifClientNumber;
    private String insuredFirstName;
    private String insuredMiddleName;
    private String insuredLastName;
    private String agentCode;
    private Date effectivityDate;

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getOwnerClientNumber() {
        return ownerClientNumber;
    }

    public void setOwnerClientNumber(String ownerClientNumber) {
        this.ownerClientNumber = ownerClientNumber;
    }

    public String getOwnerIcifClientNumber() {
        return ownerIcifClientNumber;
    }

    public void setOwnerIcifClientNumber(String ownerIcifClientNumber) {
        this.ownerIcifClientNumber = ownerIcifClientNumber;
    }

    public String getOwnerFirstName() {
        return ownerFirstName;
    }

    public void setOwnerFirstName(String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }

    public String getOwnerMiddleName() {
        return ownerMiddleName;
    }

    public void setOwnerMiddleName(String ownerMiddleName) {
        this.ownerMiddleName = ownerMiddleName;
    }

    public String getOwnerLastName() {
        return ownerLastName;
    }

    public void setOwnerLastName(String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }

    public String getInsuredClientNumber() {
        return insuredClientNumber;
    }

    public void setInsuredClientNumber(String insuredClientNumber) {
        this.insuredClientNumber = insuredClientNumber;
    }

    public String getInsuredIcifClientNumber() {
        return insuredIcifClientNumber;
    }

    public void setInsuredIcifClientNumber(String insuredIcifClientNumber) {
        this.insuredIcifClientNumber = insuredIcifClientNumber;
    }

    public String getInsuredFirstName() {
        return insuredFirstName;
    }

    public void setInsuredFirstName(String insuredFirstName) {
        this.insuredFirstName = insuredFirstName;
    }

    public String getInsuredMiddleName() {
        return insuredMiddleName;
    }

    public void setInsuredMiddleName(String insuredMiddleName) {
        this.insuredMiddleName = insuredMiddleName;
    }

    public String getInsuredLastName() {
        return insuredLastName;
    }

    public void setInsuredLastName(String insuredLastName) {
        this.insuredLastName = insuredLastName;
    }

    public String getAgentCode() {
        return agentCode;
    }

    public void setAgentCode(String agentCode) {
        this.agentCode = agentCode;
    }

    public Date getEffectivityDate() {
        return effectivityDate;
    }

    public void setEffectivityDate(Date effectivityDate) {
        this.effectivityDate = effectivityDate;
    }
}