package ph.com.sunlife.wms.dto;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

public class ILifePlanViewDTO extends SunSynergyDTO{
	
	private static final DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	
	private Date parseDate(String dateStr) {
		//this is wrong do not do thios!!!
		Date date = null;
		try {
			if(StringUtils.isBlank(dateStr)){
				//for testing purposes only yow
				date = new Date();
			} else {
				date = DATE_FORMAT.parse(dateStr);
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public void setPOL_ISS_EFF_DT(String pol_iss_eff_dt) {
		setPOL_ISS_EFF_DT(parseDate(pol_iss_eff_dt));
	}
	
	public void setOWNER_BIRTH_DT(String owner_birth_dt) {
		setOWNER_BIRTH_DT(parseDate(owner_birth_dt));
	}
	
	public void setINSURED_BIRTHDATE(String insured_birthdate) {
		setINSURED_BIRTHDATE(parseDate(insured_birthdate));
	}
}
