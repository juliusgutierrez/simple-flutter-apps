package ph.com.sunlife.wms.dto;

import java.util.Date;
import java.util.List;
import java.util.Vector;

public class PSOrderReqtsDTO  implements DataAccessInterface {
	private List ObjectList = new Vector();
	
	private String PSOR_POLICYNO;
	private String PSOR_DOCUMENT_TYPE;
	private String PSOR_REQUIREMENT_STATUS;
	private Date PSOR_ORDER_DATE;
	private Date PSOR_DUE_DATE;
	private Date PSOR_RECEIVE_DATE;
	private String PSOR_REMARKS;
	private String PSOR_CLIENT_LEVEL;
	private String PSOR_TRANSACTION_NO;
	private Integer PSOR_REQUIREMENT_ID;

	public List getObjectList() {
		return ObjectList;
	}
	
	public void setObjectList(List objectList) {
		ObjectList = objectList;
	}
	
	public void add(DataAccessInterface dataAccessInterface) {
		ObjectList.add(dataAccessInterface);
	}
	
	public void add(PSOrderReqtsDTO dto) {
		ObjectList.add(dto);
	}

	public String getPSOR_POLICYNO() {
		return PSOR_POLICYNO;
	}

	public void setPSOR_POLICYNO(String pSOR_POLICYNO) {
		PSOR_POLICYNO = pSOR_POLICYNO;
	}

	public String getPSOR_DOCUMENT_TYPE() {
		return PSOR_DOCUMENT_TYPE;
	}

	public void setPSOR_DOCUMENT_TYPE(String pSOR_DOCUMENT_TYPE) {
		PSOR_DOCUMENT_TYPE = pSOR_DOCUMENT_TYPE;
	}

	public String getPSOR_REQUIREMENT_STATUS() {
		return PSOR_REQUIREMENT_STATUS;
	}

	public void setPSOR_REQUIREMENT_STATUS(String pSOR_REQUIREMENT_STATUS) {
		PSOR_REQUIREMENT_STATUS = pSOR_REQUIREMENT_STATUS;
	}

	public Date getPSOR_ORDER_DATE() {
		return PSOR_ORDER_DATE;
	}

	public void setPSOR_ORDER_DATE(Date pSOR_ORDER_DATE) {
		PSOR_ORDER_DATE = pSOR_ORDER_DATE;
	}

	public Date getPSOR_DUE_DATE() {
		return PSOR_DUE_DATE;
	}

	public void setPSOR_DUE_DATE(Date pSOR_DUE_DATE) {
		PSOR_DUE_DATE = pSOR_DUE_DATE;
	}

	public Date getPSOR_RECEIVE_DATE() {
		return PSOR_RECEIVE_DATE;
	}

	public void setPSOR_RECEIVE_DATE(Date pSOR_RECEIVE_DATE) {
		PSOR_RECEIVE_DATE = pSOR_RECEIVE_DATE;
	}

	public String getPSOR_REMARKS() {
		return PSOR_REMARKS;
	}

	public void setPSOR_REMARKS(String pSOR_REMARKS) {
		PSOR_REMARKS = pSOR_REMARKS;
	}

	public String getPSOR_CLIENT_LEVEL() {
		return PSOR_CLIENT_LEVEL;
	}

	public void setPSOR_CLIENT_LEVEL(String pSOR_CLIENT_LEVEL) {
		PSOR_CLIENT_LEVEL = pSOR_CLIENT_LEVEL;
	}

	public String getPSOR_TRANSACTION_NO() {
		return PSOR_TRANSACTION_NO;
	}

	public void setPSOR_TRANSACTION_NO(String pSOR_TRANSACTION_NO) {
		PSOR_TRANSACTION_NO = pSOR_TRANSACTION_NO;
	}

	public Integer getPSOR_REQUIREMENT_ID() {
		return PSOR_REQUIREMENT_ID;
	}

	public void setPSOR_REQUIREMENT_ID(Integer pSOR_REQUIREMENT_ID) {
		PSOR_REQUIREMENT_ID = pSOR_REQUIREMENT_ID;
	}
}

