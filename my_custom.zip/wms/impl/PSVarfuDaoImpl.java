package ph.com.sunlife.wms.impl;

//import ph.com.sunlife.persistence.DBConnection;
import java.util.ResourceBundle;

import ph.com.sunlife.wms.dao.PSVarfuDao;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PSVarfuListDTO;
import ph.com.sunlife.wms.dto.WMSParam;
import ph.com.sunlife.wms.util.db.DBManager;

public class PSVarfuDaoImpl implements PSVarfuDao {	

	public WMSParam getBFPReportDate() {
		//		DBConnection dbConn = new DBConnection();
		DBManager dbConn = new DBManager();
		String[] columnNames = { "WMSP_Desc", "WMSP_Format", "WMSP_ParamField", "WMSP_Value" };
		String[] dataType = { "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String" };
		String className = "ph.com.sunlife.wms.dto.WMSParam";
		StringBuffer query = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM WMSPARAM WHERE WMSP_PARAMFIELD = 'BFPReportDate' ");

		System.out.println("sql : " + query.toString());
		WMSParam dto = (WMSParam) dbConn.doSelect(className, columnNames, dataType, query.toString());
		System.out.println("dto: "+dto.getObjectList());
		return dto;
	}

	public PSVarfuListDTO getPSVarfuList(String whereClause) {
		//		DBConnection dbConn = new DBConnection();
		DBManager dbConn = new DBManager();
		String[] columnNames = { "POLICY_NUM" };

		String[] dataType = { "java.lang.String" };
		String className = "ph.com.sunlife.wms.dto.PSVarfuListDTO";
		StringBuffer query = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM PS_VARFU_LIST ");

		if (whereClause != null) {
			query.append(whereClause);
		}
		System.out.println("sql : " + query.toString());
		PSVarfuListDTO dto = (PSVarfuListDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());
		return dto;
	}

	public ILifePlanViewDTO getPolicyDetails(String whereClause) {
		//		DBConnection dbConn = new DBConnection();
		ResourceBundle rb = ResourceBundle.getBundle("com.ph.sunlife.component.properties.BatchCreateWorkitems");
		//ResourceBundle rb = ResourceBundle.getBundle("BatchCreateWorkItems");
		DBManager dbConn = new DBManager();
		String[] columnNames = { "POL_ID", "OWNER_CLIENT_NO", "OWNER_FIRST_NAME", "OWNER_MIDDLE_NAME", "OWNER_LAST_NAME", "INSURED_CLIENT_NO", "INSURED_FIRST_NAME", "INSURED_MIDDLE_NAME", "INSURED_LAST_NAME" };

		String[] dataType = { "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String" };
		String className = "ph.com.sunlife.wms.dto.ILifePlanViewDTO";
		StringBuffer query = new StringBuffer();
		String CLIF = rb.getString("cif.link.server");
		query.append("SELECT * FROM OPENQUERY(").append(CLIF).append(", 'SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM ILIFE_PLAN_VIEW ");

		if (whereClause != null) {
			query.append(whereClause);
		}

		query.append("')");
		System.out.println("sql : " + query.toString());
		ILifePlanViewDTO dto = (ILifePlanViewDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());
		return dto;
	}

}
