package ph.com.sunlife.wms.impl;

import org.apache.commons.dbutils.DbUtils;
import ph.com.sunlife.wms.constants.IcifConfig;
import ph.com.sunlife.wms.dao.IcifDAO;
import ph.com.sunlife.wms.dto.LifeDTO;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.util.db.WmsDbManager;

import javax.sql.rowset.CachedRowSet;
import java.util.ArrayList;
import java.util.List;

public class IcifDAOImpl implements IcifDAO {
    WmsDbManager wmsDbManager;

    public IcifDAOImpl() {
        wmsDbManager = new WmsDbManager();
    }

    public List<LifeDTO> getLifePlanByPolicyNumber(String policyNumber, String linkedServer) {
        CommonUtil.printLog("getLifePlanByPolicyNumber START");
        CommonUtil.printLog("policyNumber: " + policyNumber);
        List<LifeDTO> lifePlanDtoList = new ArrayList<LifeDTO>();
        CachedRowSet cachedRowSet = null;
        try {
            String[] param = {policyNumber,linkedServer};
            cachedRowSet = wmsDbManager.ExecuteSP(IcifConfig.SP_LIFE_PLAN_BY_POLICY_NUMBER, param);
            LifeDTO lifeDto;

            while(cachedRowSet.next()){
                lifeDto = new LifeDTO();
                lifeDto.setPolicyNumber(cachedRowSet.getString(IcifConfig.POLICY_NUMBER));
                lifeDto.setOwnerClientNumber(cachedRowSet.getString(IcifConfig.OWNER_CLIENT_NUMBER));
                lifeDto.setOwnerIcifClientNumber(cachedRowSet.getString(IcifConfig.OWNER_ICIF_CLIENT_NUMBER));
                lifeDto.setOwnerFirstName(cachedRowSet.getString(IcifConfig.OWNER_FIRST_NAME));
                lifeDto.setOwnerMiddleName(cachedRowSet.getString(IcifConfig.OWNER_MIDDLE_NAME));
                lifeDto.setOwnerLastName(cachedRowSet.getString(IcifConfig.OWNER_LAST_NAME));
                lifeDto.setInsuredClientNumber(cachedRowSet.getString(IcifConfig.INSURED_CLIENT_NUMBER));
                lifeDto.setInsuredIcifClientNumber(cachedRowSet.getString(IcifConfig.INSURED_ICIF_CLIENT_NUMBER));
                lifeDto.setInsuredFirstName(cachedRowSet.getString(IcifConfig.INSURED_FIRST_NAME));
                lifeDto.setInsuredMiddleName(cachedRowSet.getString(IcifConfig.INSURED_MIDDLE_NAME));
                lifeDto.setInsuredLastName(cachedRowSet.getString(IcifConfig.INSURED_LAST_NAME));
                lifePlanDtoList.add(lifeDto);
            }

            return lifePlanDtoList;

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            DbUtils.closeQuietly(cachedRowSet);
        }
        return lifePlanDtoList;
    }
}