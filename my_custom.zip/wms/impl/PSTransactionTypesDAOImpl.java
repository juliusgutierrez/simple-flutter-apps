// PS_TRANSACTION_TYPES - Andre Ceasar Dacanay
package ph.com.sunlife.wms.impl;
/*
 * author: Andre Ceasar Dacanay
 * 
 */

import java.sql.SQLException;


import ph.com.sunlife.wms.dao.PSTransactionTypesDAO;
import ph.com.sunlife.wms.dto.PSTransactionTypesDTO;
import ph.com.sunlife.wms.util.db.DBManager;


public class PSTransactionTypesDAOImpl extends BaseDAOImpl implements PSTransactionTypesDAO{
	
	//
	public PSTransactionTypesDTO getTranTypes() throws SQLException {
		String className = "ph.com.sunlife.wms.dto.PSTransactionTypesDTO";
		String[] colNames = {
				"TRANS_ID","TRANS_DESC","TRANS_CATEGORY","TRANS_LOB",
				"TRANS_DOC_ID","TRANS_SITE","TRANS_ACTIVE","TRANS_CRE_USER",
				"TRANS_CRE_DATE","TRANS_UPD_USER","TRANS_UPD_DATE","TRANS_PROD"
		};
		String[] dataTypes = {
				"java.lang.String","java.lang.String","java.lang.String","java.lang.String",
				"java.lang.String","java.lang.String","java.lang.Boolean","java.lang.String",
				"java.util.Date","java.lang.String","java.util.Date","java.lang.String"
		};
		String spName = "ps_getTranTypes";
		String[] params = new String[] {};
		return (PSTransactionTypesDTO) read(className, colNames, dataTypes, spName, params);
	}
	
	public PSTransactionTypesDTO getPSTransactionTypesDTO(){
		return getPSTransactionTypesDTO(null);
	}
	
	public PSTransactionTypesDTO getPSTransactionTypesDTO(String whereClause){
		
		DBManager dbConn = new DBManager();
		String className = "ph.com.sunlife.wms.dto.PSTransactionTypesDTO";
		String[] colNames = {
				"TRANS_ID","TRANS_DESC","TRANS_CATEGORY","TRANS_LOB",
				"TRANS_DOC_ID","TRANS_SITE","TRANS_ACTIVE","TRANS_CRE_USER",
				"TRANS_CRE_DATE","TRANS_UPD_USER","TRANS_UPD_DATE","TRANS_PROD","TRANS_QUEUE"
		};
		String[] dataTypes = {
				"java.lang.String","java.lang.String","java.lang.String","java.lang.String",
				"java.lang.String","java.lang.String","java.lang.Boolean","java.lang.String",
				"java.util.Date","java.lang.String","java.util.Date","java.lang.String","java.lang.String"
		};
		
		String sql = "SELECT TRANS_ID,TRANS_DESC,TRANS_CATEGORY,TRANS_LOB," +
				"TRANS_DOC_ID,TRANS_SITE,TRANS_ACTIVE,TRANS_CRE_USER,"+
				"TRANS_CRE_DATE,TRANS_UPD_USER,TRANS_UPD_DATE,TRANS_PROD, TRANS_QUEUE"+
				" FROM Ps_Transaction_Types ";
		
		if(whereClause!=null && !whereClause.trim().equals("")){
			sql = sql + whereClause;
		}
		PSTransactionTypesDTO dto = (PSTransactionTypesDTO)dbConn.doSelect(className, colNames, dataTypes, sql);
		
		return dto;
	}
	
	
}