package ph.com.sunlife.wms.impl;

import java.util.ResourceBundle;

import ph.com.sunlife.wms.dao.PrismCreateWorkItemDAO;
import ph.com.sunlife.wms.dto.PrismCreateWorkItemDTO;
import ph.com.sunlife.wms.util.db.DBManager;

public class PrismCreateWorkItemDAOImpl implements PrismCreateWorkItemDAO{

	public PrismCreateWorkItemDTO getPrismIndividualPlanDTO(String planNumber) {
		
		PrismCreateWorkItemDTO dto = null;	
		
		String[] columnNames = {
				"PLAN_NUMBER",
				"CLIENT_FIRST_NAME",
				"CLIENT_MIDDLE_NAME",
				"CLIENT_LAST_NAME",
				"CLIENT_NUMBER",
				"AGE_INF_CODE"
				};
		String[] dataType = {
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.String"
		}; 
		
		ResourceBundle rb = ResourceBundle.getBundle("com.ph.sunlife.component.properties.ComponentProperties");
		String linkedServer = rb.getString("PRISM_SERVER");//"SV5946\\SQL5DEV1"; //add to property file  
		String className = "ph.com.sunlife.wms.dto.PrismCreateWorkItemDTO";
		//String spName = "ps_getPrismIndividualPlanView";
		StringBuffer sql = new StringBuffer("SELECT TOP 1 ");
		for(int i=0; i<columnNames.length; i++){
			sql.append(columnNames[i]);
			if(i<columnNames.length-1){
				sql.append(", ");
			}
		}
		sql.append(" FROM OPENQUERY(");
		sql.append(linkedServer);
		sql.append(", 'SELECT * ");
		sql.append("FROM WMS_Individual_Info_View a, WMS_Individual_Agent_View b WHERE a.PLAN_NUMBER =''");
		sql.append(planNumber);
		sql.append("'' and a.PLAN_NUMBER = b.PLAN_NUMBER')");
		//String params[] = {policyNo, linkedServer};
		DBManager db = new DBManager();
		dto = (PrismCreateWorkItemDTO)db.doSelect(className, columnNames, dataType, sql.toString());
		System.out.println("DTO SIZE IN DTO: "+dto.getObjectList().size());
		return dto;
	}

	

}
