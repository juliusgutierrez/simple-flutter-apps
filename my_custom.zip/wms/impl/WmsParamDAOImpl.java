package ph.com.sunlife.wms.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.sql.rowset.CachedRowSet;
import org.apache.commons.lang.StringUtils;
import ph.com.sunlife.wms.dao.WmsParamDAO;
import ph.com.sunlife.wms.dto.WMSParam;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.util.db.WmsDbManager;

public class WmsParamDAOImpl implements WmsParamDAO{

	private WmsDbManager dbManager;
	private CachedRowSet cachedRowSet;
	private ResultSet resultSet;
	private static final String WMSP_VALUE = "WMSP_Value";
	private static final String WMSPARAM_FIELDS = "WMSP_Desc, WMSP_Format, WMSP_ParamField, WMSP_Value";
	private String query;
	
	public WmsParamDAOImpl(){
		dbManager = new WmsDbManager();
	}
	
	@Override
	public String getWmsParamValue(String paramField) throws SQLException{
		
		String wmsParamValue = null;

		CommonUtil.printLog("Inside WmsParamDAOImpl.getWmsParamValue...");
		if(StringUtils.isBlank(paramField)){
			return "paramField is empty";
		}

		StringBuilder queryBuilder = new StringBuilder();
		queryBuilder.append("SELECT ")
				.append(WMSP_VALUE)
				.append(" FROM WMSParam WHERE WMSP_ParamField = '")
				.append(paramField)
				.append("'");
		
		CommonUtil.printLog("getWmsParamValue sql: " + queryBuilder.toString());

		try {

			resultSet = dbManager.doSelect(queryBuilder.toString());

			while(resultSet.next()){
				wmsParamValue = resultSet.getString(WMSP_VALUE);
			}

		} catch (SQLException sqle) {
			CommonUtil.printLog("An SQLException was encountered while retrieving ["+wmsParamValue+"] in WMS Param with error message: ["+sqle.getMessage()+"]");
			sqle.printStackTrace();
		} catch(Exception e) {
			CommonUtil.printLog("An Exception was encountered while retrieving ["+wmsParamValue+"] in WMS Param with error message: ["+e.getMessage()+"]");
		} finally {
			resultSet.close();
		}
		
		CommonUtil.printLog("Leaving WmsParamDAOImpl.getWmsParamValue...");
		
		return wmsParamValue;

	}

	@Override
	public String getWmsParamValueWithCompanyCode(String paramField, String companyCode) {
		
		CommonUtil.printLog("Inside WmsParamDAOImpl.getWmsParamValueWithCompanyCode...");

		query = "SELECT " + WMSP_VALUE + " FROM WMSParam WHERE WMSP_ParamField = '" + paramField + "'" 
				+ " AND WMSP_Company_Code = '" + companyCode + "'";
		
		CommonUtil.printLog("getWmsParamValueWithCompanyCode sql: " + query);
		
		String wmsParamValue = null;
		
		try {
			
			cachedRowSet = dbManager.doSelect(query);
			while(cachedRowSet.next()){
				wmsParamValue = cachedRowSet.getString(WMSP_VALUE);
			}
			
		} catch (SQLException e) {
			CommonUtil.printLog("WmsParamDAOImpl", "getWmsParamValueWithCompanyCode", "Exception: " + CommonUtil.exceptionStacktraceToString(e));
		} finally{
			try {
				cachedRowSet.close();
			} catch (SQLException e) {
				CommonUtil.printLog("WmsParamDAOImpl", "getWmsParamValueWithCompanyCode", "Exception: " + CommonUtil.exceptionStacktraceToString(e));
			}
		}

		CommonUtil.printLog("Leaving WmsParamDAOImpl.getWmsParamValueWithCompanyCode...");
		
		return wmsParamValue;
	}

	@Override
	public List<WMSParam> getWmsParamList(String paramField) throws SQLException {
		CommonUtil.printLog("Inside WmsParamDAOImpl.getWmsParamList...");
		
		// validate if paramField is blank
		if(StringUtils.isBlank(paramField)){
			return Collections.emptyList();
		}

		query = "SELECT " + WMSPARAM_FIELDS
				+ " FROM WMSParam WHERE WMSP_ParamField = '" + paramField + "'";

		CommonUtil.printLog("getWmsParamList sql: " + query);
		cachedRowSet = dbManager.doSelect(query);
		
		WMSParam wmsParamDto = null;
		List<WMSParam> wmsParamList = new ArrayList<WMSParam>();

		while(cachedRowSet.next()){
			
			wmsParamDto = new WMSParam();
			
			wmsParamDto.setWMSP_Desc(cachedRowSet.getString("WMSP_Desc"));
			wmsParamDto.setWMSP_Format( cachedRowSet.getString("WMSP_Format"));
			wmsParamDto.setWMSP_ParamField(cachedRowSet.getString("WMSP_ParamField"));
			wmsParamDto.setWMSP_Value(cachedRowSet.getString(WMSP_VALUE));
			
			wmsParamList.add(wmsParamDto);
		}
		cachedRowSet.close();
		
		CommonUtil.printLog("Leaving WmsParamDAOImpl.getWmsParamList...");
		
		return wmsParamList;
	}

}
