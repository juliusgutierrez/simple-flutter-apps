package ph.com.sunlife.wms.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.rowset.CachedRowSet;
import org.apache.commons.lang.StringUtils;
import ph.com.sunlife.wms.dao.BankWorkitemDao;
import ph.com.sunlife.wms.dto.PSBankUploadListDTO;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.util.db.WmsDbManager;

public class BankWorkitemDaoImpl implements BankWorkitemDao {
	
	private WmsDbManager wmsDbManager;
	private String query;
	private CachedRowSet cachedRowSet;
	private static final String BANK_UPLOAD_LIST_FIELDS = "BANK_SHORTNAME, BANK_NAME, IS_LIFE, IS_PRENEED, RUN_ON_WKENDS, IS_ACTIVE";
	
	public BankWorkitemDaoImpl(){
		wmsDbManager = new WmsDbManager();
	}
	
	@Override
	public List<PSBankUploadListDTO> getPSBankUploadList(String companyCode) throws SQLException{
		CommonUtil.printLog("Inside BankWorkitemDaoImpl.getPSBankUploadList...");
		
		// validate if companyCode is blank
		if(StringUtils.isBlank(companyCode)){
			return null;
		}

		query = "SELECT " + BANK_UPLOAD_LIST_FIELDS
				+ " FROM PS_BANK_UPLOAD_LIST WHERE COMPANY_CODE = '" + companyCode + "'"
				+ " AND IS_ACTIVE = " + PSBatchConstants.IS_ACTIVE + "";
		
		CommonUtil.printLog("getPSBankUploadList sql: " + query.toString());
		cachedRowSet = wmsDbManager.doSelect(query.toString());
		
		List<PSBankUploadListDTO> bankUploadList = new ArrayList<PSBankUploadListDTO>();
		PSBankUploadListDTO psBankUploadDto = null;
		while(cachedRowSet.next()){

			psBankUploadDto = new PSBankUploadListDTO();
			
			psBankUploadDto.setBankShortName(cachedRowSet.getString("BANK_SHORTNAME"));
			psBankUploadDto.setBankName(cachedRowSet.getString("BANK_NAME"));
			psBankUploadDto.setIsLife(cachedRowSet.getBoolean("IS_LIFE"));
			psBankUploadDto.setIsPreneed(cachedRowSet.getBoolean("IS_PRENEED"));
			psBankUploadDto.setRunOnWeekEnds(cachedRowSet.getBoolean("RUN_ON_WKENDS"));
			psBankUploadDto.setIsActive(cachedRowSet.getBoolean("IS_ACTIVE"));

			bankUploadList.add(psBankUploadDto);
		}

		cachedRowSet.close();

		CommonUtil.printLog("Leaving BankWorkitemDaoImpl.getPSBankUploadList...");

		return bankUploadList;
	}

}
