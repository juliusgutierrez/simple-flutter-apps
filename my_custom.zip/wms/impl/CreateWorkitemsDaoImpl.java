package ph.com.sunlife.wms.impl;

import static ph.com.sunlife.wms.util.CommonUtil.exceptionStacktraceToString;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import ph.com.sunlife.wms.dao.CreateWorkitemsDao;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PSOrderReqtsDTO;
import ph.com.sunlife.wms.dto.PSReportColumnMapDTO;
import ph.com.sunlife.wms.dto.PSReportColumnValuesDTO;
import ph.com.sunlife.wms.dto.PSReportTxnMapDTO;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.util.WmsParamUtil;
import ph.com.sunlife.wms.util.db.DBManager;
import ph.com.sunlife.wms.util.db.WmsDbManager;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.util.DateUtil;

public class CreateWorkitemsDaoImpl implements CreateWorkitemsDao {
	
	private DBManager dbConn;
	private String linkServer = null;
	private String bfpReportDate = DateUtil.bfpReportDate;
	
	public CreateWorkitemsDaoImpl(String companyCode){
		dbConn = new DBManager();
		linkServer  = WmsParamUtil.getParamValueUsingParamFieldAndCompanyCode(
			PSBatchConstants.WMSPARAM_CIF_LINKSERVER, companyCode);
	}

	public PSReportTxnMapDTO getPSReportTxnMapDTO(String whereClause) {
		System.out.println("#### Inside CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");
		String[] columnNames = { "REPORT_ID", "REPORT_NAME", "PSTXNTYPE_TRANS_ID", "CREATED_BY", "DATE_CREATED",
				"UPDATED_BY", "DATE_MODIFIED" };
		String[] dataType = { "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String",
				"java.util.Date", "java.lang.String", "java.util.Date" };
		String className = "ph.com.sunlife.wms.dto.PSReportTxnMapDTO";
		StringBuffer query = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM Ps_Report_Txn_Map ");

		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}

		System.out.println("sql : "+query.toString());
		PSReportTxnMapDTO dto = (PSReportTxnMapDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());

		System.out.println("#### Leaving CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");
		return dto;
	}

	public PSReportColumnMapDTO getPSReportColumnMapDTO(String whereClause) {
		System.out.println("#### Inside CreateWorkitemsDaoImpl.getPSReportColumnMapDTO  ####");

		String[] columnNames = { "REPORT_ID", "COLUMN_NAME", "FNCE_PROPERTY_NAME", "FNPE_PROPERTY_NAME", "PRCV_COL_NAME", "OFFSET", "LENGTH" };
		String[] dataType = { "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String", "java.lang.String","java.lang.Integer",
				"java.lang.Integer" };
		String className = "ph.com.sunlife.wms.dto.PSReportColumnMapDTO";
		StringBuffer query = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM Ps_Report_Column_Map ");

		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		System.out.println("sql : "+query.toString());
		PSReportColumnMapDTO dto = (PSReportColumnMapDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());
		System.out.println("dto.size1 : "+dto.getObjectList().size());

		System.out.println("#### Leaving CreateWorkitemsDaoImpl.getPSReportColumnMapDTO  ####");
		return dto;
	}

	public PSReportColumnMapDTO getColumnMap(String reportId, String columnName) {
		System.out.println("#### Inside CreateWorkitemsDaoImpl.getColumnMap  ####");
		StringBuffer whereClause = new StringBuffer("WHERE Report_Id = '");
		whereClause.append(reportId);
		whereClause.append("' and Column_name = '");
		whereClause.append(columnName);
		whereClause.append("'");
		PSReportColumnMapDTO dto = getPSReportColumnMapDTO(whereClause.toString());
		System.out.println("dto.size2 : "+dto.getObjectList().size());
		System.out.println("#### Leaving CreateWorkitemsDaoImpl.getColumnMap  ####");
		return dto;
	}

	public PSOrderReqtsDTO getPSOrderReqtsDTO(String whereClause) {
		StringBuffer query = new StringBuffer("Select " +
				"PSOR_POLICYNO, " +
				"PSOR_DOCUMENT_TYPE, " +
				"PSOR_REQUIREMENT_STATUS, " +
				"PSOR_ORDER_DATE, " +
				"PSOR_DUE_DATE, " +
				"PSOR_RECEIVE_DATE, " +
				"PSOR_REMARKS, " +
				"PSOR_CLIENT_LEVEL, " +
				"PSOR_TRANSACTION_NO, " +
				"PSOR_REQUIREMENT_ID " +
				"From PS_ORDER_REQUIREMENTS ");
		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}

		String className = "ph.com.sunlife.wms.dto.PSOrderReqtsDTO";
		String dataType[] = {"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.util.Date",
				"java.util.Date",
				"java.util.Date",
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.Integer"};

		String columnNames[] = {"PSOR_POLICYNO", 
				"PSOR_DOCUMENT_TYPE", 
				"PSOR_REQUIREMENT_STATUS", 
				"PSOR_ORDER_DATE", 
				"PSOR_DUE_DATE", 
				"PSOR_RECEIVE_DATE", 
				"PSOR_REMARKS", 
				"PSOR_CLIENT_LEVEL", 
				"PSOR_TRANSACTION_NO", 
				"PSOR_REQUIREMENT_ID"};

		PSOrderReqtsDTO dto = (PSOrderReqtsDTO)dbConn.doSelect(className, columnNames, dataType, query.toString());
		return dto;
	}

	public ILifePlanViewDTO getLifePlanViewByPolicyNo(String whereClause) {
		System.out.println("#### Inside CreateWorkitemsDaoImpl.getILifePlanViewDTO  ####");
		ILifePlanViewDTO dto = null;

		String[] columnNames = {"POL_ID",
								"LOB_CD",
								"POL_CRCY_CD",
								"POL_ISS_EFF_DT",
								"POL_STAT_CD",
								"POL_BILL_MODE_CD",
								"OWNER_CLIENT_NO",
								"OWNER_FIRST_NAME",
								"OWNER_MIDDLE_NAME",
								"OWNER_LAST_NAME",
								"OWNER_BIRTH_DT",
								"ADDRESS",
								"INSURED_CLIENT_NO",
								"INSURED_FIRST_NAME",
								"INSURED_MIDDLE_NAME",
								"INSURED_LAST_NAME",
								"INSURED_BIRTHDATE",
								"AGENT_CODE",
								"AGENT_FIRST_NAME",
								"AGENT_MIDDLE_NAME",
								"AGENT_LAST_NAME",
								"AGENT_NBO_CODE",
								"BASIC_PLAN_ID",
								"POL_TPREM_AMT",
								"CVG_FACE_AMT"
								};

		String[] dataType = {PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_STRING,
							PSBatchConstants.DATA_TYPE_BIG_DECIMAL,
							PSBatchConstants.DATA_TYPE_BIG_DECIMAL
							};
		
		String className = "ph.com.sunlife.wms.dto.ILifePlanViewDTO";
		StringBuffer query = new StringBuffer();
		StringBuffer cols = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				cols.append(columnNames[i]);
				cols.append(", ");
			} else {
				cols.append(columnNames[i]);
			}
		}
		query.append(cols.toString());
		query.append(" FROM openquery (");
		query.append(linkServer);
		query.append(", 'select ");
		query.append(cols.toString());
		query.append(" from ILIFE_PLAN_VIEW ");
		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		query.append("')");

		System.out.println("sql : "+query.toString());
		try{
			dto = (ILifePlanViewDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());
			System.out.println("dto.size1 ilifeplanview: "+dto.getObjectList().size());
		}catch(Exception e){
			System.out.println("Exception in getILifePlanViewDTO " + e.getMessage());
		}
	
		System.out.println("#### Leaving CreateWorkitemsDapImpl.getILifePlanViewDTO  ####");
		return dto;
	}
	
	public PSReportColumnMapDTO getPSReportColumnMapDTO() {
		return getPSReportColumnMapDTO("");
	}

	public PSReportTxnMapDTO getPSReportTxnMapDTO() {
		return getPSReportTxnMapDTO("");
	}

	public PSOrderReqtsDTO getPSOrderReqtsDTO() {
		return getPSOrderReqtsDTO("");
	}

	public boolean insertPSReportColumnValuesDTO(PSReportColumnValuesDTO dto) {
		return dbConn.doInsert("PS_REPORT_COLUMN_VALUES", dto);
	}
	
	public String getRoboID() {
		System.out.println("#### Start CreateWorkitemsDapImpl.getRoboID  ####");
		
		String robotID = "";
		try {
			String sql = "SELECT * FROM wmsParam WHERE wmsp_paramField='" + PSBatchConstants.WMSPARAM_PPC_ROBOTID + "'";
			System.out.println("Query to fetch robotID: " + sql);
			
			// Get connection and set preparedStatement & resultSet
			WmsDbManager dbMan = new WmsDbManager();
			Connection dbConn = dbMan.getConnection();
			PreparedStatement prepareStatement = dbConn.prepareStatement(sql.toString());
			ResultSet rs = prepareStatement.executeQuery();
			
			if (rs.next()) {
				robotID = rs.getString(4);
			}
		} catch (Exception e) {
			System.out.println("Error encountered while getting robotID in DAO: " + exceptionStacktraceToString(e));
		}
		
		System.out.println("#### Leaving CreateWorkitemsDapImpl.getRoboID  ####");
		return robotID;
	}

	public Map<String, String> getPolicyWICreationHistory(String reportId, String companyCode) {
		CommonUtil.printLog("##### Start CreateWorkitemsDaoImpl.getPolicyWICreationHistory #####");

		Map<String, String> map = new HashMap<String, String>();
		StringBuilder sql = new StringBuilder();
		sql.append("Select policy_id, convert(varchar, max(report_date), 23) as report_date from PS_report_column_values where report_id = '")
				.append(reportId)
				.append("' ")
				.append("and company_code = '")
				.append(companyCode)
				.append("' and DATEDIFF(day, report_date, '")
				.append(bfpReportDate)
				.append("') between 0 and 31 ")
				.append("group by policy_id");

		CommonUtil.printLog("CreateWorkitemsDaoImpl", "getPolicyWICreationHistory", "Executing query to get policy creation history: " + sql.toString());

		WmsDbManager dbMan = new WmsDbManager();
		Connection dbConn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			dbConn = dbMan.getConnection();
			preparedStatement = dbConn.prepareStatement(sql.toString());
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				map.put(rs.getString("POLICY_ID"), rs.getString("REPORT_DATE"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnections(rs, preparedStatement, dbConn);
		}
		CommonUtil.printLog("##### End CreateWorkitemsDaoImpl.getPolicyWICreationHistory #####");
		return map;
	}

	public List<String> getHolidayWeekendList() {
		CommonUtil.printLog("##### Start CreateWorkitemsDaoImpl.getHolidayWeekendList #####");

		List<String> list = new ArrayList<String>();
		StringBuilder sql = new StringBuilder();
		sql.append("select convert(varchar, SLFC_Date, 23) as SLFC_Date from SLF_Calendar ")
				.append("where (SLFC_Holiday = '1' ")
				.append("or SLFC_Weekend = '1') ")
				.append("and DATEDIFF(day, SLFC_Date, '")
				.append(bfpReportDate)
				.append("') between 0 and 6");

		CommonUtil.printLog("CreateWorkitemsDaoImpl", "getHolidayWeekendList", "Executing query to get holidays and weekends: " + sql.toString());

		WmsDbManager dbMan = new WmsDbManager();
		Connection dbConn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;
		try {
			dbConn = dbMan.getConnection();
			preparedStatement = dbConn.prepareStatement(sql.toString());
			rs = preparedStatement.executeQuery();
			while (rs.next()) {
				list.add(rs.getString("SLFC_Date"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeConnections(rs, preparedStatement, dbConn);
		}
		CommonUtil.printLog("##### End CreateWorkitemsDaoImpl.getHolidayWeekendList #####");
		return list;
	}

	public List<String> getEnterInfoReports() throws SQLException, Exception 	{
		CommonUtil.printLog("#### Inside CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");

		List<String> list = new ArrayList<String>();

		String className = "ph.com.sunlife.wms.dto.PSReportTxnMapDTO";
		StringBuilder query = new StringBuilder();
		query.append("SELECT REPORT_ID FROM Ps_Report_Txn_Map WHERE IsEnterInfo = '1'");

		WmsDbManager dbMan = new WmsDbManager();
		Connection dbConn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		CommonUtil.printLog("sql : "+query.toString());
		dbConn = dbMan.getConnection();
		preparedStatement = dbConn.prepareStatement(query.toString());
		rs = preparedStatement.executeQuery();

		while (rs.next()) {
			list.add(rs.getString("REPORT_ID"));
		}

		CommonUtil.printLog("Reports for Enter Info: " + list.toString());

		CommonUtil.printLog("#### Leaving CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");
		return list;
	}

	@Override
	public String getWorkflowSite(String transType) throws SQLException{
		CommonUtil.printLog("#### Inside CreateWorkitemsDaoImpl.getWorkflowSite: fetching WorkflowSite by TransType ####");

		Connection dbConn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String workflowSite = null;

		String className = "ph.com.sunlife.wms.dto.PSReportTxnMapDTO";
		StringBuilder query = new StringBuilder();
		query.append("\n" +
				"SELECT TRANS_SITE FROM PS_TRANSACTION_TYPES WHERE Trans_ID = '"+transType+"'");

		try{
			WmsDbManager dbMan = new WmsDbManager();

			CommonUtil.printLog("sql : "+ query.toString());
			dbConn = dbMan.getConnection();
			preparedStatement = dbConn.prepareStatement(query.toString());
			rs = preparedStatement.executeQuery();

			rs.next();

			workflowSite = rs.getString("TRANS_SITE");
		} catch (SQLException e) {
			throw new SQLException(e);
		} finally {
			closeConnections(rs, preparedStatement, dbConn);
		}

		CommonUtil.printLog("WorkflowSite for TransType "+transType+" : " + workflowSite);

		CommonUtil.printLog("#### Leaving CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");
		return workflowSite;
	}

	@Override
	public String getCCUnit(String transSite) throws SQLException{
		CommonUtil.printLog("#### Inside CreateWorkitemsDaoImpl.getCCUnit: fetching CCUnit by TransSite ####");

		Connection dbConn = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		String ccUnit = null;

		String className = "ph.com.sunlife.wms.dto.PSReportTxnMapDTO";
		StringBuilder query = new StringBuilder();
		query.append("SELECT HCC_CC_ID, HUB_Category FROM Hubs ");
		query.append("LEFT JOIN HubCCs ");
		query.append("ON HUB_ID = HCC_HUB_ID ");
		query.append("WHERE HUB_Category = '"+transSite+"'");
		try {
			WmsDbManager dbMan = new WmsDbManager();

			CommonUtil.printLog("sql : " + query.toString());
			dbConn = dbMan.getConnection();
			preparedStatement = dbConn.prepareStatement(query.toString());
			rs = preparedStatement.executeQuery();

			rs.next();

			ccUnit = rs.getString("HCC_CC_ID");
		}
		catch (SQLException e) {
			throw new SQLException(e);
		} finally {
			closeConnections(rs, preparedStatement, dbConn);
		}

		CommonUtil.printLog("CCUnit for TransSite " + transSite + " : " + ccUnit);

		CommonUtil.printLog("#### Leaving CreateWorkitemsDaoImpl.getPSReportTxnMapDTO  ####");

		return ccUnit;
	}

	private void closeConnections(ResultSet rs, PreparedStatement preparedStatement, Connection dbConn) {

		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (preparedStatement != null) {
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (dbConn != null) {
			try {
				dbConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}