package ph.com.sunlife.wms.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

//import ph.com.sunlife.persistence.DBConnection;
import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.dao.PSSunSynergyDao;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PNeedPlanViewDTO;
import ph.com.sunlife.wms.dto.PSSunSynergyListDTO;
import ph.com.sunlife.wms.dto.SunSynergyDTO;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.util.db.DBManager;

public class PSSunSynergyDaoImpl implements PSSunSynergyDao{
	
	private String cifLinkServer;
	private ResourceBundle rb;
	
	public PSSunSynergyDaoImpl(){
		rb = CreateWorkitems.getCreateWIResourceBundle();
		cifLinkServer = rb.getString("cif.link.server");
	}
	
	public PSSunSynergyListDTO getPSSunSynergyListDTO(){
		return getPSSunSynergyListDTO(null);
	}
	
	public PSSunSynergyListDTO getPSSunSynergyListDTO(String whereClause){
		System.out.println("#### Inside PSSunSynergyDaoImpl.getPSSunSynergyListDTO  ####");
//		DBConnection dbConn = new DBConnection();
		DBManager dbConn = new DBManager();
		String[] columnNames = {"POLICY_PLAN_NUM", 
								"LOB", 
								"ISSUE_DATE", 
								"PAYMENT_MODE", 
								"CREATED_BY",
								"DATE_CREATED", 
								"UPDATED_BY", 
								"DATE_MODIFIED",
								"MF_ACCOUNT_NUM"};

		String[] dataType = {"java.lang.String", 
							"java.lang.String", 
							"java.util.Date", 
							"java.lang.String",
							"java.lang.String",
							"java.util.Date",
							"java.lang.String",
							"java.util.Date",
							"java.lang.String"};
		String className = "ph.com.sunlife.wms.dto.PSSunSynergyListDTO";
		StringBuffer query = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM PS_SUNSYNERGY_LIST ");

		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		
		System.out.println("sql : "+query.toString());
		PSSunSynergyListDTO dto = (PSSunSynergyListDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());

		System.out.println("#### Leaving PSSunSynergyDaoImpl.getPSSunSynergyListDTO  ####");
		return dto;
	}
	
	public PSSunSynergyListDTO getPSSunSynergyList(Date BFPReportDate, String paymentMode) {
		System.out.println("#### inside PSSunSynergyDaoImpl.getPSSunSynergyList  ####");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar cal1 = new GregorianCalendar();
		Calendar cal2 = null;
		Calendar cal3 = null;
		Calendar cal4 = null;
		
		cal1.setTime(BFPReportDate);
		
		int month1 = cal1.get(Calendar.MONTH)+1;
		int month2, month3, month4;
		int day = cal1.get(Calendar.DAY_OF_MONTH);
		
		StringBuffer whereClause = new StringBuffer("WHERE PAYMENT_MODE = '");
		whereClause.append(paymentMode);
		whereClause.append("' and ISSUE_DATE <= getDate()");
		whereClause.append(" and (month(ISSUE_DATE) = ");
		whereClause.append(month1);
		
		if(paymentMode.equals("Q") || paymentMode.equals("S")){
			cal2 = new GregorianCalendar();
			cal2.setTime(BFPReportDate);
			cal2.add(Calendar.MONTH, 6);
			
			month2 = cal2.get(Calendar.MONTH)+1;
			
			whereClause.append(" or month(ISSUE_DATE) = ");
			whereClause.append(month2);
			if(paymentMode.equals("Q")){
				cal3 = new GregorianCalendar();
				cal4 = new GregorianCalendar();
				
				cal3.setTime(BFPReportDate);
				cal4.setTime(BFPReportDate);
				
				cal3.add(Calendar.MONTH, 3);
				cal4.add(Calendar.MONTH, 9);
				
				month3 = cal3.get(Calendar.MONTH)+1;
				month4 = cal4.get(Calendar.MONTH)+1;
				
				whereClause.append(" or month(ISSUE_DATE) = ");
				whereClause.append(month3);
				whereClause.append(" or month(ISSUE_DATE) = ");
				whereClause.append(month4);
			}
		}
		whereClause.append(") and (day(ISSUE_DATE) = ");
		whereClause.append(day);
		
		//for February on non-Leap Year
		if(!isLeapYear(BFPReportDate) && month1==2 && isEndOfMonth(BFPReportDate)){
			whereClause.append(" or day(ISSUE_DATE) = 29");
			whereClause.append(" or day(ISSUE_DATE) = 30");
			whereClause.append(" or day(ISSUE_DATE) = 31");
		}
		
		//for February on a Leap Year
		if(isLeapYear(BFPReportDate) && month1==2 && isEndOfMonth(BFPReportDate) && (paymentMode.equals("Q") || paymentMode.equals("S"))){
			whereClause.append(" or day(ISSUE_DATE) = 30");
			whereClause.append(" or day(ISSUE_DATE) = 31");
		}
		
		//for Apr,Jun,Sep,Nov  (months with 30 days)
		if((month1==4 || month1==6 || month1==9 || month1==11) && isEndOfMonth(BFPReportDate) && (paymentMode.equals("Q") || paymentMode.equals("S"))){
			whereClause.append(" or day(ISSUE_DATE) = 31");
		}
		
		//additional condition, must check LAST_CREATED_WI_DATE in case there are special runs (when BFPReportDate is backdated 
		//and the batch is run again) so that workitems will not be duplicated.
		whereClause.append(") and coalesce(LAST_CREATED_WI_DATE, '1900-01-01 00:00:00.000') < dateadd(m,-3,'");
		whereClause.append(sdf.format(cal1.getTime()));
		whereClause.append("')");
		
		System.out.println("#### leaving PSSunSynergyDaoImpl.getPSSunSynergyList  ####");
		return getPSSunSynergyListDTO(whereClause.toString());
	}
	
	private boolean isLeapYear(Date date){
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		
		return (cal.getActualMaximum(Calendar.DAY_OF_YEAR)==366);
	}
	
	private boolean isEndOfMonth(Date date){
		Calendar cal = new GregorianCalendar();
		cal.setTime(date);
		
		return (cal.getActualMaximum(Calendar.DAY_OF_MONTH)==cal.get(Calendar.DAY_OF_MONTH));
	}
	
	public ILifePlanViewDTO getILifePlanViewDTO(){
		
		return getILifePlanViewDTO("");
	}
	
	public ILifePlanViewDTO getILifePlanViewDTO(String whereClause){
		System.out.println("#### Inside PSSunSynergyDaoImpl.getILifePlanViewDTO  ####");

//		DBConnection dbConn = new DBConnection();
		DBManager dbConn = new DBManager();
		String[] columnNames = {"POL_ID",
								"LOB_CD",
								"POL_CRCY_CD",
								"POL_ISS_EFF_DT",
								"POL_STAT_CD",
								"POL_BILL_MODE_CD",
								"OWNER_CLIENT_NO",
								"OWNER_FIRST_NAME",
								"OWNER_MIDDLE_NAME",
								"OWNER_LAST_NAME",
								"OWNER_BIRTH_DT",
								"ADDRESS",
								"INSURED_CLIENT_NO",
								"INSURED_FIRST_NAME",
								"INSURED_MIDDLE_NAME",
								"INSURED_LAST_NAME",
								"INSURED_BIRTHDATE",
								"AGENT_CODE",
								"AGENT_FIRST_NAME",
								"AGENT_MIDDLE_NAME",
								"AGENT_LAST_NAME",
								"AGENT_NBO_CODE",
								"BASIC_PLAN_ID",
								"POL_TPREM_AMT",
								"CVG_FACE_AMT"
								};

		String[] dataType = {"java.lang.String", 	//POL_ID
							"java.lang.String",     //LOB_CD
							"java.lang.String",     //POL_CRCY_CD
							"java.util.Date",     	//POL_ISS_EFF_DT  java.util.Date
							"java.lang.String",     //POL_STAT_CD
							"java.lang.String",     //POL_BILL_MODE_CD
							"java.lang.String",     //OWNER_CLIENT_NO
							"java.lang.String",     //OWNER_FIRST_NAME
							"java.lang.String",     //OWNER_MIDDLE_NAME
							"java.lang.String",     //OWNER_LAST_NAME
							"java.util.Date", 	    //OWNER_BIRTH_DT  java.util.Date
							"java.lang.String",     //ADDRESS
							"java.lang.String",     //INSURED_CLIENT_NO
							"java.lang.String",     //INSURED_FIRST_NAME
							"java.lang.String",     //INSURED_MIDDLE_NAME
							"java.lang.String",     //INSURED_LAST_NAME
							"java.util.Date",    	//INSURED_BIRTHDATE  java.util.Date
							"java.lang.String",     //AGENT_CODE
							"java.lang.String",     //AGENT_FIRST_NAME
							"java.lang.String",     //AGENT_MIDDLE_NAME
							"java.lang.String",     //AGENT_LAST_NAME
							"java.lang.String",     //AGENT_NBO_CODE
							"java.lang.String",     //BASIC_PLAN_ID
							"java.math.BigDecimal",     //POL_TPREM_AMT
							"java.math.BigDecimal"      //CVG_FACE_AMT
							};
		String className = "ph.com.sunlife.wms.dto.ILifePlanViewDTO";
		StringBuffer query = new StringBuffer();
		StringBuffer cols = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				cols.append(columnNames[i]);
				cols.append(", ");
			} else {
				cols.append(columnNames[i]);
			}
		}
		query.append(cols.toString());
		query.append(" FROM openquery (");
		query.append(cifLinkServer);
		query.append(", 'select ");
		query.append(cols.toString());
		query.append(" from ILIFE_PLAN_VIEW ");
		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		query.append("')");
		
		System.out.println("sql : "+query.toString());
		ILifePlanViewDTO dto = (ILifePlanViewDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());

		System.out.println("#### Leaving PSSunSynergyDaoImpl.getILifePlanViewDTO  ####");
		return dto;
	}
	
	public PNeedPlanViewDTO getPNeedPlanViewDTO(String whereClause){
		System.out.println("#### Inside PSSunSynergyDaoImpl.getPNeedPlanViewDTO  ####");
//		DBConnection dbConn = new DBConnection();
		DBManager dbConn = new DBManager();
		String[] columnNames = {"POL_ID",
								"LOB_CD",
								"POL_CRCY_CD",
								"POL_ISS_EFF_DT",
								"POL_STAT_CD",
								"POL_BILL_MODE_CD",
								"OWNER_CLIENT_NO",
								"OWNER_FIRST_NAME",
								"OWNER_MIDDLE_NAME",
								"OWNER_LAST_NAME",
								"OWNER_BIRTH_DT",
								"ADDRESS",
								"INSURED_CLIENT_NO",
								"INSURED_FIRST_NAME",
								"INSURED_MIDDLE_NAME",
								"INSURED_LAST_NAME",
								"INSURED_BIRTHDATE",
								"AGENT_CODE",
								"AGENT_FIRST_NAME",
								"AGENT_MIDDLE_NAME",
								"AGENT_LAST_NAME",
								"AGENT_NBO_CODE",
								"BASIC_PLAN_ID",
								"POL_TPREM_AMT",
								"CVG_FACE_AMT"
								};

		String[] dataType = {"java.lang.String", 	//POL_ID
							"java.lang.String",     //LOB_CD
							"java.lang.String",     //POL_CRCY_CD
							"java.util.Date",     	//POL_ISS_EFF_DT    java.util.Date
							"java.lang.String",     //POL_STAT_CD
							"java.lang.String",     //POL_BILL_MODE_CD
							"java.lang.String",     //OWNER_CLIENT_NO
							"java.lang.String",     //OWNER_FIRST_NAME
							"java.lang.String",     //OWNER_MIDDLE_NAME
							"java.lang.String",     //OWNER_LAST_NAME
							"java.util.Date", 	    //OWNER_BIRTH_DT    java.util.Date
							"java.lang.String",     //ADDRESS
							"java.lang.String",     //INSURED_CLIENT_NO
							"java.lang.String",     //INSURED_FIRST_NAME
							"java.lang.String",     //INSURED_MIDDLE_NAME
							"java.lang.String",     //INSURED_LAST_NAME
							"java.util.Date",    	//INSURED_BIRTHDATE    java.util.Date
							"java.lang.String",     //AGENT_CODE
							"java.lang.String",     //AGENT_FIRST_NAME
							"java.lang.String",     //AGENT_MIDDLE_NAME
							"java.lang.String",     //AGENT_LAST_NAME
							"java.lang.String",     //AGENT_NBO_CODE
							"java.lang.String",     //BASIC_PLAN_ID
							"java.math.BigDecimal",     //POL_TPREM_AMT
							"java.math.BigDecimal"      //CVG_FACE_AMT
							};
		String className = "ph.com.sunlife.wms.dto.PNeedPlanViewDTO";
		StringBuffer query = new StringBuffer();
		StringBuffer cols = new StringBuffer();
		query.append("SELECT ");
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				cols.append(columnNames[i]);
				cols.append(", ");
			} else {
				cols.append(columnNames[i]);
			}
		}
		query.append(cols.toString());
		query.append(" FROM openquery (");
		query.append(cifLinkServer);
		query.append(", 'select ");
		query.append(cols.toString());
		query.append(" from PNEED_PLAN_VIEW ");  //PNEED_PLAN_VIEW -> temp table
		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		query.append("')");
		
		System.out.println("sql : "+query.toString());
		PNeedPlanViewDTO dto = (PNeedPlanViewDTO) dbConn.doSelect(className, columnNames, dataType, query.toString());

		System.out.println("#### Leaving PSSunSynergyDaoImpl.getPNeedPlanViewDTO  ####");
		
		return dto;
	}


	public PNeedPlanViewDTO getPNeedPlanViewDTO() {
		return getPNeedPlanViewDTO("");
	}

	public SunSynergyDTO getPolicyDetails(List policiesStr, String lob) {
		
		StringBuffer whereClause = new StringBuffer("WHERE Pol_Id IN (");
		
		for(Iterator i=policiesStr.iterator(); i.hasNext();){
			whereClause.append("''");
			whereClause.append(i.next());
			if(i.hasNext()){
				whereClause.append("''");
				whereClause.append(",");
			} else {
				whereClause.append("''");
			}
		}
		whereClause.append(")");
		
		if(lob.equalsIgnoreCase(PSBatchConstants.LOB_LIFE)){
			return getILifePlanViewDTO(whereClause.toString());
		} else if (lob.equalsIgnoreCase(PSBatchConstants.LOB_PRENEED)){
			return getPNeedPlanViewDTO(whereClause.toString());
		}
		
		return null;
	}

	public boolean updateLastCreateWIDate(String policyNumber, Date lastCreateWIDate ) {
		
		DBManager dbConn = new DBManager();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		StringBuffer strQuery = new StringBuffer("Update PS_SUNSYNERGY_LIST Set LAST_CREATED_WI_DATE = '");
		strQuery.append(sdf.format(lastCreateWIDate)).append("' ");
		strQuery.append("Where POLICY_PLAN_NUM = '").append(policyNumber).append("'");
		
		dbConn.ExecQuery(strQuery.toString());
		
		return true;
	}
	
}
