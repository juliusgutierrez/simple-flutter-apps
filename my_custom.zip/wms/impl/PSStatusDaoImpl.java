package ph.com.sunlife.wms.impl;

import org.apache.commons.lang3.StringUtils;
import ph.com.sunlife.wms.dao.PSStatusDao;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.util.db.WmsDbManager;

import javax.sql.rowset.CachedRowSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class PSStatusDaoImpl implements PSStatusDao {

    private WmsDbManager wmsDbManager;
    private CachedRowSet cachedRowSet;

    public PSStatusDaoImpl(){
        wmsDbManager = new WmsDbManager();
    }

    @Override
    public List<String> checkStatusCreatable(List<String> statusList, List<String> transTypes, String companyCode) throws SQLException {
        List<String> validStatus = new ArrayList<String>();

        String query = String.format("SELECT * FROM PS_Lookup_Valid_Status WHERE TRANSACTION_TYPE IN ('%s') AND COMPANY_CODE  = '%s'",
                StringUtils.join(transTypes,"','"),
                companyCode
        );

        CommonUtil.printLog("Checking Valid Status: " + query);

        cachedRowSet = wmsDbManager.doSelect(query);
        while(cachedRowSet.next()){
            validStatus.add(cachedRowSet.getString("STATUS"));
        }

        if(validStatus.isEmpty()){
            return Collections.emptyList();
        }

        CommonUtil.printLog("Valid status for transType: "+ transTypes.toString() +" is "+validStatus);

        statusList.removeAll(validStatus);

        return statusList;
    }
}
