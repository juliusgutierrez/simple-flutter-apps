package ph.com.sunlife.wms.logger;

import java.io.File;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.PropertyConfigurator;

import ph.com.sunlife.wms.batch.CreateWorkitems;

public class LogInit {

	
	public static void initialize(){
		ResourceBundle props = CreateWorkitems.getCreateWIResourceBundle();
		
		String path = props.getString("log4j.properties.path");
		File file = new File(props.getString("log4j.output.path"));
		PropertyConfigurator.configure(path);
		
	}
	
}
