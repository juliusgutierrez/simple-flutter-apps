package ph.com.sunlife.wms.batch;

import ph.com.sunlife.wms.util.CommonUtil;

import java.util.ResourceBundle;

import ph.com.sunlife.wms.util.BankWorkItemUtil;
import ph.com.sunlife.wms.util.CreateWorkItemsUtil;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.util.PSPrismUtil;
import ph.com.sunlife.wms.util.PSSunSynergyUtil;
import ph.com.sunlife.wms.util.PSVarfuUtil;
import ph.com.sunlife.wms.util.SpecialCsvWorkitemCreation;

public class CreateWorkitems {

	private static ResourceBundle createWIResourceBundle;
	private static ResourceBundle componentPropertiesResourceBundle;
	
	/**
	 * Initialize ResourceBundles for property file access.
	 * @param
	 */
	public CreateWorkitems(){
		createWIResourceBundle = ResourceBundle.getBundle("com.ph.sunlife.component.properties.BatchCreateWorkitems");
		componentPropertiesResourceBundle = ResourceBundle.getBundle("com.ph.sunlife.component.properties.ComponentProperties");
	}
	
	/*
	 * This needs to be enabled when executing in local environment 
	 * and files must be added in the project
	 */
	public static void main(String[] args) {
		
		CommonUtil.printLog("Starting CreateWorkItems...");
		
		String batchAction = args[0];
		String companyCode = args[1];
		
		CommonUtil.printLog("Entering main " + batchAction);
		CommonUtil.printLog("Company Code: " + companyCode);
		
		new CreateWorkitems(); 
		
		try {
			//Create workitem process
			if(PSBatchConstants.REPORTCREATEITEM.equalsIgnoreCase(batchAction)){
				CommonUtil.printLog("Processing " + PSBatchConstants.REPORTCREATEITEM);
				CreateWorkItemsUtil util = new CreateWorkItemsUtil(companyCode);
				util.processItems();
				CommonUtil.printLog("End of Process for " + PSBatchConstants.REPORTCREATEITEM);
			} else if(PSBatchConstants.BANKCREATEITEM.equalsIgnoreCase(batchAction)){
				CommonUtil.printLog("Processing " + PSBatchConstants.BANKCREATEITEM);
				BankWorkItemUtil util = new BankWorkItemUtil();
				util.setCompanyCode(companyCode);
				util.processItems();
				CommonUtil.printLog("End of Process for " + PSBatchConstants.BANKCREATEITEM);
			} else if(PSBatchConstants.SUNSYNERGYBATCH.equalsIgnoreCase(batchAction)){
				//PE and CE sessions are initialized when CEUtil and PEUtil are instantiated
				CommonUtil.printLog("Processing " + PSBatchConstants.SUNSYNERGYBATCH);
				PSSunSynergyUtil util = new PSSunSynergyUtil();
				util.processItems();
				CommonUtil.printLog("End of Process for " + PSBatchConstants.SUNSYNERGYBATCH);
			}else if(PSBatchConstants.VARFUBATCH.equalsIgnoreCase(batchAction)){
				CommonUtil.printLog("Processing " + PSBatchConstants.VARFUBATCH);
				PSVarfuUtil util = new PSVarfuUtil();
				CommonUtil.printLog("Create work item varfu = " + util.processItems());
				CommonUtil.printLog("End of Process for " + PSBatchConstants.VARFUBATCH);
			}else if(PSBatchConstants.PRISMBATCH.equalsIgnoreCase(batchAction)){
				CommonUtil.printLog("Processing " + PSBatchConstants.PRISMBATCH);
				PSPrismUtil util = new PSPrismUtil();
				util.processItems();
				CommonUtil.printLog("End of Process for " + PSBatchConstants.PRISMBATCH);
			} else if(PSBatchConstants.SPECIALLIST.equalsIgnoreCase(batchAction)){
				CommonUtil.printLog("Processing " + PSBatchConstants.SPECIALLIST);
				SpecialCsvWorkitemCreation util = new SpecialCsvWorkitemCreation(companyCode);
				util.processSpecialCsv();
				CommonUtil.printLog("End of Process for " + PSBatchConstants.SPECIALLIST);
			} else {
				//for testing
				PSPrismUtil util = new PSPrismUtil();
				util.processItems();
			}
			
		} catch (Exception e) {

			CommonUtil.printLog("Error encountered in creating worktitems: " + CommonUtil.exceptionStacktraceToString(e));
			e.printStackTrace();
		}
	}
	
	public static ResourceBundle getCreateWIResourceBundle() {
		return createWIResourceBundle;
	}

	public static ResourceBundle getComponentPropertiesResourceBundle() {
		return componentPropertiesResourceBundle;
	}

}