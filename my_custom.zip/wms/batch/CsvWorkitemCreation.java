package ph.com.sunlife.wms.batch;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.Collection;

import org.apache.commons.lang3.StringUtils;

import org.apache.commons.lang3.tuple.Pair;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
import ph.com.sunlife.wms.impl.CreateWorkitemsDaoImpl;
import ph.com.sunlife.wms.util.CommonUtil;
import ph.com.sunlife.wms.util.CEDataProviderExtended;
import ph.com.sunlife.wms.util.CreateWorkItemsUtil;
import ph.com.sunlife.wms.util.CreateWorkItemsHelper;
import ph.com.sunlife.wms.util.CsvFileUtil;
import ph.com.sunlife.wms.util.DateUtil;
import ph.com.sunlife.wms.util.FileUtil;
import ph.com.sunlife.wms.util.NullCheckerUtil;
import ph.com.sunlife.wms.constants.PSBatchConstants;

public class CsvWorkitemCreation {
	
	protected boolean isCheckPolicyCWIHistory = false;
	protected boolean isCheckForSkippedPolicies = false;
	protected boolean isCheckCreationDateFromFile = false;
	
	CreateWorkitemsDaoImpl createWorkitemsDaoImpl = null;
	CreateWorkItemsHelper createWorkItemsHelper = null;
	CreateWorkItemsUtil createWorkItemUtil = null;

	private String transType;
	private File dir;
	private CEDataProvider cedp;
	private ResourceBundle createWIRB;
	private List<String> holidayWeekendList;
	private Map<String, String> policyCWIHistory = new HashMap<String, String>();
	private String currentYear;
	private String bfpReportDate;
	private String className;
	private String companyCode;
	private static int policyIdPos;
	private static String[] fileLineValues;
	private String reportId;
	private String reportDate = DateUtil.getReportDateFormatYYYYMMDD();
	private Map<String, Pair<Integer, Integer>> pSReportColumnMap;
	public CsvWorkitemCreation(String companyCode) {

		this.createWIRB = CreateWorkitems.getCreateWIResourceBundle();
		CreateWorkitems.getComponentPropertiesResourceBundle();
		this.dir = new File(createWIRB.getString("reports.folder.path"));

		bfpReportDate = DateUtil.bfpReportDate;
		className = this.getClass().getSimpleName();
		this.companyCode = companyCode;
		try {
			cedp = new CEDataProviderExtended();
			cedp.init();
			new PEUtilDP();
			createWorkItemsHelper = new CreateWorkItemsHelper();
			createWorkItemUtil = new CreateWorkItemsUtil(companyCode);
			createWorkitemsDaoImpl = new CreateWorkitemsDaoImpl(companyCode);
		} catch (Exception e) {
			CommonUtil.exceptionStacktraceToString(e);
		}
	}
	
	public CsvWorkitemCreation(String companyCode, String dirPath) {
			this(companyCode);
			this.currentYear = DateUtil.getCurrentYear();
			this.dir = new File(createWIRB.getString(dirPath));
	}
	
	public void processItems() throws IOException {
		String methodName = "processItems";

		CommonUtil.printLog("##### Start CsvCreateWorkitemUtil.processItems #####");
		CommonUtil.printLog(className, methodName, "Directory: " + this.dir.getAbsoluteFile());
		CommonUtil.printLog(className, methodName, "BFP Report Date / Current Date: " + bfpReportDate);
		
		int processedFileCount = 0;
		Set<String> csvFiles;
		csvFiles = getCsvFilesFromDir();
		if(NullCheckerUtil.isNullOrEmpty(csvFiles)) {
			CommonUtil.printLog(className, methodName, "No valid csv files from source");
			CommonUtil.printLog(className, methodName, "Exiting CsvCreateWorkitemUtil...");
			return;
		}
		
		Map<String, String> finalReportIdMap = getValidCsvFilesForProcessing(csvFiles);
		
		if(!finalReportIdMap.isEmpty()) {
			
			for (Map.Entry<String, String> entry : finalReportIdMap.entrySet()) {
				transType = entry.getValue();
				reportId = entry.getKey();
				CommonUtil.printLog(className, methodName, "Key: " + reportId + " Value: " + transType);

				createWorkItemUtil.isValidCsvFileForWICreation = true;

				//looking for Policy ID Column Number
				pSReportColumnMap = createWorkItemUtil.mapPairPSReportColumnMap.get(reportId);
				CommonUtil.printLog("Report Column Map: " + pSReportColumnMap);

				Pair<Integer, Integer> pSReportColumnMapPair = pSReportColumnMap.get(PSBatchConstants.POLICY_NO_COL_NAME);
				policyIdPos = pSReportColumnMapPair.getLeft();
				CommonUtil.printLog("POLICY POS: " + policyIdPos);


				if(isCheckPolicyCWIHistory) {
					getPolicyCWIhHistory(reportId, companyCode);
				}
				
				processSLReports(reportId.concat(PSBatchConstants.CSV_FILE_EXTENSION), PSBatchConstants.WORKSITE_SPECIALBILLINGLIST);
				processedFileCount++;
			}
		}else {
			CommonUtil.printLog(className, methodName, "No valid csv files for processing");
		}
		
		CommonUtil.printLog(className, methodName, "Count of valid files for processing : " + finalReportIdMap.size());
		CommonUtil.printLog(className, methodName, "No. of files processed : " + processedFileCount);
		CommonUtil.printLog("##### End CsvCreateWorkitemUtil.processItems #####");
	}

	private void processSLReports(String fileName, String workflowSite) throws IOException {
		String methodName = "processSLReports";
		CommonUtil.printLog("##### Start CsvCreateWorkitemUtil.processSLReports #####");
		CommonUtil.printLog(className, methodName, "Start processing report id: " + reportId);
		String reportFile = reportId.concat(PSBatchConstants.UNDERSCORE).concat(reportDate);

		BufferedWriter statusWriter = null;
		BufferedWriter logWriter = null;
		BufferedReader logReader = null;

		try {
			File file;
			File logFile;
			File statusFile;
			file = FileUtil.createFile(dir.getPath() + "\\" + fileName);
			logFile = FileUtil.createLogTxtFile(reportFile);
			statusFile = FileUtil.createStatusTxtFile(reportFile);

			CommonUtil.printLog(className, methodName, "File : " + file);
			CommonUtil.printLog(className, methodName, "Log File: " + logFile);
			CommonUtil.printLog(className, methodName, "Status File: " + statusFile);
			
			statusWriter = FileUtil.createStatusBW(reportFile, statusFile, false);
			logWriter = FileUtil.createBufferedWriterFile(logFile, true);
			logReader = FileUtil.createBufferedReaderFile(logFile);
			
			int noOfSuccess = 0;
			int noOfFailed = 0;
			int total = 0;
			
			Set<String[]> policyForCreation = getPoliciesForCreationCurrentDay(file, reportId);

			for(String[] rec : policyForCreation) {
				try {
					createWorkItem(rec, reportFile, workflowSite);
					CommonUtil.printLog(className, "processSLReports", "Processing file: " + fileName + ". Record: " + Arrays.toString(rec));
					noOfSuccess++;
				}
				catch(Exception e) {
					CommonUtil.printLog("FAILED : " + rec[policyIdPos] + " - " + e.getMessage());
					statusWriter = FileUtil.writeToFile(statusWriter, statusFile, "FAILED : ".concat(rec[policyIdPos]).concat(" - ").concat(e.getMessage()), true);
					noOfFailed++;
				}
				total++;
				logWriter = FileUtil.writeToFile(logWriter, logFile, Arrays.toString(rec), true);
			}
			
			statusWriter = FileUtil.appendEndingStatus(statusWriter, statusFile, total, noOfSuccess, noOfFailed, true);

			} catch (IOException ioe) {
				CommonUtil.printLog(className, methodName, CommonUtil.exceptionStacktraceToString(ioe));
			} catch (ParseException pe) {
				CommonUtil.printLog(className, methodName, CommonUtil.exceptionStacktraceToString(pe));
			} catch (Exception e) {
				CommonUtil.printLog(className, methodName, CommonUtil.exceptionStacktraceToString(e));
			}finally{

				try{
					if(statusWriter != null)
						statusWriter.close();

					if(logReader != null)
						logReader.close();

					if(logWriter != null)
						logWriter.close();

				}catch(IOException e){
					CommonUtil.exceptionStacktraceToString(e);
				}
			}
		
		CommonUtil.printLog("##### End CsvCreateWorkitemUtil.processSLReports #####");
	}

	private void createWorkItem(String[] rec, String reportFile, String workflowSite) throws Exception{
		try {
			setFileLineValues(rec);
			createWorkItemUtil.createWorkItem(reportFile, StringUtils.EMPTY, transType , workflowSite);
		} catch (Exception e) {
			CommonUtil.exceptionStacktraceToString(e);
			throw new Exception(e.getMessage());
		}
	}

	private Map<String, String> getValidCsvFilesForProcessing(Set<String> set){
		
		String reportIdIn = CsvFileUtil.removeCsvExtension(convertReportCollectionToSqlIn(set));
		Map<String,String> reportIdMap = createWorkItemsHelper.getPSReportTxnMapReportIds(reportIdIn);
		
		if(set.size() != reportIdMap.size()) {
			set.clear();
			set = reportIdMap.keySet();
			reportIdIn = CsvFileUtil.removeCsvExtension(convertReportCollectionToSqlIn(set));
		}
		
		createWorkItemUtil.mapPairPSReportColumnMap = createWorkItemsHelper.getMapPSReportColumnMapByReportIds(reportIdIn);
		
		return reportIdMap;
	}
	
	public String convertReportCollectionToSqlIn(Collection<String> collection) {
		
		StringBuilder sb = new StringBuilder();
		for(String csvFile : collection) {
			sb.append("'").append(csvFile).append("',");
		}
		
		String sqlIn = sb.toString();
		sqlIn = sqlIn.substring(0, sqlIn.length() -1);
		
		return sqlIn;

	}
	
	public Set<String[]> getPoliciesForCreationCurrentDay(File file, String reportId) throws Exception {
		CommonUtil.printLog("##### Start CsvCreateWorkitemUtil.getPoliciesForCreationCurrentDay #####");
		Set<String[]> policySet = new HashSet<String[]>();
		String rec;
		String logMessage = StringUtils.EMPTY;

		BufferedReader br = null;

		try {
			br = FileUtil.createBufferedReaderFile(file);
			CommonUtil.printLog("Header: " + br.readLine()); // removes csv header
			CommonUtil.printLog("##### Checking Creation Date...");
			while ((rec = br.readLine()) != null) {
				String[] records = rec.split(PSBatchConstants.COMMA);

				if (records.length == 0 || policyIdPos > (records.length - 1)) {
					CommonUtil.printLog("Records is empty or bad Policy position: " + policyIdPos + ". Records : " + Arrays.toString(records));
					continue;
				}

				String policy = StringUtils.trim(records[policyIdPos]);

				if (StringUtils.isNotBlank(policy)) {
					if (isCheckCreationDateFromFile) {
						int wiCreateDatePos = createWorkItemUtil.mapPairPSReportColumnMap.get(reportId).get(PSBatchConstants.WORKITEM_CREATE_DATE_COL_NAME).getLeft();


						if (wiCreateDatePos > (records.length - 1)) {
							logMessage = "Bad Workitem Create Date position. Expected: 0 - " + (records.length - 1) + ". Actual: " + wiCreateDatePos;
						} else {
							String creationDate = records[wiCreateDatePos];
							if (StringUtils.isNotBlank(creationDate)) {
								creationDate += PSBatchConstants.DASH.concat(currentYear);
								creationDate = DateUtil.getDateToBFPReportDateFormat(creationDate);
								String lastCreatedDate = policyCWIHistory.get(policy);

								CommonUtil.printLog("Policy: " + policy + ". Creation Date: [" + creationDate + "]."
										+ " Last Creation Date: [" + lastCreatedDate + "]. "
										+ " Creation Date is a holiday? " + holidayWeekendList.contains(creationDate));

								if (checkDate(creationDate, lastCreatedDate)) {
									logMessage = "Policy: " + policy + " okay for WI Creation.";
									policySet.add(records);
								} else {
									logMessage = "Policy: " + policy + " not okay for WI Creation";
								}
							} else {
								logMessage = "Policy: " + policy + ". Do not create. WI Create Date is invalid: " + creationDate;
							}
						}
					} else {
						logMessage = "Policy: " + policy + " okay for WI creation.";
						policySet.add(records);
					}
				} else {
					logMessage = "Policy position " + policyIdPos + " is empty. Records: " + Arrays.toString(records);
				}

				CommonUtil.printLog(logMessage);

			}
		}finally {
			br.close();
		}
		CommonUtil.printLog("##### End CsvCreateWorkitemUtil.getPoliciesForCreationCurrentDay #####");
		return policySet;
	}

	private boolean checkDate(String creationDate, String lastCreatedDate) {
			return (bfpReportDate.equals(creationDate) && !creationDate.equals(lastCreatedDate))
				|| (StringUtils.isBlank(lastCreatedDate) && holidayWeekendList.contains(creationDate));
	}

	public Set<String> getCsvFilesFromDir(){
		String methodName = "getCsvFilesFromDir";
		CommonUtil.printLog(className, methodName, "Start getting valid csv files from source directory: " + dir.getAbsolutePath());
		Set<String> csvFiles = new HashSet<String>();
		String[] dirCsvFiles = dir.list();
		boolean isValidFile = false;
		
		for(String file : dirCsvFiles) {
			isValidFile = false;
			if(CsvFileUtil.isValidCsvFile(file)) {
				isValidFile = true;
				csvFiles.add(file.toUpperCase());
			}
			
			CommonUtil.printLog(className, methodName, file + " is a valid csv file? " + isValidFile);
		}
		
		CommonUtil.printLog(className, methodName, "Done getting valid csv files from source directory: Number of valid files: " + csvFiles.size());
		return csvFiles;
	}
	
	private void getPolicyCWIhHistory(String reportId, String companyCode) {
		this.policyCWIHistory = createWorkitemsDaoImpl.getPolicyWICreationHistory(reportId, companyCode);
	}
	
	protected void getHolidayWeekendList(){
		
		holidayWeekendList = createWorkitemsDaoImpl.getHolidayWeekendList();
		CommonUtil.printLog(className, "getHolidayWeekendList", "Holiday and Weekend list size: " + holidayWeekendList.size());
		
	}
	
	public static void setFileLineValues(String[] values) {
		fileLineValues = values;
	}

	public static String[] getFileLineValues() {
		return fileLineValues;
	}

	public static int getPolicyIdPos(){
		return policyIdPos;
	}
}