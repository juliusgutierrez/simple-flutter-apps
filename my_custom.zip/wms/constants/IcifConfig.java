package ph.com.sunlife.wms.constants;

public class IcifConfig {
    public static final String SP_LIFE_PLAN_BY_POLICY_NUMBER = "GetICIFLifePlanByPolicyNumber";
    public static final String POLICY_NUMBER = "policyNumber";
    public static final String OWNER_CLIENT_NUMBER = "ownerClientNumber";
    public static final String OWNER_ICIF_CLIENT_NUMBER = "ownerIcifClientNumber";
    public static final String OWNER_FIRST_NAME = "ownerFirstName";
    public static final String OWNER_MIDDLE_NAME = "ownerMiddleName";
    public static final String OWNER_LAST_NAME = "ownerLastName";
    public static final String INSURED_CLIENT_NUMBER = "insuredClientNumber";
    public static final String INSURED_ICIF_CLIENT_NUMBER = "insuredIcifClientNumber";
    public static final String INSURED_FIRST_NAME = "insuredFirstName";
    public static final String INSURED_MIDDLE_NAME = "insuredMiddleName";
    public static final String INSURED_LAST_NAME = "insuredLastName";
    public static final String BY_POLICY_NUMBER = "policy_number";
    public static final String LINKED_SERVER = "link_server";
}
