package ph.com.sunlife.wms.constants;

public class PSBatchConstants {

	private PSBatchConstants(){}

	public static final String PS_CREATEWI_BATCH_WF_NAME = "PS CreateWorkitem Workflow";
	public static final String PS_CREATEWI_BATCH_WF_NAME_GF = "PS CreateWorkitem Workflow GF";
	public static final String REPORT_DATE_COL_NAME = "REPORTDATE";
	public static final String POLICY_NO_COL_NAME = "Policy ID";
	public static final String REASON_COL_NAME = "REASON";
	public static final String CHEQUE_NUMBER_COL_NAME = "Cheque Number";
	public static final String GROUP_NAME_COL_NAME = "Group Name";
	public static final String SCAN_DATE_PROP = "ScanDate";
	public static final String PS_TXN_TYPE_PROP = "PSTransType";
	public static final String SOURCE_OF_FUND_PROP = "SourceofFunds";
	public static final String POLICY_NO_PROP = "PolicyNo";
	public static final String STEP_ELEM_POLICY_NO = "Policy_Number";
	public static final String STEP_ELEM_TXN_TYPE = "PS_Transaction_Type";
	public static final String STEP_ELEM_F_SUBJECT = "F_Subject";
	public static final String WORK_OBJ_PS_TXN_NUM = "PS_Transaction_Number";
	public static final String WORK_OBJ_QUEUE_NAME = "QueueName";
	public static final String WORK_OBJ_DISPLAY_STATUS = "DisplayStatus";
	public static final String PPC_ABEYANCE_QUEUE = "PPC Abeyance";
	public static final String INBOX = "Inbox(0)";
	public static final String OS_DISB_TASK = "OS_Disb";
	public static final String BANK_TASK = "bank";
	public static final String PS_F_BATCH_SCANNEDBY_VALUE = "Batch";
	public static final String PS_REPORT_ID = "Report_ID";
	public static final String FILENAME_TOKENS_ALLOWED = "_.";
	public static final String PROP_KEY_PPC_GROUP = "ppcGroup";
	public static final String PROP_VALUE_COL_NAME = "PropValue";

	//DATA_TYPE
	public static final String DATA_TYPE_STRING = "java.lang.String";
	public static final String DATA_TYPE_BIG_DECIMAL = "java.math.BigDecimal";
	public static final String DATA_TYPE_INTEGER = "java.lang.Integer";
	public static final String DATA_TYPE_BOOLEAN = "java.lang.Boolean";
	public static final String DATA_TYPE_DATE = "java.util.Date";

	//Bank Create Workitem
	public static final String PS_F_BANK_UPLOAD = "00-Bank Uploads";
	public static final String PS_F_BANK_COLLECTIONS = "PSBankCollections";
	public static final String PS_BANK_UPLOAD_TRANS_TYPE_PN = "BU-PN";
	public static final String PS_BANK_UPLOAD_TRANS_TYPE_LIFE = "BU-LIFE";
	public static final String PS_BANK_LOGS = "PSBankUploads_log";

	//PS SUN SYNERGY BATCH
	public static final String LOB_LIFE = "LIFE";
	public static final String LOB_PRENEED = "PN-IND";
	public static final String PAYMENT_MODE_ANNUAL = "A";
	public static final String PAYMENT_MODE_SEMI_ANNUAL = "S";
	public static final String PAYMENT_MODE_QUARTERLY = "Q";
	public static final String TRANS_TYPE_LIFE = "RD-MF-LIFE";
	public static final String TRANS_TYPE_PRENEED = "RD-MF-PN";
	public static final String PS_NDISB_CATEGORY = "NDISB";
	public static final String PS_STEPELEM_ATTACHMENT_PARAM = "PSFolder";
	public static final String PS_SUN_SYNERGY_LOGS = "PSSunSynergy_log";

	public static final String REPORT_ID_CSBM9209 = "CSBM9209";
	public static final String REPORT_ID_CSBM9586 = "CSBM9586";
	public static final String REPORT_ID_CSBM9441 = "CSBM9441";
	public static final String BAD_ADD_REASON = "BAD ADD. INDICATOR IN MAILING OR OWNER CLIENT = Y";

	//Type of batch to process
	public static final String REPORTCREATEITEM = "reportCreateItem";
	public static final String BANKCREATEITEM = "bankCreateItem";
	public static final String SUNSYNERGYBATCH = "sunSynergyBatch";
	public static final String VARFUBATCH = "varfuBatch";
	public static final String PRISMBATCH = "prismBatch";
	public static final String SPECIALLIST = "specialList";
	public static final String WMSPARAM_CIF_LINKSERVER = "CIF Server";

	// Policy prefix used for special conditions
	public static final String POLICY_PREFIX_CP = "08";
	public static final String POLICY_PREFIX_GF = "28";

	// Constants for fields in wmsParam table
	public static final String WMSPARAM_PPC_ROBOTID = "ppcRobotID";

	// MR-WF-17-00120 PS Batch Create Work item for Bank Upload
	public static final String IS_ACTIVE = "1";
	public static final String PS_COMPANY_SLOCPI = "CP";
	public static final String PS_COMPANY_SLGFI = "GF";

	// MR-GF-17-0020 Special List
	public static final String WORKSITE_SPECIALBILLINGLIST= "BS";
	public static final String LOG_FOLDER_PATH = "log.folder.path";
	public static final String STATUS_FOLDER_PATH = "status.folder.path";
	public static final String PROCESSED_FOLDER_PATH = "processed.folder.path";
	public static final String SPECIAL_CSV_FILE_PATH = "special.folder.path";
	public static final String MKDIRS_MESSAGE = "File %1$s: %2$s is not a directory. Creating a directory..";
	public static final String PS_F_COMPANY_CODE = "CompanyCode";
	public static final String PS_COMPANY_CODE = "Company_Code";
	public static final String UNDERSCORE = "_";
	public static final String COMMA = ",";
	public static final String SPACE = " ";
	public static final String DASH = "-";
	public static final String LOG_TXT = "_log.txt";
	public static final String STATUS_TXT = "_status.txt";
	public static final String CSV_FILE_EXTENSION = ".CSV";

	public static final String BATCH = "BATCH";

	public static final String WORKITEM_CREATE_DATE_COL_NAME = "Workitem Create Date";

	public static final String DIGITS_REGEX = "[0-9]+";
}
