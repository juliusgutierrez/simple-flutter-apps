package ph.com.sunlife.wms.dao;

import ph.com.sunlife.wms.dto.LifeDTO;

import java.util.List;

public interface IcifDAO {

    public List<LifeDTO> getLifePlanByPolicyNumber(String policyNumber, String linkedServer);
}