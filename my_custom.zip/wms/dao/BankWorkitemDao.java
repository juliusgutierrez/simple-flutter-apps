package ph.com.sunlife.wms.dao;

import java.sql.SQLException;
import java.util.List;
import ph.com.sunlife.wms.dto.PSBankUploadListDTO;

public interface BankWorkitemDao {
	
	public List<PSBankUploadListDTO> getPSBankUploadList(String companyCode) throws SQLException;

}