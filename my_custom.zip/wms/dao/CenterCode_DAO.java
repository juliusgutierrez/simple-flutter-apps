/*
 * NBClass.java
 *
 * Created on June 5, 2006, 1:06 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package ph.com.sunlife.wms.dao;


import ph.com.sunlife.wms.dto.CenterCodesDTO;
import ph.com.sunlife.wms.util.db.DBManager;

/**
 *
 * @author pc24
 */
public class CenterCode_DAO {
    DBManager dbmanager =  new DBManager();
    /** Creates a new instance of NBClass */
    public CenterCode_DAO() {
    }
    public CenterCodesDTO getCenterCodesDTO(){
    	return getCenterCodesDTO("");
    }
    
    public CenterCodesDTO getCenterCodesDTO( String whereClause ){
    	StringBuffer sb = new StringBuffer();
    	CenterCodesDTO dto = null;
		DBManager dbConn = new DBManager();
		
		String[] columnNames = { 
				"CC_ID",
				"CC_Name",
				"CC_Desc",
				"CC_AutoIdx",
				"CC_CanEncode",
				"CC_ViewImage",
				"CC_ZoomZone",
				"CC_Active",
				"CC_CRE_User",
				"CC_CRE_Date",
				"CC_UPD_User",
				"CC_UPD_Date",
				"CC_AbbrevName"
				};

		String[] dataType = { 
				"java.lang.String",
				"java.lang.String",
				"java.lang.String",
				"java.lang.Boolean",
				"java.lang.Boolean",
				"java.lang.Boolean",
				"java.lang.Boolean",
				"java.lang.Boolean",
				"java.lang.String",
				"java.util.Date",
				"java.lang.String",
				"java.util.Date",
				"java.lang.String"
		};
		
		String className = "ph.com.sunlife.wms.dto.CenterCodesDTO";
		
		StringBuffer query = new StringBuffer();
		query.append("SELECT "); 
		for (int i = 0; i < columnNames.length; i++) {
			if (i < columnNames.length - 1) {
				query.append(columnNames[i]);
				query.append(", ");
			} else {
				query.append(columnNames[i]);
			}
		}
		query.append(" FROM CenterCodes ");

		if (whereClause != null && !whereClause.equals("")) {
			query.append(whereClause);
		}
		
		dto = (CenterCodesDTO)dbConn.doSelect(className, columnNames, dataType, query.toString());
        return dto;
    }
    
    
}
//fix hubccnbo