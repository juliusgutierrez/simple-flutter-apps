package ph.com.sunlife.wms.dao;

import java.sql.SQLException;
import java.util.List;
import ph.com.sunlife.wms.dto.WMSParam;

public interface WmsParamDAO {

	public String getWmsParamValue(String paramField) throws SQLException;
	
	public String getWmsParamValueWithCompanyCode(String paramField, String companyCode);
	
	public List <WMSParam> getWmsParamList(String paramField) throws SQLException;
	
}