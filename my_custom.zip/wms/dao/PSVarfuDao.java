package ph.com.sunlife.wms.dao;

import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PSVarfuListDTO;
import ph.com.sunlife.wms.dto.WMSParam;

public interface PSVarfuDao {
	public WMSParam getBFPReportDate();
	public PSVarfuListDTO getPSVarfuList(String whereClause);
	public ILifePlanViewDTO getPolicyDetails(String whereClause);
}
