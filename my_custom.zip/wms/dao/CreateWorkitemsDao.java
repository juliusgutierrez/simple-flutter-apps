package ph.com.sunlife.wms.dao;

import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PSOrderReqtsDTO;
import ph.com.sunlife.wms.dto.PSReportColumnMapDTO;
import ph.com.sunlife.wms.dto.PSReportColumnValuesDTO;
import ph.com.sunlife.wms.dto.PSReportTxnMapDTO;

import java.sql.SQLException;
import java.util.List;

public interface CreateWorkitemsDao {

	PSReportTxnMapDTO getPSReportTxnMapDTO(String whereClause);

	PSReportColumnMapDTO getPSReportColumnMapDTO(String whereClause);

	PSReportColumnMapDTO getColumnMap(String reportId, String columnName);

	PSReportColumnMapDTO getPSReportColumnMapDTO();

	PSReportTxnMapDTO getPSReportTxnMapDTO();

	PSOrderReqtsDTO getPSOrderReqtsDTO(String whereClause);
	
	public ILifePlanViewDTO getLifePlanViewByPolicyNo(String whereClause);
	
	boolean insertPSReportColumnValuesDTO(PSReportColumnValuesDTO dto);

	List<String> getEnterInfoReports() throws SQLException, Exception;
	
	/**
	 * Method to fetch robotID in DB - wmsParam table
	 * @return userId
	 */
	public String getRoboID();

	String getWorkflowSite(String transType) throws SQLException;

	String getCCUnit(String transSite) throws SQLException;
}
