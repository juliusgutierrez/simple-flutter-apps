package ph.com.sunlife.wms.dao;

import java.util.Date;
import java.util.List;

import ph.com.sunlife.wms.dto.DataAccessInterface;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PNeedPlanViewDTO;
import ph.com.sunlife.wms.dto.PSSunSynergyListDTO;
import ph.com.sunlife.wms.dto.SunSynergyDTO;

public interface PSSunSynergyDao {
	public PSSunSynergyListDTO getPSSunSynergyListDTO();
	public PSSunSynergyListDTO getPSSunSynergyListDTO(String whereClause);
	public PSSunSynergyListDTO getPSSunSynergyList(Date BFPReportDate, String paymentMode);
	public PNeedPlanViewDTO getPNeedPlanViewDTO(String whereClause);
	public PNeedPlanViewDTO getPNeedPlanViewDTO();
	public ILifePlanViewDTO getILifePlanViewDTO(String whereClause);
	public ILifePlanViewDTO getILifePlanViewDTO();
	public SunSynergyDTO getPolicyDetails(List policiesStr, String lob);
	public boolean updateLastCreateWIDate(String policyNumber, Date lastCreateWIDate );
}

