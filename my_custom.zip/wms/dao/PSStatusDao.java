package ph.com.sunlife.wms.dao;

import java.sql.SQLException;
import java.util.List;

public interface PSStatusDao {
    List<String> checkStatusCreatable(List<String> statusList, List<String> transTypes, String companyCode) throws SQLException;
}
