package ph.com.sunlife.wms.dao;

import ph.com.sunlife.wms.dto.PrismCreateWorkItemDTO;

public interface PrismCreateWorkItemDAO {
	
	public PrismCreateWorkItemDTO getPrismIndividualPlanDTO(String planNumber);

}
