// PS_TRANSACTION_TYPES - Andre Ceasar Dacanay
package ph.com.sunlife.wms.dao;

import java.sql.SQLException;

import ph.com.sunlife.wms.dto.PSTransactionTypesDTO;

public interface PSTransactionTypesDAO extends BaseDAO {
	
	//stored procedure name  - dbo.ps_getTranTypes - table name - PS_TRANSACTION_TYPES
    public PSTransactionTypesDTO getTranTypes() throws SQLException;
    
    public PSTransactionTypesDTO getPSTransactionTypesDTO();
    
    public PSTransactionTypesDTO getPSTransactionTypesDTO(String whereClause);

}