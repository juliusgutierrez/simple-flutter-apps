package ph.com.sunlife.wms.util;

import org.apache.commons.lang3.StringUtils;
import ph.com.sunlife.wms.dao.WmsParamDAO;
import ph.com.sunlife.wms.impl.WmsParamDAOImpl;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Calendar;

public class WmsParamUtil {

	public static Calendar cal = Calendar.getInstance();

	public static String getParamValueUsingParamFieldAndCompanyCode(String paramField,String companyCode){
		
		WmsParamDAO paramDAO = null;
		
		if(paramField == null || companyCode == null){
			throw new IllegalArgumentException("Param Field or Company Code cannot be null");
		}
		
		paramDAO = new WmsParamDAOImpl();

		return paramDAO.getWmsParamValueWithCompanyCode(paramField, companyCode);
	}

	public static String getBFPReportDate() {
		WmsParamDAO paramDAO = new WmsParamDAOImpl();
		String currentDate = null;
		try {
			currentDate = paramDAO.getWmsParamValue("BFPReportDate");
			cal.setTime(DateUtil.parseDate(currentDate));
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return StringUtils.trim(currentDate);
	}
}
