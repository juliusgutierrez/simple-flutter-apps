/*
 * vsantos
 * CEDataProvider extended to overload getFNObjectByPath and pass company code
 */
package ph.com.sunlife.wms.util;

import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.ObjectFactory;
import com.filenet.wcm.api.ObjectStore;
import com.filenet.wcm.api.Session;
import com.ph.sunlife.component.company.util.CompanyWMSPropsUtil;

import ph.com.sunlife.wms.api.WmsParameters;
import ph.com.sunlife.wms.dp.CEDataProvider;

public class CEDataProviderExtended extends CEDataProvider {

	public CEDataProviderExtended() throws Exception {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public BaseObject getFNObjectByPath(int objType, String pathAndFileName, String companyCode) throws Exception{
		ObjectStore objectStore = ObjectFactory.getObjectStore(CompanyWMSPropsUtil.getWMSObjectStoreName(companyCode), this.getSession());
		BaseObject bos = (BaseObject)objectStore.getObject(objType, pathAndFileName);
		return bos;
	}
		
}
