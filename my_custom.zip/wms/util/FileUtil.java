package ph.com.sunlife.wms.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;

import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.constants.PSBatchConstants;

/**
 * 
 * @author p344
 * This class is for generic file util
 */
public class FileUtil {
	private static final ResourceBundle createWIRB = CreateWorkitems.getCreateWIResourceBundle();

	protected FileUtil(){
	}

	public static File createLogDirPath() throws Exception {

		return createDirectory(PSBatchConstants.LOG_FOLDER_PATH);
		
	}
	
	public static File createStatusFilePath() throws Exception {
		
		return createDirectory(PSBatchConstants.STATUS_FOLDER_PATH);
		
	}
	
	public static File createDirectory(String path) throws Exception {

		File file = createFile(path);

		if(file == null && !file.isDirectory()) {
			throw new Exception("Encountered exception while creating ["+path+"] directory.");
		}

		try {
			file.mkdirs();
		} catch (Exception e) {
			throw new Exception("Encountered exception while creating ["+path+"] directory.");
		}
		return file;
	}
	
	public static File createLogTxtFile(String reportFile) throws Exception {
		

		return createFileIfNotExist(new File(createLogDirPath(), reportFile.concat(PSBatchConstants.LOG_TXT)));
		
	}
	
	public static File createStatusTxtFile(String reportFile) throws Exception {

		return createFileIfNotExist(new File(createStatusFilePath(), reportFile.concat(PSBatchConstants.STATUS_TXT)));
	}
	
	public static File createFile(String filePath){
		
		File file = null;
		
		try {
			file = new File(filePath);
		}catch (Exception e) {
			CommonUtil.printLog("Encountered error while creating new file: ["+filePath+"]");
		}
		return file;
	}

	public static BufferedWriter createStatusBW(String reportFile, File file, boolean isAppendAtEnd) throws IOException {
		
		BufferedWriter bw = createBufferedWriterFile(file, isAppendAtEnd);
		bw.write("Status report for " + reportFile);
		bw.newLine();
		bw.newLine();
		bw.close();
		return bw;
		
	}
	
	public static BufferedWriter appendEndingStatus(BufferedWriter writer, File file, int total, int noOfSuccess, int noOfFailed, boolean isAppendAtEnd) throws IOException {
		

		try {
			writer = new BufferedWriter(new FileWriter(file, isAppendAtEnd));
			writer.newLine();
			writer.newLine();
			writer.write("Total no. of records : "+ total);
			writer.newLine();
			writer.write("No. of created workitems : "+ noOfSuccess);
			writer.newLine();
			writer.write("No. of failed workitems : "+ noOfFailed);
			writer.newLine();
			writer.close();
		} catch (IOException ioe) {
			CommonUtil.printLog("An IOException was encounterd during creation of new file with error message ["+ioe.getMessage()+"]");
			throw new IOException(ioe);
		} finally {
			if(writer != null)
				writer.close();
		}
		
		return writer;
		
	}
	
	public static BufferedWriter createBufferedWriterFile(File file, boolean isAppendAtEnd) throws IOException {
		
		try {
			return new BufferedWriter(new FileWriter(file, isAppendAtEnd));
			
		} catch (IOException ioe) {
			CommonUtil.printLog("An IOException was encountered during creation of new file with error message ["+ioe.getMessage()+"]");
			throw new IOException(ioe);
		}
	}
	
	public static BufferedWriter writeToFile(BufferedWriter bw, File file, String fileContent, boolean isAppendAtEnd) throws IOException {

		try {
			bw = new BufferedWriter(new FileWriter(file, isAppendAtEnd));
			bw.write(fileContent);
			bw.newLine();
			bw.close();
			return bw;
			
		} catch (IOException ioe) {
			CommonUtil.printLog("An IOException was encounterd during creation of new file with error message ["+ioe.getMessage()+"]");
			throw new IOException(ioe);
		} finally {
			if(bw != null)
				bw.close();
		}
	}
	
	public static BufferedReader createBufferedReaderFile(File file) throws FileNotFoundException {
		
		try {
			return new BufferedReader(new FileReader(file));
			
		} catch (FileNotFoundException fnfe) {
			CommonUtil.printLog("A FileNotFoundException was encounterd during reading of file with error message ["+fnfe.getMessage()+"]");
			throw new FileNotFoundException();
		}
	}
	
	public static File createFileIfNotExist(File file) {
		
		if(!file.exists()) {
			try {
				if(file.createNewFile())
					CommonUtil.printLog("File "+file.getName()+" is created");
			} catch (IOException ioe) {
				CommonUtil.printLog("Encountered IOException while creating file: ["+file+"]");
				ioe.printStackTrace();
			} catch (Exception e) {
				CommonUtil.printLog("Encountered Exception while creating file: ["+file+"]");
				e.printStackTrace();
			}
		}
		return file;
	}
	
	public static String extractReportId(String reportFile, String marker){
		
		if(StringUtils.isNotBlank(reportFile)){
			return reportFile.toUpperCase().substring(0, reportFile.indexOf(marker));
		}	
		return StringUtils.EMPTY;
	}
}
