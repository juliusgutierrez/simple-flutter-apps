package ph.com.sunlife.wms.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.constants.wmsconstants;
import ph.com.sunlife.wms.dao.BankWorkitemDao;
import ph.com.sunlife.wms.dao.WmsParamDAO;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
import ph.com.sunlife.wms.dto.PSBankUploadListDTO;
import ph.com.sunlife.wms.impl.BankWorkitemDaoImpl;
import ph.com.sunlife.wms.impl.WmsParamDAOImpl;
import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.Folder;
import com.filenet.wcm.api.PropertyNotFoundException;
import com.filenet.wcm.api.UniquenessConstraintException;
import filenet.vw.api.VWAttachment;
import filenet.vw.api.VWException;

public class BankWorkItemUtil {
	
	private ResourceBundle createWIRB;
	private BankWorkitemDao bankWorkItemDao;
	private WmsParamDAO wmsParamDao;
	private CEDataProvider cedp;
	private PEUtilDP pedp;
	
	private static String PS_F_Company_Code = "CompanyCode"; //create folder properties
	private static String PS_Company_Code = "Company_Code"; //pedp create workitem
	private String companyCode;

	public BankWorkItemUtil(){
		createWIRB = CreateWorkitems.getCreateWIResourceBundle();
		bankWorkItemDao = new BankWorkitemDaoImpl();
		wmsParamDao = new WmsParamDAOImpl();
		
		try {
			cedp = new CEDataProvider();
			cedp.init();
			pedp = new PEUtilDP();
		} catch (Exception e) {
			CommonUtil.printLog("BankWorkItemUtil","", "Exception: " + CommonUtil.exceptionStacktraceToString(e));
		}
		
	}
	
	public boolean processItems() {
		CommonUtil.printLog("Inside BankWorkItemUtil.processItems...");
		try{
			// set up Dtos for value retrieval
			List<PSBankUploadListDTO> bankUploadList = bankWorkItemDao.getPSBankUploadList(companyCode);
			String wmsParamValue = wmsParamDao.getWmsParamValue("BFPReportDate");
			
			CommonUtil.printLog("BankWorkItemUtil", "processItems", "bankUploadList: " + bankUploadList);
			CommonUtil.printLog("BankWorkItemUtil", "processItems", "wmsParamValue: " + wmsParamValue);
			
			File logDir = new File(createWIRB.getString("status.folder.path"));
	
			if(!logDir.isDirectory()){
				logDir.mkdirs();
			}
			
			File logFile = new File(logDir, PSBatchConstants.PS_BANK_LOGS + "_" + wmsParamValue + ".txt"  );
			BufferedWriter logWriter = null;
	
			logWriter = new BufferedWriter(new FileWriter(logFile, true));
			logWriter.write("Status report for bank uploads - " + wmsParamValue);
			logWriter.newLine();
			logWriter.newLine();
			logWriter.close();
			
			int total = 0;
			int noOfSuccess = 0;
			int noOfFailed = 0;
			
			String lob = null;
			String bankShortName = null;
			boolean isLife, isPreneed;
			Date reportDate = DateUtil.parseDate(wmsParamValue);
			boolean isWkEnd = DateUtil.isWeekend(reportDate);
			
			for(PSBankUploadListDTO psBankUploadDto: bankUploadList){
				
				if(!isWkEnd || (isWkEnd && psBankUploadDto.getRunOnWeekEnds())){
					bankShortName = psBankUploadDto.getBankShortName();
					isLife = psBankUploadDto.getIsLife();
					isPreneed = psBankUploadDto.getIsPreneed();
					
					logWriter = new BufferedWriter(new FileWriter(logFile, true));
						
					try{
						if(isLife){
							lob = PSBatchConstants.LOB_LIFE;
							logWriter.write("Processing... " + bankShortName + " - " + lob);
							CommonUtil.printLog("BankWorkItemUtil", "processItems", "Processing... " + bankShortName + " - " + lob);
							createWorkItem(psBankUploadDto, lob);
						}
						
						if(isPreneed){
							lob = PSBatchConstants.LOB_PRENEED;
							logWriter.write("Processing... " + bankShortName + " - " + lob);
							CommonUtil.printLog("BankWorkItemUtil", "processItems", "Processing... " + bankShortName + " - " + lob);
							createWorkItem(psBankUploadDto, lob);
						}
						
						logWriter.write("Success!");
						CommonUtil.printLog("BankWorkItemUtil", "processItems", "SUCCESS!");
						noOfSuccess++;
					}catch(Exception e){
						logWriter.write("Failed! - " + e.getMessage());
						CommonUtil.printLog("BankWorkItemUtil", "processItems", "Failed! - " + e.getMessage());
						noOfFailed++;
					}
						logWriter.newLine();
						logWriter.close();
						total++;
				} // end if
			}// end for
			logWriter = new BufferedWriter(new FileWriter(logFile, true));
			logWriter.newLine();
			logWriter.write("Total number of bank transactions run: " + total);
			logWriter.newLine();
			logWriter.write("No. of created workitems : " + noOfSuccess);
			logWriter.newLine();
			logWriter.write("No. of failed workitems : " + noOfFailed);
			logWriter.newLine();
			
			if(noOfFailed > 0){
				logWriter.write("Please check Bank Details");
			}
			
			logWriter.close();
			
		}catch(IOException e){
			CommonUtil.printLog("BankWorkItemUtil", "processItems", "IOException: " + CommonUtil.exceptionStacktraceToString(e));
		}catch(Exception ex){
			CommonUtil.printLog("BankWorkItemUtil", "processItems", "Exception" + CommonUtil.exceptionStacktraceToString(ex));
		}
		
		CommonUtil.printLog("BankWorkItemUtil", "processItems", "Bank Uploads DONE");
		CommonUtil.printLog("Leaving BankWorkItemUtil.processItems...");
		return true;
	}
	
	private void createWorkItem(PSBankUploadListDTO dto, String lob) throws Exception{
		CommonUtil.printLog("Inside BankWorkItemUtil.createWorkItem...");
		
		Calendar cal = Calendar.getInstance();
		Folder folder = null;
		HashMap hm = new HashMap();
		String wmsParamValue = wmsParamDao.getWmsParamValue("BFPReportDate");
		Date date = DateUtil.parseDate(wmsParamValue); // simplified to a method

		cal.setTime(date);
		cal.add(Calendar.DATE, 1);

		String reportDate = DateUtil.formatDate(cal.getTime());
		String txnType = (lob.equalsIgnoreCase(PSBatchConstants.LOB_LIFE)) ? 
				PSBatchConstants.PS_BANK_UPLOAD_TRANS_TYPE_LIFE:PSBatchConstants.PS_BANK_UPLOAD_TRANS_TYPE_PN;
	
		String folderName = dto.getBankShortName() + "_" + txnType + "_" + reportDate;
		
		CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Report Date: " + reportDate);
		CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Scan Date(fr: BFPReportDate): " + date);
		
		hm.put(wmsconstants.PS_F_ScanDate, date);
		hm.put(wmsconstants.PS_F_SourceOfFunds, dto.getBankShortName());
		hm.put(wmsconstants.PS_F_LOB, lob);
		hm.put(wmsconstants.PS_F_PSTransType, txnType);
		hm.put(wmsconstants.PS_F_ProcessStatus, "Created");
		hm.put(PS_F_Company_Code, this.companyCode);
		
		CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Getting compcode in resource bundle: " + this.companyCode);
		CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Folder name: " + folderName.toString());

		Folder newFolder = null;
		
		try{
			folder = (Folder) cedp.getFNObjectByPath(BaseObject.TYPE_FOLDER, "/" + wmsconstants.PS_F_POLICY_SERVICING 
					+ "/" + PSBatchConstants.PS_F_BANK_UPLOAD);
			
			newFolder = folder.addSubFolder(folderName.toString(), wmsconstants.PS_F_Tran_Folder, cedp.createProperties(hm), null);
			launchWorkflow(newFolder);
		} catch (UniquenessConstraintException e) {
			CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Folder Name : " + folderName.toString() + " is not unique");
			e.printStackTrace(System.out);
			throw new Exception("Folder Name : "+folderName.toString()+" is not unique");
		} catch (Exception e){
			CommonUtil.printLog("BankWorkItemUtil", "createWorkItem", "Exception: " + CommonUtil.exceptionStacktraceToString(e));
			throw new Exception(e.getMessage());
		}
		
		CommonUtil.printLog("Leaving BankWorkItemUtil.createWorkItem...");
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected void launchWorkflow(Folder folder) {
		HashMap stepElemParams = new HashMap();
		Date scanDate = new Date();
		VWAttachment att = null;
		String txnType = "";
		String lob = "";
		String bankShortName = "";
		try {
			CreateWorkItemsUtil util = new CreateWorkItemsUtil(this.companyCode);
			att = util.convertFolderToAttachment(folder);
			bankShortName = (String) folder.getPropertyValue(wmsconstants.PS_F_SourceOfFunds);
			scanDate = (Date) folder.getPropertyValue(wmsconstants.PS_F_ScanDate);
			lob = (String) folder.getPropertyValue(wmsconstants.PS_F_LOB);
			txnType = (String) folder.getPropertyValue(wmsconstants.PS_F_PSTransType);
		} catch (PropertyNotFoundException e) {
			CommonUtil.printLog("BankWorkItem", "launchWorkflow", "PropertyNotFoundException: " + CommonUtil.exceptionStacktraceToString(e));
		} catch (VWException e){
			CommonUtil.printLog("BankWorkItem", "launchWorkflow", "VWException: " + CommonUtil.exceptionStacktraceToString(e));
		} catch (IOException e) {
			CommonUtil.printLog("BankWorkItem", "launchWorkflow", "IOException: " + CommonUtil.exceptionStacktraceToString(e));
		}

		CommonUtil.printLog("BankWorkItem", "launchWorkflow", "bankShortName : "+bankShortName);
		CommonUtil.printLog("BankWorkItem", "launchWorkflow", "txnType : "+txnType);
		CommonUtil.printLog("BankWorkItem", "launchWorkflow", "scanDate : "+scanDate);
		CommonUtil.printLog("BankWorkItem", "launchWorkflow", "lob : "+lob);
		
		
		stepElemParams.put(wmsconstants.PS_Folder, att);
		stepElemParams.put(wmsconstants.PS_LINE_OF_BUSINESS, lob);
		stepElemParams.put(wmsconstants.PS_CC_AbbrevName, wmsconstants.WORK_FLOW_SITE_PPA);
		stepElemParams.put(wmsconstants.PS_CustomerCenterID, "PA" );
		stepElemParams.put(wmsconstants.PS_BankName, bankShortName);
		stepElemParams.put(wmsconstants.PS_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE);
		stepElemParams.put(wmsconstants.PS_TRANSACTION_TYPE, txnType);
		stepElemParams.put(wmsconstants.PS_ScanDate, scanDate);
		stepElemParams.put(wmsconstants.PS_MULTIPLE_TRANSACTION, new Boolean(false));
		
		try {
			stepElemParams.put(PS_Company_Code, folder.getPropertyValue(PS_F_Company_Code));
		} catch (PropertyNotFoundException e) {
			// TODO Auto-generated catch block
			CommonUtil.printLog("BankWorkItem", "launchWorkflow", "error in setting stepelement company code: " + CommonUtil.exceptionStacktraceToString(e));
		}
		CommonUtil.printLog("BankWorkItem", "launchWorkflow", "isMulti " + stepElemParams.get(wmsconstants.PS_MULTIPLE_TRANSACTION));	
		
		if(PSBatchConstants.PS_COMPANY_SLGFI.equalsIgnoreCase(this.companyCode)){
			pedp.createWorkItem(stepElemParams, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME_GF, null);
		}else if(PSBatchConstants.PS_COMPANY_SLOCPI.equalsIgnoreCase(this.companyCode)){
			pedp.createWorkItem(stepElemParams, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME, null);
		}
	}

	public void setCompanyCode(String companyCode) {
		// TODO Auto-generated method stub
		this.companyCode = companyCode;
		
	}
}

