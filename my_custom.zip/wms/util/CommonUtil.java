package ph.com.sunlife.wms.util;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Calendar;

public class CommonUtil {
	
	private static Calendar calendar = Calendar.getInstance();

	public static String exceptionStacktraceToString(Exception e) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		PrintStream ps = new PrintStream(baos);
		e.printStackTrace(ps);
		ps.close();
		return baos.toString();
	}
	
	public static void printLog(String className, String methodName, String message){
		System.out.println(calendar.getTime() + ": " + className + "." + methodName + ": " + message);
	}
	
	public static void printLog(String message){
		System.out.println(calendar.getTime() + ": " + message);
	}
}
