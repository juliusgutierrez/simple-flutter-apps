package ph.com.sunlife.wms.util;

import com.filenet.wcm.api.BadReferenceException;
import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.Folder;
import com.filenet.wcm.api.UniquenessConstraintException;
import com.ph.sunlife.component.company.util.CompanyWMSPropsUtil;
import filenet.vw.api.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;
import org.apache.commons.io.FileUtils;
import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.batch.CsvWorkitemCreation;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.constants.wmsconstants;
import ph.com.sunlife.wms.dao.*;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
import ph.com.sunlife.wms.dto.*;
import ph.com.sunlife.wms.impl.*;

import java.io.*;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ph.com.sunlife.wms.util.CommonUtil.exceptionStacktraceToString;

public class CreateWorkItemsUtil {
    private static final String CLASS_NAME = "CreateWorkItemsUtil";

    private static final String LOG_FOLDER_PATH = "log.folder.path";
    private static final String STATUS_FOLDER_PATH = "status.folder.path";
    private static final String PROCESSED_FOLDER_PATH = "processed.folder.path";
    private static final String PAYMENT_CODE = "PAYM";
    private static final String MKDIRS_MESSAGE = "File %1$s: %2$s is not a directory. Creating a directory..";
    private static final String FILENAME_PATTERN = "^([A-Z0-9])+_([A-Z0-9]){8,9}(_([0-9])+)*$";
    private static final String PS_F_Company_Code = "CompanyCode"; //create folder properties
    private static final String PS_Company_Code = "Company_Code"; //pedp create workitem
    private static final ResourceBundle rb = ResourceBundle.getBundle("ph.com.sunlife.wms.properties.PSBatchCreateWorkitems");
    private final ResourceBundle createWIRB;
    //private Logger logger  = Logger.getLogger(CreateWorkItemsUtil.class);
    private final File dir;
    private final File buStatDir;
    private final CreateWorkitemsDao createWorkitemsDao;
    CreateWorkItemsHelper createWorkItemsHelper = null;
    private CEDataProvider cedp;
    private PEUtilDP pedp;
    private String companyCode = "";
    private Map<String, String> listOfPSReportColumnMap = new HashMap<String, String>();
    private String linkServer = null;
    private Map<String, String> ICIF_LINKED_SERVER;
    private List<String> transTypes = null;

    public Map <String, Map<String, Pair<Integer, Integer>>> mapPairPSReportColumnMap = new HashMap <String, Map<String, Pair<Integer, Integer>>>();
    private List<String> reportsForStatusChecking = new ArrayList<String>();
    public boolean isValidCsvFileForWICreation = false;

    private Pattern patternDigits = Pattern.compile(PSBatchConstants.DIGITS_REGEX);

    private List<String> enterInfoReports;
    private boolean isEnterInfo;

    public CreateWorkItemsUtil(String companyCode) throws IOException {

        this.createWIRB = CreateWorkitems.getCreateWIResourceBundle();
        CreateWorkitems.getComponentPropertiesResourceBundle();
        this.companyCode = companyCode;

        this.dir = new File(createWIRB.getString("reports.folder.path"));
        this.buStatDir = new File(createWIRB.getString("bu.status.folder.path"));
        createWorkitemsDao = new CreateWorkitemsDaoImpl(companyCode);

        try {
            createWorkItemsHelper = new CreateWorkItemsHelper();
            listOfPSReportColumnMap = createWorkItemsHelper.getlistOfPSReportColumnMapby();

            enterInfoReports = createWorkitemsDao.getEnterInfoReports();
            reportsForStatusChecking = createWorkItemsHelper.getReportsForStatusChecking();

            cedp = new CEDataProviderExtended();
            cedp.init();
            pedp = new PEUtilDP();
        } catch (Exception e) {
            CommonUtil.printLog(CLASS_NAME, "CreateWorkItemsUtil", "Exception: " + CommonUtil.exceptionStacktraceToString(e));
        }

        if (null == ICIF_LINKED_SERVER) {
            ICIF_LINKED_SERVER = new HashMap<String, String>();
            linkServer = WmsParamUtil.getParamValueUsingParamFieldAndCompanyCode(PSBatchConstants.WMSPARAM_CIF_LINKSERVER, companyCode);
            ICIF_LINKED_SERVER.put(PSBatchConstants.PS_COMPANY_SLOCPI, linkServer);
        }
    }

    public void processItems() {
        System.out.println("##### Inside CreateWorkItemsUtil.processItems #####");
        //1. Get the report ids in Ps_Report_Txn_Map table
        Map<String, String> listOfReportId = createWorkItemsHelper.getPSReportTxnMap(companyCode);
        //loop a Map
        for (Map.Entry<String, String> entry : listOfReportId.entrySet()) {
            System.out.println("Key: " + entry.getKey() + " ============== Value : " + entry.getValue());
        }

        System.out.println("Searching " + dir.getPath());

        String[] files = dir.list();

        String ppa = createWIRB.getString("ppa.reports");
        String ppc = createWIRB.getString("ppc.reports");
        System.out.println("ppa.reports " + ppa);
        System.out.println("ppc.reports " + ppc);
        System.out.println("No. of files in directory : " + files.length);

        int fileCnt = 0;

        if (files != null && files.length > 0) {//make sure that there is a file in the directory
            for (int i = 0; i < files.length; i++) {
                System.out.println("Files[" + i + "] : " + files[i]);
                if (files[i].indexOf("_") > 0) {
                    if (!files[i].matches(FILENAME_PATTERN)) {
                        System.out.println("File: " + files[i] +
                                " doesn't match naming convention pattern: " + FILENAME_PATTERN +
                                ". Skipping this file... ");
                        continue;
                    }

                    String reportId = files[i].substring(0, files[i].indexOf("_"));

                    if (listOfReportId.containsKey(reportId)) {
                        try {
                            String transactionType = listOfReportId.get(reportId);
                            CommonUtil.printLog("transactionType: " + transactionType);
                            CommonUtil.printLog("Get the transaction type of each reportid : " + reportId + " = " + transactionType);

                            transTypes = createWorkItemsHelper.getPSReportTxnMapTransTypes(reportId);

                            isEnterInfo = enterInfoReports.contains(reportId);
                            if (!"null".equalsIgnoreCase(String.valueOf(transactionType))) {
                                if (ppa.indexOf(transactionType) > -1) {
                                    processPPAReports(files[i],transactionType);
                                    fileCnt++;
                                } else if (ppc.indexOf(transactionType) > -1) {
                                    processPPCReports(files[i], transactionType, wmsconstants.WORK_FLOW_SITE_PPC);
                                    fileCnt++;
                                } else {
                                    try {
                                        processPPCReports(files[i], transactionType, createWorkitemsDao.getWorkflowSite(transactionType));
                                        fileCnt++;
                                    }catch(SQLException e) {
                                        e.printStackTrace(System.out);
                                    }
                                }
                            }
                        } catch (ArrayIndexOutOfBoundsException e) {
                            System.out.println("ArrayIndexOutOfBoundsException : Report : " + reportId + " not yet included in PS_Report_Txn_Map, skipping...");
                        }
                    } else {
                        System.out.println("Report : " + reportId + " not yet included in PS_Report_Txn_Map, skipping...");
                    }
                } else {
                    System.out.println("File " + files[i] + " is not valid");
                }
            }
        }

        System.out.println("No. of files in directory : " + files.length);
        System.out.println("No. of files processed : " + fileCnt);
        System.out.println("##### Leaving CreateWorkItemsUtil.processItems #####");
    }

    private void processPPCReports(String fileName, String transType, String workflowSite) {
        CommonUtil.printLog("##### Inside CreateWorkItemsUtil.processPPCReports  #####");
        //directory where temporary log files will be saved, in case of premature termination (ex. accidental shut down).
        //The log file contains the processed records, so the batch file can pick up from the last processed record.
        File logDir = new File(createWIRB.getString(LOG_FOLDER_PATH));

        //	directory of status reports (this contains the number of passed/failed transactions)
        File statusDir = new File(createWIRB.getString(STATUS_FOLDER_PATH));

        //directory where finished/processed reports will be transferred to
        File processedDir = new File(createWIRB.getString(PROCESSED_FOLDER_PATH));

        if (!logDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "logDir", logDir));
            logDir.mkdirs();
        }
        if (!statusDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "statusDir", statusDir));
            statusDir.mkdirs();
        }
        if (!processedDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "processedDir", processedDir));
            processedDir.mkdirs();
        }

        if (!buStatDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "buStatDir", processedDir));
            buStatDir.mkdirs();
        }
        //String fNameNoExt = (fileName.indexOf(".")>1) ? fileName.substring(0,fileName.indexOf(".")) : fileName;
        StringTokenizer st = new StringTokenizer(fileName, PSBatchConstants.FILENAME_TOKENS_ALLOWED);

        String reportId = st.nextToken();  //fileName.substring(0, fileName.indexOf("_"));
        if (!st.hasMoreTokens()) {
            System.out.println("Cannot extract the next token (Date). Skipping the processing of PPC reports...");
            return;
        }
        String reportDate = fileName.substring(fileName.lastIndexOf("_") + 1);
        File file = new File(dir.getPath() + "\\" + fileName);
        File logFile = new File(logDir, reportId + "_" + reportDate + "_log.txt");
        File statusFile = new File(statusDir, reportId + "_" + reportDate + "_status.txt");

        BufferedWriter statusWriter = null;
        BufferedWriter logWriter = null;
        BufferedReader br = null;
        BufferedReader logReader = null;
        try {
            br = new BufferedReader(new FileReader(file));

            if (!logFile.isFile()) {
                logFile.createNewFile();
            }
            logReader = new BufferedReader(new FileReader(logFile));
            String record;
            statusWriter = new BufferedWriter(new FileWriter(statusFile));
            statusWriter.write("Status report for " + reportId + "_" + reportDate);
            statusWriter.newLine();
            statusWriter.newLine();
            int noOfSuccess = 0;
            int noOfFailed = 0;
            int total = 0;
            String policyNo = null;

            String compStatuses = createWIRB.getString("completion.statuses");
            StringTokenizer statusST = new StringTokenizer(compStatuses, ";");
            String reinTxnType = createWIRB.getString("reinstatement.txn.type");
            String OSDisbTxnType = createWIRB.getString("os.disb.clring.txn.type");

            Boolean checkOS = reportsForStatusChecking.contains(reportId);

            while ((record = br.readLine()) != null) {
                System.out.println("\n\nrecord: " + record);
                if (!record.equalsIgnoreCase(logReader.readLine()) && !record.trim().equalsIgnoreCase("")) {
                    VWSession vwSession = pedp.getVwSession();
                    try {
                        VWRoster roster = vwSession.getRoster(wmsconstants.PS_Roster);
                        StringBuffer criteria = new StringBuffer();
                        policyNo = getColumnValueFrFile(reportId, record, PSBatchConstants.POLICY_NO_COL_NAME);

                        if (null != policyNo) {
                            if (null != policyNo && !policyNo.trim().isEmpty()) {
                                criteria.append("Policy_Number = '");
                                criteria.append(policyNo);
                                criteria.append("'");
                                while (statusST.hasMoreTokens()) {
                                    criteria.append(" and Process_Status <> '");
                                    criteria.append(statusST.nextToken());
                                    criteria.append("'");
                                }
                                //criteria.append(" and Business_Group = 'PPC'");   //uncomment when 'Business_Group' column has been added
                                System.out.println("criteria : " + criteria);
                                VWRosterQuery vwRQuery = roster.createQuery(null, null, null, VWRosterQuery.QUERY_READ_LOCKED, criteria.toString(), null, VWFetchType.FETCH_TYPE_WORKOBJECT);
                                System.out.println("vwQuery fetchCount : " + vwRQuery.fetchCount());
                                boolean createWorkItem = true;
                                String queueName = null;
                                String psTxnType = null;
                                String txnNo = null;
                                VWWorkObject workObj = null;
                                String errMsg = null;
                                if(checkOS) {
                                    while (vwRQuery.hasNext()) {
                                        workObj = (VWWorkObject) vwRQuery.next();
                                        queueName = (String) workObj.getFieldValue(wmsconstants.PS_QName);
                                        psTxnType = (String) workObj.getFieldValue(wmsconstants.PS_TRANSACTION_TYPE);
                                        txnNo = (String) workObj.getFieldValue(wmsconstants.PS_TRANSACTION_NUMBER);
                                        if (OSDisbTxnType.indexOf(psTxnType) > -1) {//OD-CL-PPC
                                            createWorkItem = false;
                                            errMsg = "FAILED : " + policyNo + " has pending O/S Disbursement Clearing transactions.";
                                        } else if (reinTxnType.indexOf(psTxnType) > -1) { //CR and SRO-LIFE
                                            createWorkItem = false;
                                            errMsg = "FAILED : " + policyNo + " has pending Reinstatement transactions.";
                                            if (validReinTxn(txnNo) && queueName.equals(PSBatchConstants.PPC_ABEYANCE_QUEUE)) {
                                                workObj.doDispatch();
                                            }
                                        } else {
                                            //System.out.println("queueName " + queueName);
                                            //System.out.println("txnNo " + txnNo);
                                            if (queueName.equals(PSBatchConstants.PPC_ABEYANCE_QUEUE)) {
                                                workObj.doDispatch();
                                                System.out.println("work object is in PPC Abeyance Queue. Dispatching Work item");
                                            } else if (queueName.equals(PSBatchConstants.INBOX)) {
                                                StringBuffer displayStatus = new StringBuffer((String) workObj.getFieldValue(PSBatchConstants.WORK_OBJ_DISPLAY_STATUS));
                                                displayStatus.append(".  O/S for Clearing");
                                                workObj.setFieldValue(PSBatchConstants.WORK_OBJ_DISPLAY_STATUS, displayStatus.toString(), true);
                                            }
                                        }
                                    }
                                }
                                total++;
                                System.out.println("Create Work Item is " + createWorkItem);
                                System.out.println("Create Work Item errMsg " + errMsg);
                                if (createWorkItem) {
                                    logWriter = new BufferedWriter(new FileWriter(logFile, true));
                                    try {
                                        createWorkItem(fileName, record, transType, workflowSite);
                                        noOfSuccess++;
                                    } catch (Exception e) {
                                        e.printStackTrace(System.out);
                                        noOfFailed++;
                                        statusWriter.write("FAILED : " + policyNo + " - " + e.getMessage());
                                        statusWriter.newLine();
                                    }
                                    //log
                                    logWriter.write(record);
                                    logWriter.newLine();
                                    logWriter.close();
                                } else {
                                    noOfFailed++;
                                    statusWriter.write(errMsg);
                                    statusWriter.newLine();
                                }
                            }
                        }
                    } catch (VWException e) {
                        e.printStackTrace(System.out);
                    }
                }
            }
            statusWriter.newLine();
            statusWriter.newLine();
            statusWriter.write("Total no. of records : " + total);
            statusWriter.newLine();
            statusWriter.write("No. of created workitems : " + noOfSuccess);
            statusWriter.newLine();
            statusWriter.write("No. of failed workitems : " + noOfFailed);
            statusWriter.newLine();
            if (noOfFailed > 0) {
                statusWriter.write("Please check Policy Details");
            }
            statusWriter.close();
            br.close();
            logReader.close();
            logFile.delete();
            file.renameTo(new File(processedDir, file.getName()));
            file.delete();

            copyFiles(statusFile, buStatDir);

        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
        System.out.println("##### Leaving CreateWorkItemsUtil.processPPCReports  #####");
    }

    private boolean validReinTxn(String transactionNo) {
        StringBuffer whereClause = new StringBuffer("WHERE PSOR_TRANSACTION_NO = '");
        whereClause.append(transactionNo);
        whereClause.append("' and ");
        whereClause.append("PSOR_REQUIREMENT_STATUS = 'ORD'");

        @SuppressWarnings("unchecked")
        List<PSOrderReqtsDTO> dtoList = createWorkitemsDao.getPSOrderReqtsDTO(whereClause.toString()).getObjectList();
        if (dtoList != null && !dtoList.isEmpty()) {
            return dtoList.size() == 1 && PAYMENT_CODE.equals(dtoList.get(0).getPSOR_DOCUMENT_TYPE());
        }
        return false;
    }

    private void processPPAReports(String fileName, String transType) {
        CommonUtil.printLog("##### Inside CreateWorkItemsUtil.processPPAReports #####");

        /*
         * directory where temporary log files will be saved, in case of premature termination (ex. accidental shut down).
         * The log file contains the processed records, so the batch file can pick up from the last processed record.
         */
        File logDir = new File(createWIRB.getString(LOG_FOLDER_PATH));

        //directory of status reports (this contains the number of passed/failed transactions)
        File statusDir = new File(createWIRB.getString(STATUS_FOLDER_PATH));

        //directory where finished/processed reports will be transferred to
        File processedDir = new File(createWIRB.getString(PROCESSED_FOLDER_PATH));

        //Checking if directories exist if not then create.
        if (!logDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "logDir", logDir));
            logDir.mkdirs();
        }
        if (!statusDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "statusDir", statusDir));
            statusDir.mkdirs();
        }
        if (!processedDir.isDirectory()) {
            System.out.println(String.format(MKDIRS_MESSAGE, "processedDir", processedDir));
            processedDir.mkdirs();
        }

        StringTokenizer st = new StringTokenizer(fileName, PSBatchConstants.FILENAME_TOKENS_ALLOWED);

        String reportId = st.nextToken(); //fileName.substring(0, fileName.indexOf("_"));
        if (!st.hasMoreTokens()) {
            System.out.println("Cannot extract the next token (Date). Skipping the processing of PPA reports...");
            return;
        }
        String reportDate = fileName.substring(fileName.lastIndexOf("_") + 1);

        File file = new File(dir.getPath() + "\\" + fileName);
        File logFile = new File(logDir, reportId + "_" + reportDate + "_log.txt");
        File statusFile = new File(statusDir, reportId + "_" + reportDate + "_status.txt");

        BufferedWriter statusWriter = null;
        BufferedWriter logWriter = null;
        BufferedReader br = null;
        BufferedReader logReader = null;

        try {
            br = new BufferedReader(new FileReader(file));

            if (!logFile.isFile()) {
                logFile.createNewFile();
            }

            logReader = new BufferedReader(new FileReader(logFile));

            String record;
            statusWriter = new BufferedWriter(new FileWriter(statusFile));
            statusWriter.write("Status report for " + reportId + "_" + reportDate);
            statusWriter.newLine();
            statusWriter.newLine();
            int noOfSuccess = 0;
            int noOfFailed = 0;
            int total = 0;
            String policyNo = null;
            String reason = null;
            while ((record = br.readLine()) != null) {
                System.out.println("\n\nrecord: " + record);
                System.out.println("condition: " + !record.equalsIgnoreCase(logReader.readLine()));
                if (!record.equalsIgnoreCase(logReader.readLine()) && !record.trim().equalsIgnoreCase("")) {
                    logWriter = new BufferedWriter(new FileWriter(logFile, true));

                    policyNo = getColumnValueFrFile(reportId, record, PSBatchConstants.POLICY_NO_COL_NAME);

                    if (PSBatchConstants.REPORT_ID_CSBM9209.equals(reportId)) {
                        reason = getColumnValueFrFile(reportId, record, PSBatchConstants.REASON_COL_NAME);
                        if (PSBatchConstants.BAD_ADD_REASON.equalsIgnoreCase(reason)) {
                            System.out.println("reportId : " + reportId + " reason: " + reason);
                            System.out.println("skipping...");
                            continue;
                        }
                    }

                    if (!NullCheckerUtil.isNullOrEmpty(policyNo)) {
                        try {
                            createWorkItem(fileName, record, transType, wmsconstants.WORK_FLOW_SITE_PPA);
                            noOfSuccess++;
                        } catch (Exception e) {
                            e.printStackTrace(System.out);
                            noOfFailed++;
                            statusWriter.write("FAILED : " + policyNo + " - " + e.getMessage());
                            statusWriter.newLine();
                        }

                        total++;
                        //log
                        logWriter.write(record);
                        logWriter.newLine();
                        logWriter.close();
                    } else {
                        System.out.println("Cannot create workitem. The policyNo is either NULL or EMPTY..");
                    }
                }
            }

            statusWriter.newLine();
            statusWriter.newLine();
            statusWriter.write("Total no. of records : " + total);
            statusWriter.newLine();
            statusWriter.write("No. of created workitems : " + noOfSuccess);
            statusWriter.newLine();
            statusWriter.write("No. of failed workitems : " + noOfFailed);
            statusWriter.newLine();

            if (noOfFailed > 0) statusWriter.write("Please check Policy Details");

            statusWriter.close();
            br.close();
            logReader.close();
            logFile.delete();
            file.renameTo(new File(processedDir, file.getName()));
            file.delete();

            copyFiles(statusFile, buStatDir);
        } catch (IOException e) {
            e.printStackTrace(System.out);
        }
        System.out.println("##### Leaving CreateWorkItemsUtil.processPPAReports #####");
    }

    public void createWorkItem(String fileName, String rec, String transType, String workflowSite) throws Exception {
        final String methodName = "createWorkItem";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

        CommonUtil.printLog("##### Inside CreateWorkItemsUtil.createWorkItem #####");
        Folder folder = null;
        StringTokenizer st = new StringTokenizer(fileName, PSBatchConstants.FILENAME_TOKENS_ALLOWED);
        String reportId = st.nextToken();
        String reportDate = fileName.substring(fileName.lastIndexOf("_") + 1);  //fileName.substring(fileName.indexOf("_")+1, fileName.indexOf("."));
        StringBuilder folderName = new StringBuilder();

        PSStatusDao psStatusDao = new PSStatusDaoImpl();

        String policyNo = null;
        HashMap<String, Object> hm = new HashMap<String, Object>();

        if(isValidCsvFileForWICreation){
            String[] records = CsvWorkitemCreation.getFileLineValues();
            policyNo = records[CsvWorkitemCreation.getPolicyIdPos()];
            reportDate = sdf.format(new Date()).toString();
        }else{
            policyNo = getColumnValueFrFile(reportId, rec, PSBatchConstants.POLICY_NO_COL_NAME);
        }

        Folder policyFolder = null;
        ILifePlanViewDTO iLifeDto = null;
        LifeDTO lifePlanViewDto = null;
        if(isEnterInfo){
            String groupName = getColumnValueFrFile(reportId, rec, PSBatchConstants.GROUP_NAME_COL_NAME);

            policyNo = StringUtils.trim(policyNo);
            Matcher digitMatcher = patternDigits.matcher(policyNo);
            if(!digitMatcher.matches()){
                throw new Exception("Policy Number " + policyNo + " is Column Name");
            }

            hm.put(wmsconstants.PS_F_ClientFName, StringUtils.trimToEmpty(groupName));
            hm.put(wmsconstants.PS_F_ClientLName, "");
            hm.put(wmsconstants.PS_F_ClientMName, "");
            hm.put(wmsconstants.PS_F_ClientNo, "");
            hm.put(wmsconstants.PS_F_InsClientNo, "");
            hm.put(wmsconstants.PS_F_InsFName, StringUtils.trimToEmpty(groupName));
            hm.put(wmsconstants.PS_F_InsLName, "");
            hm.put(wmsconstants.PS_F_InsMName, "");
        }
        else{
            if (PSBatchConstants.PS_COMPANY_SLOCPI.equalsIgnoreCase(this.companyCode)) {
                CommonUtil.printLog("##### Checking if Policy Number " + policyNo + " Exist in CIF... #####");
                IcifDAO icifDaoImpl = new IcifDAOImpl();
                List<LifeDTO> lifePlanViewDtoList = icifDaoImpl.getLifePlanByPolicyNumber(policyNo, ICIF_LINKED_SERVER.get(PSBatchConstants.PS_COMPANY_SLOCPI));
                if (null != lifePlanViewDtoList && !lifePlanViewDtoList.isEmpty()) {
                    lifePlanViewDto = lifePlanViewDtoList.get(0);
                    if (lifePlanViewDto != null) {
                        hm.put(wmsconstants.PS_F_ClientFName, StringUtils.trimToEmpty(lifePlanViewDto.getOwnerFirstName()));
                        hm.put(wmsconstants.PS_F_ClientLName, StringUtils.trimToEmpty(lifePlanViewDto.getOwnerLastName()));
                        hm.put(wmsconstants.PS_F_ClientMName, StringUtils.trimToEmpty(lifePlanViewDto.getOwnerMiddleName()));
                        hm.put(wmsconstants.PS_F_ClientNo, StringUtils.trimToEmpty(lifePlanViewDto.getOwnerClientNumber()));
                        hm.put(wmsconstants.PS_F_InsClientNo, StringUtils.trimToEmpty(lifePlanViewDto.getInsuredClientNumber()));
                        hm.put(wmsconstants.PS_F_InsFName, StringUtils.trimToEmpty(lifePlanViewDto.getInsuredFirstName()));
                        hm.put(wmsconstants.PS_F_InsLName, StringUtils.trimToEmpty(lifePlanViewDto.getInsuredLastName()));
                        hm.put(wmsconstants.PS_F_InsMName, StringUtils.trimToEmpty(lifePlanViewDto.getInsuredMiddleName()));
                    }
                } else {
                    throw new Exception("Policy Number " + policyNo + " does not exist in CIF");
                }
            } else {
                CommonUtil.printLog("##### Checking if Policy Number Exist in CIF... #####");
                List<ILifePlanViewDTO> ilifeDtoList = createWorkitemsDao.getLifePlanViewByPolicyNo("WHERE POL_ID = ''" + policyNo + "''").getObjectList();

                if (ilifeDtoList.isEmpty()) {
                    throw new Exception("Policy Number " + policyNo + " does not exist in CIF");
                }

                iLifeDto = ilifeDtoList.get(0);
                hm.put(wmsconstants.PS_F_ClientFName, iLifeDto.getOWNER_FIRST_NAME());
                hm.put(wmsconstants.PS_F_ClientLName, iLifeDto.getOWNER_LAST_NAME());
                hm.put(wmsconstants.PS_F_ClientMName, iLifeDto.getOWNER_MIDDLE_NAME());
                hm.put(wmsconstants.PS_F_ClientNo, iLifeDto.getOWNER_CLIENT_NO());
                hm.put(wmsconstants.PS_F_InsClientNo, iLifeDto.getINSURED_CLIENT_NO());
                hm.put(wmsconstants.PS_F_InsFName, iLifeDto.getINSURED_FIRST_NAME());
                hm.put(wmsconstants.PS_F_InsLName, iLifeDto.getINSURED_LAST_NAME());
                hm.put(wmsconstants.PS_F_InsMName, iLifeDto.getINSURED_MIDDLE_NAME());
            }
        }
        CommonUtil.printLog("##### Checking Status for workitem... #####");

        String criteria = String.format("Policy_Number = '%s' and PS_Transaction_Type IN ('%s') and Company_Code = '%s'",
                policyNo,
                StringUtils.join(transTypes,"','"),
                companyCode
                );

        CommonUtil.printLog("Criteria: " + criteria);
        List<String> statusList = getPSStatus(criteria, wmsconstants.PS_Roster);
        List<String> invalidList = psStatusDao.checkStatusCreatable(statusList, transTypes, companyCode);

        if (!invalidList.isEmpty()) {
            throw new Exception("Policy Number: " + policyNo + " is invalid due to existing work item with " + invalidList + " status");
        }


        hm.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_LIFE);
        hm.put(wmsconstants.PS_F_PolicyNo, policyNo);
        hm.put(PSBatchConstants.PS_F_COMPANY_CODE, this.companyCode);

        CommonUtil.printLog(CLASS_NAME, methodName, "Getting compcode in resource bundle: " + this.companyCode);
        List dtoList = createWorkitemsDao.getPSReportColumnMapDTO("WHERE report_id = '" + reportId + "'").getObjectList();
        PSReportColumnValuesDTO colValuesDto = new PSReportColumnValuesDTO();

        String tmpColValuePrefix = "";
        String tmpColValueSuffix = "";
        Iterator dtoIter = dtoList.iterator();
        String colValue = null;
        PSReportColumnMapDTO dto = null;
        //setting column values
        colValuesDto.setREPORT_ID(reportId);
        colValuesDto.setREPORT_DATE(reportDate);
        while (dtoIter.hasNext()) {
            dto = (PSReportColumnMapDTO) dtoIter.next();

            if(isValidCsvFileForWICreation){
                Pair<Integer, Integer> pair = new MutablePair<Integer, Integer>();
                pair = mapPairPSReportColumnMap.get(reportId).get(dto.getCOLUMN_NAME());
                if(pair != null) {
                    colValue = CsvWorkitemCreation.getFileLineValues()[pair.getLeft()];
                    CommonUtil.printLog(CLASS_NAME, methodName, "Column Name: " + dto.getCOLUMN_NAME() + " Value: " + colValue);
                }else {
                    continue;
                }
            } else {
                colValue = getColumnValueFrFile(reportId, rec, dto.getCOLUMN_NAME());
                try{
                    if (rb.getString("PS_REPORT_COLUMN_VALUES.FIELDS.AMOUNT").indexOf(dto.getCOLUMN_NAME()) > -1 &&
                            colValue != null && !colValue.equals("")){
                        if(colValue!=null && !colValue.equals("")){

                            boolean isPrefixZero = true;

                            while(colValue.startsWith("0") && isPrefixZero){
                                colValue = colValue.substring(1,colValue.length());

                                if(!colValue.startsWith("0")){
                                    isPrefixZero = false;
                                }
                            }

                            if(colValue.length()>=3){
                                tmpColValuePrefix = colValue.substring(0,colValue.length()-2);
                                tmpColValueSuffix = colValue.substring(colValue.length()-2,colValue.length());
                                colValue = tmpColValuePrefix+"."+tmpColValueSuffix;
                            }else if(colValue.length()==2){
                                colValue = "0."+colValue;
                            }else if(colValue.length()==1){
                                colValue = "0.0"+colValue;
                            }
                        }
                    }
                } catch(Exception e){
                    CommonUtil.printLog(CLASS_NAME, methodName, "Exception: " + CommonUtil.exceptionStacktraceToString(e));
                }
            }
            colValuesDto = setColumnValueToDTO(dto.getPRCV_COL_NAME(), colValue, colValuesDto);
        }

        colValuesDto.setCOMPANY_CODE(this.companyCode);
        createWorkitemsDao.insertPSReportColumnValuesDTO(colValuesDto);
        CommonUtil.printLog(CLASS_NAME, methodName, "attempting to insert to db");
        //Saving record into to DB - end

        try {
            CommonUtil.printLog("##### Checking if Folder Exist... #####");
            final CEDataProviderExtended cedpEx = (CEDataProviderExtended) cedp;
            folder = (Folder) cedpEx.getFNObjectByPath(BaseObject.TYPE_FOLDER, "/" + wmsconstants.PS_F_POLICY_SERVICING, this.companyCode);
            CommonUtil.printLog(CLASS_NAME, methodName, "folder from cedp: " + folder.getName());
            CommonUtil.printLog(CLASS_NAME, methodName, "folder objectStoreID: " + folder.getObjectStoreId());
            policyFolder = (Folder) cedpEx.getFNObjectByPath(BaseObject.TYPE_FOLDER, "/" + wmsconstants.PS_F_POLICY_SERVICING + "/" + policyNo, this.companyCode);
            CommonUtil.printLog(CLASS_NAME, methodName, "policy folder: " + policyFolder.getName());
            CommonUtil.printLog(CLASS_NAME, methodName, policyNo + " PSFolder exists!");
        } catch (BadReferenceException e) {
            CommonUtil.printLog(CLASS_NAME, methodName, policyNo + " PSFolder doesn't exist, creating ...");
            try {
                policyFolder = folder.addSubFolder(policyNo, wmsconstants.PS_Folder, cedp.createProperties(hm), null);
                CommonUtil.printLog(CLASS_NAME, methodName, "Created policyFolder: " + policyFolder.getName());
            } catch (Exception e1) {
                CommonUtil.printLog(CLASS_NAME, methodName, "Exception: " + CommonUtil.exceptionStacktraceToString(e1));
            }
        }

        try {
            hm.put(wmsconstants.PS_F_ScanDate, sdf.parse(reportDate));
        } catch (ParseException e1) {
            CommonUtil.printLog("CreateWorkItemsUtil", "createWorkItem", "ParseException: " + CommonUtil.exceptionStacktraceToString(e1));
            throw new Exception("Invalid Report Date format ");
        }

        PSReportTxnMapDTO tmpDto = (PSReportTxnMapDTO) createWorkitemsDao.getPSReportTxnMapDTO("Where Report_Id = '" + reportId + "' AND (ACTIVE = 1 OR SLGFI_ACTIVE = 1)").getObjectList().get(0);
        String txnType = tmpDto.getPSTXNTYPE_TRANS_ID();
        String agentID = "";
        if(!isEnterInfo){
            agentID = PSBatchConstants.PS_COMPANY_SLOCPI.equalsIgnoreCase(this.companyCode)
                    ? lifePlanViewDto.getAgentCode()
                    : iLifeDto.getAGENT_CODE();
        }
        PSTransactionTypesDAO tranTypeDao = new PSTransactionTypesDAOImpl();
        PSTransactionTypesDTO tranTypeDto = null;
        List tranTypeDtoList = tranTypeDao.getPSTransactionTypesDTO("Where Trans_Id = '" + txnType + "'").getObjectList();
        String disbCategory = "";
        String ccUnit = "";
        if (tranTypeDtoList != null && !tranTypeDtoList.isEmpty()) {
            tranTypeDto = (PSTransactionTypesDTO) tranTypeDtoList.get(0);
            disbCategory = tranTypeDto.getTRANS_CATEGORY();
            String transSite = tranTypeDto.getTRANS_SITE();
            if (transSite.toUpperCase().indexOf("PPC") >= 0) {
                ccUnit = "PC";
            } else if (transSite.toUpperCase().indexOf("PPA") >= 0) {
                ccUnit = "PA";
            } else if (transSite.toUpperCase().indexOf("CMG") >= 0) {
                ccUnit = "CM";
            } else if (transSite.toUpperCase().indexOf("BS") >= 0) {
                ccUnit = "BS";
            }else {
                CommonUtil.printLog(CLASS_NAME, methodName, "TransSite is not PPA, PPC or CMG, it's " + transSite);
                try {
                    ccUnit = createWorkitemsDao.getCCUnit(transSite);
                }catch(SQLException e){
                    throw new Exception("TransSite is Invalid");
                }
            }
        }
        hm.put(wmsconstants.PS_F_PSTransType, txnType);
        hm.put(wmsconstants.PS_F_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE);
        hm.put(wmsconstants.PS_F_AgentID, agentID);
        hm.put(wmsconstants.PS_F_MultipleTransaction, new Boolean("false"));
        hm.put(wmsconstants.PS_F_DisbCategory, disbCategory);
        hm.put(wmsconstants.PS_F_DocCapSiteID, ccUnit);
        hm.put(wmsconstants.PS_F_ProcessStatus, "Created");

        //Folder name construction
        folderName.append(policyNo);
        folderName.append("_");
        folderName.append(txnType);

        if (PSBatchConstants.REPORT_ID_CSBM9586.equals(reportId)) {
            folderName.append("_").append(getColumnValueFrFile(reportId, rec, PSBatchConstants.CHEQUE_NUMBER_COL_NAME));
        }

        folderName.append("_");
        folderName.append(reportDate);

        Folder newFolder = null;

        try {
            newFolder = policyFolder.addSubFolder(folderName.toString(), wmsconstants.PS_F_Tran_Folder, cedp.createProperties(hm), null);
            CommonUtil.printLog(CLASS_NAME, methodName, "created new folder : " + folderName.toString());
            CommonUtil.printLog(CLASS_NAME, methodName, "folder: " + newFolder.getName());
            CommonUtil.printLog(CLASS_NAME, methodName, "folder objectStoreID: " + newFolder.getObjectStoreId());
            Folder parent = newFolder.getParentFolder();
            if (parent != null) {
                CommonUtil.printLog(CLASS_NAME, methodName, "folder parent: " + parent.getName());
            }
            CommonUtil.printLog(CLASS_NAME, methodName, "Policy Folder: " + policyFolder.getName());
        } catch (UniquenessConstraintException e) {
            CommonUtil.printLog(CLASS_NAME, methodName, "UniquenessConstraintException: " + CommonUtil.exceptionStacktraceToString(e));
            CommonUtil.printLog(CLASS_NAME, methodName, "Folder Name " + folderName.toString() + " is not unique");
            throw new Exception("Folder Name " + folderName.toString() + " is not unique");
        }

        launchWorkflow(newFolder, reportId);
        CommonUtil.printLog("##### Leaving CreateWorkItemsUtil.createWorkItem #####");
    }

    protected PSReportColumnValuesDTO setColumnValueToDTO(String columnName, String columnValue, PSReportColumnValuesDTO dto) throws Exception {
        Class clazz = Class.forName((dto.getClass().toString()).replaceAll("class ", ""));
        Method setMethod = clazz.getMethod("set" + columnName.trim(), Class.forName("java.lang.String"));
        setMethod.invoke(dto, new String[]{columnValue});

        return dto;
    }

    protected VWAttachment convertFolderToAttachment(Folder folder) throws VWException {
        CommonUtil.printLog("Inside CreateWorkItemsUtil.convertFolderToAttachment...");
        VWAttachment att = new VWAttachment();

        att.setLibraryType(VWLibraryType.LIBRARY_TYPE_CONTENT_ENGINE);
        String objectStoreName = CompanyWMSPropsUtil.getWMSObjectStoreName(this.companyCode);
        att.setLibraryName(objectStoreName);
        CommonUtil.printLog("CreateWorkItemsUtil", "convertFolderToAttachment", "objectStoreName: " + objectStoreName);
        CommonUtil.printLog("CreateWorkItemsUtil", "convertFolderToAttachment", "companyCode: " + this.companyCode);
        CommonUtil.printLog("CreateWorkItemsUtil", "convertFolderToAttachment", "folder: " + folder.getName());
        CommonUtil.printLog("CreateWorkItemsUtil", "convertFolderToAttachment", "folder id: " + folder.getId());
        CommonUtil.printLog("CreateWorkItemsUtil", "convertFolderToAttachment", "folder objtStoreId: " + folder.getObjectStoreId());
        att.setType(VWAttachmentType.ATTACHMENT_TYPE_FOLDER);
        att.setAttachmentName(folder.getName());
        att.setId(folder.getId());

        CommonUtil.printLog("Leaving CreateWorkItemsUtil.convertFolderToAttachment...");
        return att;
    }

    protected void launchWorkflow() {
        launchWorkflow(null, null);
    }

    protected void launchWorkflow(Folder folder, String reportID) {
        CommonUtil.printLog("Inside CreateWorkItemsUtil.launchWorkflow...");
        HashMap<String, Object> stepElemParams = new HashMap<String, Object>();

        try {
            VWAttachment att = convertFolderToAttachment(folder);
            if (att != null) {
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "Folder Attachment:");
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att libraryName: " + att.getLibraryName());
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att attachmentName: " + att.getAttachmentName());
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att attachmentDesc: " + att.getAttachmentDescription());
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att ID: " + att.getId());
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att libraryType: " + att.getLibraryType());
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "att type: " + att.getType());
            }

            stepElemParams.put(wmsconstants.PS_ScanDate, folder.getPropertyValue(wmsconstants.PS_F_ScanDate));
            stepElemParams.put(wmsconstants.PS_CLIENT_FIRST_NAME, folder.getPropertyValue(wmsconstants.PS_F_ClientFName));
            stepElemParams.put(wmsconstants.PS_CLIENT_LAST_NAME, folder.getPropertyValue(wmsconstants.PS_F_ClientLName));
            stepElemParams.put(wmsconstants.PS_CLIENT_MIDDLE_NAME, folder.getPropertyValue(wmsconstants.PS_F_ClientMName));
            stepElemParams.put(wmsconstants.PS_CLIENT_NUMBER, folder.getPropertyValue(wmsconstants.PS_F_ClientNo));
            stepElemParams.put(wmsconstants.PS_INSURED_CLIENT_NUMBER, folder.getPropertyValue(wmsconstants.PS_F_InsClientNo));
            stepElemParams.put(wmsconstants.PS_INSURED_FIRST_NAME, folder.getPropertyValue(wmsconstants.PS_F_InsFName));
            stepElemParams.put(wmsconstants.PS_INSURED_LAST_NAME, folder.getPropertyValue(wmsconstants.PS_F_InsLName));
            stepElemParams.put(wmsconstants.PS_INSURED_MIDDLE_NAME, folder.getPropertyValue(wmsconstants.PS_F_InsMName));
            stepElemParams.put(wmsconstants.PS_LOB, folder.getPropertyValue(wmsconstants.PS_F_LOB));
            stepElemParams.put(wmsconstants.PS_PolicyNo, folder.getPropertyValue(wmsconstants.PS_F_PolicyNo));
            stepElemParams.put(PSBatchConstants.PS_REPORT_ID, reportID);
            stepElemParams.put(wmsconstants.PS_ScannedBy, folder.getPropertyValue(wmsconstants.PS_F_ScannedBy));
            stepElemParams.put(wmsconstants.PS_TRANSACTION_TYPE, folder.getPropertyValue(wmsconstants.PS_F_PSTransType));
            stepElemParams.put(wmsconstants.PS_Folder, att);
            stepElemParams.put(wmsconstants.PS_MultipleTransaction, folder.getPropertyValue(wmsconstants.PS_F_MultipleTransaction));
            stepElemParams.put(wmsconstants.PS_DisbCategory, folder.getPropertyValue(wmsconstants.PS_F_DisbCategory));
            stepElemParams.put(PS_Company_Code, folder.getPropertyValue(PS_F_Company_Code));

            String policyFolderValue = folder.getPropertyStringValue(wmsconstants.PS_F_PolicyNo);
            String companyCodeFolderValue = folder.getPropertyStringValue(PS_F_Company_Code);
            String lobFolderValue = folder.getPropertyStringValue(wmsconstants.PS_F_LOB);
            String disbCategoryFolderValue = folder.getPropertyStringValue(wmsconstants.PS_F_DisbCategory);
            String transTypeFolderValue = folder.getPropertyStringValue(wmsconstants.PS_F_PSTransType);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "Folder Values:");
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "policyFolderValue: " + policyFolderValue);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "companyCodeFolderValue: " + companyCodeFolderValue);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "lobFolderValue: " + lobFolderValue);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "disbCategoryFolderValue: " + disbCategoryFolderValue);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "transTypeFolderValue: " + transTypeFolderValue + "\n");

            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "stepElementparams report id in launchworkitem: " + stepElemParams.get(wmsconstants.PS_REPORT_ID));

            String ccId = (String) folder.getPropertyValue(wmsconstants.PS_F_DocCapSiteID);
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "ccId value: " + ccId);
            if (StringUtils.isBlank(ccId)) {
                CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "CC ID is Blank. Raising exception..");
                throw new Exception("ccID is BLANK.");
            }

            CenterCode_DAO ccDao = new CenterCode_DAO();
            List<CenterCodesDTO> dtoList = ccDao.getCenterCodesDTO("Where CC_ID='" + ccId + "'").get();
            String ccAbbrev = "";
            if (dtoList != null && dtoList.size() > 0) {
                ccAbbrev = dtoList.get(0).getCC_AbbrevName();
            }
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "ccAbbrev value: " + ccAbbrev);

            stepElemParams.put(wmsconstants.PS_AGENT_ID, folder.getPropertyValue(wmsconstants.PS_F_AgentID));
            stepElemParams.put(wmsconstants.PS_CC_AbbrevName, ccAbbrev);
            stepElemParams.put(wmsconstants.PS_CustomerCenterID, ccId);

            // Set workitem created to robotID if condition have been met
            stepElemParams = setRobotID(stepElemParams);

            boolean result = false;
            if (PSBatchConstants.PS_COMPANY_SLGFI.equalsIgnoreCase(this.companyCode)) {
                result = pedp.createWorkItem(stepElemParams, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME_GF, null);
            } else if (PSBatchConstants.PS_COMPANY_SLOCPI.equalsIgnoreCase(this.companyCode)) {
                result = pedp.createWorkItem(stepElemParams, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME, null);
            }

            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "Work item created , result is: " + result);
        } catch (Exception e) {
            CommonUtil.printLog("CreateWorkItemsUtil", "launchWorkflow", "Exception: " + exceptionStacktraceToString(e));
        }
        CommonUtil.printLog("Leaving CreateWorkItemsUtil.launchWorkflow...");
    }

    /**
     * Parses the string, and returns the value
     *
     * @param reportId
     * @param record
     * @return
     * @modified by OLUND for MR-WF-15-00217
     */
    protected String getColumnValueFrFile(String reportId, String record, String columnName) {
        System.out.println(reportId + " " + columnName);
        String value = "";
        int offset = 0;
        int length = 0;
        int endIndex = 0;

        try {
            String key = (reportId + columnName).toUpperCase();
            String data = listOfPSReportColumnMap.get(key);

            System.out.println("DATA : " + data);

            String[] oofsetAndLength = data.split("-");
            offset = Integer.valueOf(oofsetAndLength[0]) - 1;
            length = Integer.valueOf(oofsetAndLength[1]);

            System.out.println("listOfPSReportColumnMap OFFSET = " + offset);
            System.out.println("listOfPSReportColumnMap LENGTH = " + length);

            offset = Integer.valueOf(oofsetAndLength[0]) - 1;
            length = Integer.valueOf(oofsetAndLength[1]);

            endIndex = (offset + length < record.length()) ? offset + length : record.length();
            value = record.substring(offset, endIndex);

            System.out.println("value : " + value);
        } catch (Exception e) {
            e.printStackTrace(System.out);

            System.out.println("If there there are any problem with the map collection. Use the database!");

            PSReportColumnMapDTO dto = createWorkitemsDao.getColumnMap(reportId, columnName);
            List dtoList = dto.getObjectList();
            System.out.println("Report " + reportId);
            System.out.println("Getting " + columnName + " from record");
            offset = ((PSReportColumnMapDTO) dtoList.get(0)).getOFFSET().intValue() - 1;
            length = ((PSReportColumnMapDTO) dtoList.get(0)).getLENGTH().intValue();

            endIndex = (offset + length < record.length()) ? offset + length : record.length();

            System.out.println("endIndex : " + endIndex);
            value = record.substring(offset, endIndex);

            System.out.println("value : " + value);

        }
        return value.trim();
    }

    public boolean isFileValid(String fileName) {
        PSReportColumnMapDTO dto1 = createWorkitemsDao.getPSReportColumnMapDTO();
        PSReportTxnMapDTO dto2 = createWorkitemsDao.getPSReportTxnMapDTO();

        return (dto1.getObjectList().size() > 0 && dto2.getObjectList().size() > 0);
    }

    /**
     * Check reportID and policyNo prefix starts with 08(CP) and 28(GF), will then assign robotID in "PROCESSOR" field in WF
     *
     * @param stepElemParams
     * @return HashMap Object that robotID has been set as processor
     */
    public HashMap<String, Object> setRobotID(HashMap<String, Object> stepElemParams) {
        System.out.println("##### Start CreateWorkItemsUtil.setRobotID #####");

        try {
            boolean prefixCheck = StringUtils.startsWith((CharSequence) stepElemParams.get(wmsconstants.PS_PolicyNo), PSBatchConstants.POLICY_PREFIX_CP)
                    || StringUtils.startsWith((CharSequence) stepElemParams.get(wmsconstants.PS_PolicyNo), PSBatchConstants.POLICY_PREFIX_GF);

            System.out.println("File ReportID: " + stepElemParams.get(PSBatchConstants.PS_REPORT_ID));
            System.out.println("Policy prefixCheck: " + prefixCheck);

            if (PSBatchConstants.REPORT_ID_CSBM9441.equals(stepElemParams.get(PSBatchConstants.PS_REPORT_ID)) && prefixCheck) {
                String compCode = (String) stepElemParams.get(PS_Company_Code);
                System.out.println("Getting compCode in stepElement HasMap: " + compCode);

                System.out.println("Start getting robotID in DB...");
                CreateWorkitemsDao cwiDao = new CreateWorkitemsDaoImpl(compCode);
                String userId = cwiDao.getRoboID();
                System.out.println("Fetched robotID: " + userId);

                VWParticipant vwParticipant = new VWParticipant(userId);
                VWParticipant[] vwParticipantArr = new VWParticipant[]{vwParticipant};

                System.out.println("Set robotID as processor in workflow...");
                stepElemParams.put(wmsconstants.PS_Processor, vwParticipantArr);
            }

        } catch (Exception e) {
            System.out.println("Error encountered while setting robotID: " + exceptionStacktraceToString(e));
        }

        System.out.println("##### Leaving CreateWorkItemsUtil.setRobotID #####");
        return stepElemParams;
    }

    public VWRosterQuery getRoster(String criteria, String rosterName) throws Exception {
        CommonUtil.printLog("Inside Roster Helper");
        VWSession vwSession = pedp.getVwSession();
        CommonUtil.printLog("Roster Name: "+rosterName);
        try {
            VWRoster roster;
            roster = vwSession.getRoster(rosterName);
            CommonUtil.printLog("criteria : " + criteria);
            VWRosterQuery vwRQuery = roster.createQuery(null, null, null, VWRosterQuery.QUERY_READ_LOCKED, criteria, null, VWFetchType.FETCH_TYPE_WORKOBJECT);
            CommonUtil.printLog("vwQuery fetchCount : " + vwRQuery.fetchCount());
            return vwRQuery;

        } catch (VWException e) {
            throw new Exception("Error in Roster Fetching");
        }
    }

    public List<String> getPSStatus(String criteria, String rosterName) throws Exception {
        VWRosterQuery vwRQuery = getRoster(criteria, rosterName);
        List<String> statusList = new ArrayList<String>();
        VWWorkObject workObj = null;
        while (vwRQuery.hasNext()) {
            workObj = (VWWorkObject) vwRQuery.next();

            if(!statusList.contains((String) workObj.getFieldValue(wmsconstants.PS_ProcessStatus)))
                statusList.add((String) workObj.getFieldValue(wmsconstants.PS_ProcessStatus));
        }
        return statusList;
    }

    private void copyFiles(File from, File to) {
        CommonUtil.printLog("Copying file from: " +  from.getAbsolutePath() + " to: " + to.getAbsolutePath());
        try{
            FileUtils.copyFileToDirectory(from, to);
            CommonUtil.printLog("copy success");
        }catch (IOException e){
            e.printStackTrace(System.out);
        }

    }
}