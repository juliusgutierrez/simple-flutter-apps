package ph.com.sunlife.wms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.Folder;
import com.filenet.wcm.api.Properties;

import filenet.vw.api.VWAttachment;

import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.constants.wmsconstants;
import ph.com.sunlife.wms.dao.PSVarfuDao;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PSVarfuListDTO;
import ph.com.sunlife.wms.dto.WMSParam;
import ph.com.sunlife.wms.impl.PSVarfuDaoImpl;

public class PSVarfuUtil {
	//private Logger logger = Logger.getLogger(PSVarfuUtil.class);
	private PSVarfuDao dao;
	private CEDataProvider ceu;
	private PEUtilDP peu;
	
	public PSVarfuUtil() throws Exception{
		dao = new PSVarfuDaoImpl();
		ceu = new CEDataProvider();
		ceu.init();
		peu = new PEUtilDP();
	}
	public boolean processItems(){
		Date reportDate = getBFPReportDate();
		Calendar cal = Calendar.getInstance();
		if(reportDate!=null) {
			cal.setTime(reportDate);
			if((cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY)){
				int month = cal.get(Calendar.MONTH)+1;
				int day = cal.get(Calendar.DAY_OF_MONTH);
				int year = cal.get(Calendar.YEAR);
				System.out.println("Report date month = " + month);
				System.out.println("Report date day = " + day);
				System.out.println("Report date year = " + year);
				StringBuffer sb = new StringBuffer();
	
				sb.append("WHERE MONTH(ISSUE_DATE) = ")
				  .append(month);
				
				//System.out.println("Is year " + cal.get(Calendar.YEAR) + " leap year = " + isLeapYear(cal.get(Calendar.YEAR)));
				
				if(month == 2 && day == 28 && !isLeapYear(year)){
					sb.append(" AND ((DAY(ISSUE_DATE)) = 28")
					  .append(" OR (DAY(ISSUE_DATE)) = 29)");
				}else if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY){
					sb.append(" AND ((DAY(ISSUE_DATE)) = ")
					  .append(day)
					  .append(" OR (DAY(ISSUE_DATE)) = ")
					  .append(day-1)
					  .append(")");	
				}else{
					sb.append(" AND (DAY(ISSUE_DATE)) = ")
					  .append(day);
				}
				
				System.out.println("whereclause = " + sb.toString());
				StringBuffer whereClause = new StringBuffer();
				
				@SuppressWarnings("rawtypes")
				List varfuList = dao.getPSVarfuList(sb.toString()).getObjectList();
				System.out.println("varfuList.size() :"+varfuList.size());
				if (varfuList.size()>0) {
					whereClause.append("WHERE POL_ID IN (");
					Iterator varfuIt = varfuList.iterator();
					while (varfuIt.hasNext()) {
						PSVarfuListDTO dto = (PSVarfuListDTO) varfuIt.next();
						whereClause.append("''" + dto.getPOLICY_NUM() + "''");
						if (varfuIt.hasNext()) {
							whereClause.append(", ");
						}
					}
					whereClause.append(")");
					System.out.println("IlifePlanView whereclause = " + whereClause.toString());
					
					List polDetailList = dao.getPolicyDetails(whereClause.toString()).getObjectList();
					System.out.println("polDetailList.size() :"+polDetailList.size());
					if(polDetailList.size()>0){
						//TODO: Create workitem here
						try {
							HashMap hm = new HashMap();
							Date currDate = Calendar.getInstance().getTime();
							//TODO: put properties here to hashmap
							Iterator polDetailIt = polDetailList.iterator();
							while(polDetailIt.hasNext()){
								ILifePlanViewDTO dto = (ILifePlanViewDTO)polDetailIt.next();
								hm.put(wmsconstants.PS_F_PolicyNo, dto.getPOL_ID());
								hm.put(wmsconstants.PS_F_ClientNo, dto.getOWNER_CLIENT_NO());
								hm.put(wmsconstants.PS_F_ClientFName, dto.getOWNER_FIRST_NAME());
								hm.put(wmsconstants.PS_F_ClientMName, dto.getOWNER_MIDDLE_NAME());
								hm.put(wmsconstants.PS_F_ClientLName, dto.getOWNER_LAST_NAME());
								hm.put(wmsconstants.PS_F_InsClientNo, dto.getINSURED_CLIENT_NO());
								hm.put(wmsconstants.PS_F_InsFName, dto.getINSURED_FIRST_NAME());
								hm.put(wmsconstants.PS_F_InsMName, dto.getINSURED_MIDDLE_NAME());
								hm.put(wmsconstants.PS_F_InsLName, dto.getINSURED_LAST_NAME());
								// hm.put(wmsconstants.PS_F_ScanDate, currDate );
								// hm.put(wmsconstants.PS_F_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE );
								
								Folder parentFolder = (Folder)ceu.getFNObjectByPath(BaseObject.TYPE_FOLDER, "/"+wmsconstants.PS_F_POLICY_SERVICING);
								Folder folder = (Folder)ceu.getFNObjectByPath(BaseObject.TYPE_FOLDER, "/"+wmsconstants.PS_F_POLICY_SERVICING+"/"+dto.getPOL_ID());
								// checking for null using try and catch? genius!
								try{
									System.out.println("folder.getName():"+folder.getName());
								}catch(Exception e){
									hm.put(wmsconstants.PS_F_FolderName, dto.getPOL_ID());
									Properties props = ceu.createProperties(hm);
									folder = parentFolder.addSubFolder(dto.getPOL_ID(), wmsconstants.PS_Folder, props, null);
								}
								
								SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddhhmm");
								String folderName = dto.getPOL_ID() + "_DISB-VARFU_" + sdf.format(currDate);
								hm.put(wmsconstants.PS_F_PSTransType, "DISB-VARFU");
								hm.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_LIFE);
								
								Properties props = ceu.createProperties(hm);
								
								if(folder!=null){
									System.out.println("folder not null");
									VWAttachment vwa = peu.convertCEObjToAttachment(folder);
									//clear hashmap
													
														
									hm.clear();
									hm.put(wmsconstants.PS_F_PolicyNo, dto.getPOL_ID());
									hm.put(wmsconstants.PS_F_ClientNo, dto.getOWNER_CLIENT_NO());
									hm.put(wmsconstants.PS_F_ClientFName, dto.getOWNER_FIRST_NAME());
									hm.put(wmsconstants.PS_F_ClientMName, dto.getOWNER_MIDDLE_NAME());
									hm.put(wmsconstants.PS_F_ClientLName, dto.getOWNER_LAST_NAME());
									hm.put(wmsconstants.PS_F_InsClientNo, dto.getINSURED_CLIENT_NO());
									hm.put(wmsconstants.PS_F_InsFName, dto.getINSURED_FIRST_NAME());
									hm.put(wmsconstants.PS_F_InsMName, dto.getINSURED_MIDDLE_NAME());
									hm.put(wmsconstants.PS_F_InsLName, dto.getINSURED_LAST_NAME());
									hm.put(wmsconstants.PS_F_PSTransType, "DISB-VARFU");
									//hm.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_LIFE);
									hm.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_LIFE);
									hm.put(wmsconstants.PS_F_ScanDate, currDate );
									hm.put(wmsconstants.PS_F_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE );
									hm.put(wmsconstants.PS_Folder, vwa);
									hm.put(wmsconstants.Audit_Tag, false);
									
									Properties propsFolder = ceu.createProperties(hm);
								
									folder = folder.addSubFolder(folderName, wmsconstants.PS_F_Tran_Folder, propsFolder, null);
									
									
									 vwa = peu.convertCEObjToAttachment(folder);
									HashMap hmWorkitem = new HashMap();
									hmWorkitem.put(wmsconstants.PS_POLICY_NUMBER, dto.getPOL_ID());
									hmWorkitem.put(wmsconstants.PS_CLIENT_NUMBER, dto.getOWNER_CLIENT_NO());
									hmWorkitem.put(wmsconstants.PS_CLIENT_FIRST_NAME, dto.getOWNER_FIRST_NAME());
									hmWorkitem.put(wmsconstants.PS_CLIENT_MIDDLE_NAME, dto.getOWNER_MIDDLE_NAME());
									hmWorkitem.put(wmsconstants.PS_CLIENT_LAST_NAME, dto.getOWNER_LAST_NAME());
									hmWorkitem.put(wmsconstants.PS_INSURED_CLIENT_NUMBER, dto.getINSURED_CLIENT_NO());
									hmWorkitem.put(wmsconstants.PS_INSURED_FIRST_NAME, dto.getINSURED_FIRST_NAME());
									hmWorkitem.put(wmsconstants.PS_INSURED_MIDDLE_NAME, dto.getINSURED_MIDDLE_NAME());
									hmWorkitem.put(wmsconstants.PS_INSURED_LAST_NAME, dto.getINSURED_LAST_NAME());
									hmWorkitem.put(wmsconstants.PS_TRANSACTION_TYPE, "DISB-VARFU");
									//hm.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_LIFE);
									hmWorkitem.put(wmsconstants.PS_LOB, PSBatchConstants.LOB_LIFE);
									hmWorkitem.put(wmsconstants.PS_ScanDate, currDate );
									hmWorkitem.put(wmsconstants.PS_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE );
									hmWorkitem.put(wmsconstants.PS_Folder, vwa);
									
									return peu.createWorkItem(hmWorkitem, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME, null);
								}
								
							}
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}else{
				System.out.println("No Batch process on sunday");
			}
		}else{
			System.out.println("Report Date is null");
		}
		return false;
	}
	
	public Date getBFPReportDate(){
		List list = dao.getBFPReportDate().getObjectList();
		Date reportDate = null;
		if(list.size()>0){
			WMSParam dto = (WMSParam)list.get(0);
			SimpleDateFormat sdf = new SimpleDateFormat(dto.getWMSP_Format());
			try {
				reportDate = sdf.parse(dto.getWMSP_Value());
			} catch (ParseException e) {
				e.printStackTrace();
				System.out.println(e.getMessage());
			}
		}
		return reportDate;
	}
	
	public static boolean isLeapYear(int year) {
		if (year < 0) {
			return false;
		}

	    if (year % 400 == 0) {
	      return true;
	    } else if (year % 100 == 0) {
	      return false;
	    } else if (year % 4 == 0) {
	      return true;
	    } else {
	      return false;
	    }
   }
}
