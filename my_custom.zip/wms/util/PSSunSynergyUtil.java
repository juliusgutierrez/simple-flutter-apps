package ph.com.sunlife.wms.util;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import com.filenet.wcm.api.BadReferenceException;
import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.Folder;
import com.filenet.wcm.api.Properties;

import filenet.vw.api.VWAttachment;

import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.constants.wmsconstants;
import ph.com.sunlife.wms.dao.PSSunSynergyDao;
import ph.com.sunlife.wms.dao.WmsParamDAO;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
//import ph.com.sunlife.wms.dto.DataAccessInterface;
import ph.com.sunlife.wms.dto.ILifePlanViewDTO;
import ph.com.sunlife.wms.dto.PNeedPlanViewDTO;
import ph.com.sunlife.wms.dto.PSSunSynergyListDTO;
import ph.com.sunlife.wms.dto.SunSynergyDTO;
import ph.com.sunlife.wms.dto.WMSParam;
import ph.com.sunlife.wms.impl.PSSunSynergyDaoImpl;
import ph.com.sunlife.wms.impl.WmsParamDAOImpl;

public class PSSunSynergyUtil {

	//private Logger logger = Logger.getLogger(PSSunSynergyUtil.class);
	private CEDataProvider cedp;
	private PEUtilDP pedp;
	private ResourceBundle rb;
	
	
	public PSSunSynergyUtil(){
		try {
			cedp = new CEDataProvider();
			cedp.init();
			pedp = new PEUtilDP();
			rb = CreateWorkitems.getCreateWIResourceBundle();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void processItems() throws SQLException {
		
		PSSunSynergyDao sunSynDao = new PSSunSynergyDaoImpl();
		Date BFPReportDate = getBFPReportDate();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		File logDir = new File(rb.getString("status.folder.path"));
		
		if(!logDir.isDirectory()){
			logDir.mkdirs();
		}
		
		File logFile = new File(logDir, PSBatchConstants.PS_SUN_SYNERGY_LOGS+"_"+sdf.format(BFPReportDate)+".txt");
		BufferedWriter logWriter = null;
		
		//test - start
//		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
//		Date BFPReportDate = null;
//		try {
//			BFPReportDate = sdf.parse("02-28-2009");
//			
//		} catch (ParseException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
		// test - end
		System.out.println("Today is : "+ BFPReportDate);
		List sunSynergyList = getTotalSunSynergyList(BFPReportDate);
		List lobLifeList = groupPoliciesByLob(sunSynergyList, PSBatchConstants.LOB_LIFE);
		List lobPNList = groupPoliciesByLob(sunSynergyList, PSBatchConstants.LOB_PRENEED);
		
		System.out.println("lobLifeList : "+lobLifeList.size());
		System.out.println("lobPNList : "+lobPNList.size());
		
		List ILifeDtoList = new ArrayList();
		List PNeedDtoList = new ArrayList();
		
		if(lobLifeList!=null && lobLifeList.size()>0){
			ILifeDtoList = ((ILifePlanViewDTO) sunSynDao.getPolicyDetails(lobLifeList, PSBatchConstants.LOB_LIFE)).getObjectList();
		}
		if(lobPNList!=null && lobPNList.size()>0){
			PNeedDtoList = ((PNeedPlanViewDTO) sunSynDao.getPolicyDetails(lobPNList, PSBatchConstants.LOB_PRENEED)).getObjectList();
		}
		
		
		ILifePlanViewDTO ILifeDto = null;
		PNeedPlanViewDTO PNeedDto = null;
		
		int createdItemCnt = 0;
		int noOfFailed = 0;
		int noOfSuccess = 0;
		try {
			logWriter = new BufferedWriter(new FileWriter(logFile, true));
			logWriter.write("Status report for Sun Synergy List- "+BFPReportDate);
			logWriter.newLine();
			logWriter.newLine();
			logWriter.close();
			for(Iterator i=ILifeDtoList.iterator(); i.hasNext();){
				ILifeDto = (ILifePlanViewDTO)i.next();
				logWriter = new BufferedWriter(new FileWriter(logFile, true));
				try {
					logWriter.write("Processing... "+ ILifeDto.getPOL_ID()+" - "+PSBatchConstants.LOB_LIFE);
					createWorkItem(ILifeDto, PSBatchConstants.LOB_LIFE);
					sunSynDao.updateLastCreateWIDate(ILifeDto.getPOL_ID(), BFPReportDate);
					logWriter.write("  Success!");
					noOfSuccess++;
					
				} catch (Exception e) {
					logWriter.write("  Failed! - "+e.getMessage());
					noOfFailed++;
					e.printStackTrace();
				}
				createdItemCnt++ ;
				logWriter.newLine();
				logWriter.close();
			}
			
			for(Iterator i=PNeedDtoList.iterator(); i.hasNext();){
				PNeedDto = (PNeedPlanViewDTO)i.next();
				logWriter = new BufferedWriter(new FileWriter(logFile, true));
				try {
					logWriter.write("Processing... "+ PNeedDto.getPOL_ID()+" - "+PSBatchConstants.LOB_PRENEED);
					createWorkItem(PNeedDto, PSBatchConstants.LOB_PRENEED);
					sunSynDao.updateLastCreateWIDate(PNeedDto.getPOL_ID() ,BFPReportDate);
					logWriter.write("  Success!");
					
					noOfSuccess++;
				} catch (Exception e) {
					logWriter.write("  Failed! - "+e.getMessage());
					noOfFailed++;
					e.printStackTrace();
				}
				createdItemCnt++ ;
				logWriter.newLine();
				logWriter.close();
			}
			
			logWriter = new BufferedWriter(new FileWriter(logFile, true));
			logWriter.newLine();
			logWriter.write("Total number of Sun Synergy transactions run: "+createdItemCnt);
			logWriter.newLine();
			logWriter.write("No. of created workitems : "+noOfSuccess);
			logWriter.newLine();
			logWriter.write("No. of failed workitems : "+ noOfFailed);
			logWriter.newLine();
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done!");
		System.out.println(createdItemCnt+" Workitems created!");
	}
	
	private boolean createWorkItem(SunSynergyDTO dto, String lob) throws Exception{
		
		Folder parentFolder = (Folder)cedp.getFNObjectByPath(BaseObject.TYPE_FOLDER, "//"+wmsconstants.PS_F_POLICY_SERVICING);

		String transType = "";
		HashMap params = new HashMap();
		Date date = new Date();
		
		if(lob.equals(PSBatchConstants.LOB_LIFE)){
			transType = PSBatchConstants.TRANS_TYPE_LIFE;
			
		}else if(lob.equals(PSBatchConstants.LOB_PRENEED)){
			transType = PSBatchConstants.TRANS_TYPE_PRENEED;
			
		}
		
		Folder newFolder = createFolderHierarchy(dto, parentFolder, transType);
		VWAttachment att = pedp.convertCEObjToAttachment(newFolder);
		
		PSSunSynergyDao sunSynergyListDao = new PSSunSynergyDaoImpl();
		PSSunSynergyListDTO sunSynergyListDto = sunSynergyListDao.getPSSunSynergyListDTO("WHERE Policy_Plan_Num='"+dto.getPOL_ID()+"'");
		String mfClientNo = "";
		if(sunSynergyListDto.getObjectList().size()>0){
			mfClientNo = (String)((PSSunSynergyListDTO)sunSynergyListDto.getObjectList().get(0)).getMF_ACCOUNT_NUM();
		}
		if(mfClientNo!=null && !mfClientNo.trim().equals("")){
			params.put(wmsconstants.PS_CLIENT_NUMBER,mfClientNo);
		}
		
		params.put(wmsconstants.PS_AGENT_ID, dto.getAGENT_CODE());
		params.put(wmsconstants.PS_LINE_OF_BUSINESS, lob);
		params.put(wmsconstants.PS_INSURED_BIRTH_DATE, dto.getINSURED_BIRTHDATE());
		params.put(wmsconstants.PS_INSURED_CLIENT_NUMBER, dto.getINSURED_CLIENT_NO());
		params.put(wmsconstants.PS_INSURED_FIRST_NAME, dto.getINSURED_FIRST_NAME());
		params.put(wmsconstants.PS_INSURED_LAST_NAME, dto.getINSURED_LAST_NAME());
		params.put(wmsconstants.PS_INSURED_MIDDLE_NAME, dto.getINSURED_MIDDLE_NAME());
		params.put(wmsconstants.PS_CLIENT_BIRTH_DATE, dto.getOWNER_BIRTH_DT());
		params.put(wmsconstants.PS_CLIENT_NUMBER, dto.getOWNER_CLIENT_NO());
		params.put(wmsconstants.PS_CLIENT_FIRST_NAME, dto.getOWNER_FIRST_NAME() );
		params.put(wmsconstants.PS_CLIENT_LAST_NAME, dto.getOWNER_LAST_NAME() );
		params.put(wmsconstants.PS_CLIENT_MIDDLE_NAME, dto.getOWNER_MIDDLE_NAME() );
		params.put(wmsconstants.PS_TRANSACTION_TYPE, transType );
		params.put(wmsconstants.PS_POLICY_NUMBER, dto.getPOL_ID() );
		params.put(wmsconstants.PS_ScanDate, date );
		params.put(wmsconstants.PS_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE );
		params.put(wmsconstants.PS_Folder, att);
		
		params.put(wmsconstants.PS_CC_AbbrevName, wmsconstants.WORK_FLOW_SITE_PPA);
		params.put(wmsconstants.PS_CustomerCenterID, "PA" );
		

		pedp.createWorkItem(params, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME, null);
		
		return true;
	}

	private Folder createFolderHierarchy(SunSynergyDTO dto, Folder parentFolder, String transType) throws Exception{
		
		String lob = "";
		if(transType.equals(PSBatchConstants.TRANS_TYPE_LIFE)){
			lob=PSBatchConstants.LOB_LIFE;
		}else if(transType.equals(PSBatchConstants.TRANS_TYPE_PRENEED)){
			lob=PSBatchConstants.LOB_PRENEED;
		}
			
		
		Folder policyFolder = (Folder) cedp.getFNObjectByPath(BaseObject.TYPE_FOLDER, "//"+wmsconstants.PS_F_POLICY_SERVICING+"//"+dto.getPOL_ID() );
		Folder newFolder = null;
		HashMap propsHm = new HashMap();
		
		//PSFolder properties
		propsHm.put(wmsconstants.PS_F_FolderName, dto.getPOL_ID());
		propsHm.put(wmsconstants.PS_F_ClientFName, dto.getOWNER_FIRST_NAME());
		propsHm.put(wmsconstants.PS_F_ClientLName, dto.getOWNER_LAST_NAME());
		propsHm.put(wmsconstants.PS_F_ClientMName, dto.getOWNER_MIDDLE_NAME());
		propsHm.put(wmsconstants.PS_F_ClientNo, dto.getOWNER_CLIENT_NO());
		propsHm.put(wmsconstants.PS_F_InsClientNo, dto.getINSURED_CLIENT_NO());
		propsHm.put(wmsconstants.PS_F_InsFName, dto.getINSURED_FIRST_NAME());
		propsHm.put(wmsconstants.PS_F_InsLName, dto.getINSURED_LAST_NAME());
		propsHm.put(wmsconstants.PS_F_InsMName, dto.getAGENT_MIDDLE_NAME());
		propsHm.put(wmsconstants.PS_F_LOB, lob);
		propsHm.put(wmsconstants.PS_F_PolicyNo, dto.getPOL_ID());
		
		try{
			
			policyFolder.getName();
			System.out.println("Policy folder found!");
			
		}catch(BadReferenceException e ){
			System.out.println("Policy folder not found, creating...");
			
			//creating policy PS Folder 
			Properties props = cedp.createProperties(propsHm);
			//policyFolder = (Folder)cedp.createObject(props, wmsconstants.PS_Folder, BaseObject.TYPE_FOLDER, "//"+parentFolder.getName());
			policyFolder = parentFolder.addSubFolder(dto.getPOL_ID(), wmsconstants.PS_Folder, props, null);
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		
		//additional properties for PSTransactionFolder
		propsHm.put(wmsconstants.PS_F_AgentID, dto.getAGENT_CODE());
		propsHm.put(wmsconstants.PS_F_ScanDate,date );
		propsHm.put(wmsconstants.PS_F_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE);
		
		propsHm.put(wmsconstants.PS_F_PSTransType, transType);
		propsHm.put(wmsconstants.PS_F_MultipleTransaction, new Boolean("false"));
		propsHm.put(wmsconstants.PS_F_DocCapSiteID, "PA");
		propsHm.put(wmsconstants.PS_F_ProcessStatus, "Created");
		propsHm.put(wmsconstants.PS_F_DisbType, PSBatchConstants.PS_NDISB_CATEGORY);
		
		String folderName = dto.getPOL_ID()+"_"+transType+"_"+sdf.format(date);
		newFolder = policyFolder.addSubFolder(folderName, wmsconstants.PS_F_Tran_Folder, cedp.createProperties(propsHm), null);
		
		return newFolder;
	}
	
	
	/**
	 * 
	 * @param PSSunSynergyListDTOs
	 * @param lobType
	 * @return List of Strings of policy numbers
	 */
	public List groupPoliciesByLob(List PSSunSynergyListDTOs, String lobType){
		PSSunSynergyListDTO sunSynListDto = null;
		List lobList = new ArrayList();
		for(Iterator i=PSSunSynergyListDTOs.iterator(); i.hasNext();){
			sunSynListDto = (PSSunSynergyListDTO)i.next();
			
			if(sunSynListDto.getLOB().equalsIgnoreCase(lobType)){
				lobList.add(sunSynListDto.getPOLICY_PLAN_NUM());
			}
		}
		return lobList;
	}
	/**
	 * 
	 * @param BFPReportDate
	 * @return List of PSSunSynergyListDTO objects
	 */
	public List getTotalSunSynergyList(Date BFPReportDate){
		PSSunSynergyDao sunSynDao = new PSSunSynergyDaoImpl();
		List sunSynergyList = sunSynDao.getPSSunSynergyList(BFPReportDate, PSBatchConstants.PAYMENT_MODE_ANNUAL).getObjectList();
		sunSynergyList.addAll(sunSynDao.getPSSunSynergyList(BFPReportDate, PSBatchConstants.PAYMENT_MODE_SEMI_ANNUAL).getObjectList());
		sunSynergyList.addAll(sunSynDao.getPSSunSynergyList(BFPReportDate, PSBatchConstants.PAYMENT_MODE_QUARTERLY).getObjectList());
		
		Calendar cal  = new GregorianCalendar();
		
		//if today is monday, add to the list all items that should have run on sunday 
		if(cal.get(Calendar.DAY_OF_WEEK)==Calendar.MONDAY){
			cal.add(Calendar.DAY_OF_WEEK, -1);
			Date sunday = cal.getTime();
			
			sunSynergyList.addAll(sunSynDao.getPSSunSynergyList(sunday, PSBatchConstants.PAYMENT_MODE_ANNUAL).getObjectList());
			sunSynergyList.addAll(sunSynDao.getPSSunSynergyList(sunday, PSBatchConstants.PAYMENT_MODE_SEMI_ANNUAL).getObjectList());
			sunSynergyList.addAll(sunSynDao.getPSSunSynergyList(sunday, PSBatchConstants.PAYMENT_MODE_QUARTERLY).getObjectList());
		}
		
		return sunSynergyList;
	}
	
	public Date getBFPReportDate() throws SQLException{
		
		WmsParamDAO dao = new WmsParamDAOImpl();
		
		String wmsParamValue = null;
		String wmsParamFormat = null;
		
		List <WMSParam> wmsParamList = dao.getWmsParamList("BFPReportDate");
		for(WMSParam wmsParamDto : wmsParamList){
			wmsParamValue = wmsParamDto.getWMSP_Value();
			wmsParamFormat = wmsParamDto.getWMSP_Format();
		}
		SimpleDateFormat sdf = new SimpleDateFormat(wmsParamFormat);
		
		Date date = null;
		
		try {
			date = sdf.parse(wmsParamValue);
		} catch (ParseException e1) {
			CommonUtil.printLog("PSSunSynergyUtil", "getBFPReportDate", "ParseException: " + CommonUtil.exceptionStacktraceToString(e1));
		}
		
		return date;
	}
	
}
