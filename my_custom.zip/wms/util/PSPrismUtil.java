package ph.com.sunlife.wms.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.ResourceBundle;
import java.util.Set;





import com.filenet.wcm.api.BadReferenceException;
import com.filenet.wcm.api.BaseObject;
import com.filenet.wcm.api.Folder;
import com.sun.rowset.CachedRowSetImpl;

import filenet.vw.api.VWAttachment;
import filenet.vw.api.VWAttachmentType;
import filenet.vw.api.VWException;
import filenet.vw.api.VWLibraryType;

import ph.com.sunlife.wms.batch.CreateWorkitems;
import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.constants.wmsconstants;
import ph.com.sunlife.wms.dao.PrismCreateWorkItemDAO;
import ph.com.sunlife.wms.dp.CEDataProvider;
import ph.com.sunlife.wms.dp.PEUtilDP;
import ph.com.sunlife.wms.dto.PrismCreateWorkItemDTO;
import ph.com.sunlife.wms.impl.PrismCreateWorkItemDAOImpl;
import ph.com.sunlife.wms.util.db.WmsDbManager;

public class PSPrismUtil {
	
	private ResourceBundle createWIRB;
	private ResourceBundle componentRB;
	private CEDataProvider cedp;
	private PEUtilDP pedp;
	private String transType;
	
	private String appendDate;
	private Date scanDateForStepElem;
	private Date scanDateForFolder = new Date();
	
	private SimpleDateFormat appendDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	private SimpleDateFormat scanDateFolderFormat = new SimpleDateFormat("MM/dd/yy");
	
	public PSPrismUtil(){

		System.out.println("INITIALIZING...");
		try {
			this.createWIRB = CreateWorkitems.getCreateWIResourceBundle();
			this.componentRB = CreateWorkitems.getComponentPropertiesResourceBundle();
			this.transType = "POSTDISB-P";		
			this.appendDate = appendDateFormat.format(new Date());
			this.scanDateForStepElem = new Date();		
			this.scanDateForFolder = (Date)scanDateFolderFormat.parse((String)scanDateFolderFormat.format(new Date()));
			cedp = new CEDataProvider();
			cedp.init();
			pedp = new PEUtilDP();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void processItems() {
		System.out.println("START OF processItems...");
		StringBuffer query = new StringBuffer();
		String casServer = componentRB.getString("CAS_SERVER");
		query.append("select REF_NUM from openquery ("+casServer+", 'SELECT REF_NUM FROM  WMS_PREN_CHEQUE_VIEW') ");
		query.append("UNION select REF_NUM from openquery ("+casServer+", 'SELECT REF_NUM FROM WMS_PREN_DM_VIEW')");
		
//		for testing only - start
//		query.append("select * from WMS_PREN_CHEQUE_VIEW");
//		System.out.println("Query: "+query.toString());		
//		for testing only - end
		
		ResultSet rs = null;
		try{
			WmsDbManager db = new WmsDbManager();
			rs = (CachedRowSetImpl) db.doSelect(query.toString());
			System.out.println("Number of Plan Numbers to process: "+rs.getFetchSize());
			int cnt = 0;
			while(rs.next()){
				String planNumber = rs.getString("REF_NUM");
				System.out.println("CREATING WORK ITEM FOR PLAN_NUMBER: "+planNumber);
				PrismCreateWorkItemDTO dto = this.getDetailsFromPrism(planNumber);
				this.processPrismTrans(dto);
				cnt++;
			}
			System.out.println(cnt+" workitems created!");
		}catch(Exception e){
			e.getStackTrace();
		}finally{
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		System.out.println("END OF processItems...");
	}
	
	public void processPrismTrans(PrismCreateWorkItemDTO dto){
		System.out.println("START OF processPrismTrans");
		Iterator iter = dto.getObjectList().iterator();
		while(iter.hasNext()){
			PrismCreateWorkItemDTO prismDTO = (PrismCreateWorkItemDTO)iter.next();
			if(this.createWorkItem(prismDTO)){
				System.out.println("Work Item created for Plan Number: "+prismDTO.getPLAN_NUMBER());					
			} else {
				System.out.println("Failed to create work item fro Plan Number: "+prismDTO.getPLAN_NUMBER());
			}
		}
		System.out.println("END OF processPrismTrans");
	}
	 
	private boolean createWorkItem(PrismCreateWorkItemDTO dto) {
		System.out.println("START OF createWorkItem... PrismCreateWorkItemDTO: "+dto);
		HashMap stepElemParams = new HashMap();
		String planNumber = dto.getPLAN_NUMBER();
		System.out.println("PLAN NUMBER: "+planNumber);
		Folder psFolder = this.getPSFolder(planNumber);
		Folder psTransFolder = null;
		stepElemParams.putAll(this.getStepElemParams(dto));
		if(psFolder != null){
			HashMap hm = new HashMap(); 
			hm.putAll(this.getPsFolderParams(dto));
			hm.putAll(this.getPsTransFolderParams(dto));
			psTransFolder = this.createPSTransFolder(hm, psFolder);	
			System.out.println("PS TRANS FOLDER CREATED: "+psTransFolder.getName());
		} else {
			psTransFolder = this.createPSFolderAndPSTransFolder(dto);
			System.out.println("PS FOLDER CREATED: "+psTransFolder.getName());
		}
		try {
			stepElemParams.put(wmsconstants.PS_Folder, this.convertFolderToAttachment(psTransFolder));
		} catch (VWException e) {
			e.printStackTrace();
		}
		this.hmKeys(stepElemParams);
		if(pedp.createWorkItem(stepElemParams, PSBatchConstants.PS_CREATEWI_BATCH_WF_NAME, null)){
			System.out.println("END OF createWorkItem...");
			return true;
		}
		System.out.println("END OF createWorkItem...");
		return false;
	}
	
	private HashMap getStepElemParams(PrismCreateWorkItemDTO dto){
		HashMap stepElemParams = new HashMap();
		stepElemParams.put(wmsconstants.PS_CLIENT_FIRST_NAME, dto.getCLIENT_FIRST_NAME());
		stepElemParams.put(wmsconstants.PS_CLIENT_LAST_NAME, dto.getCLIENT_LAST_NAME());
		stepElemParams.put(wmsconstants.PS_CLIENT_MIDDLE_NAME,dto.getCLIENT_MIDDLE_NAME());
		stepElemParams.put(wmsconstants.PS_CLIENT_NUMBER, dto.getCLIENT_NUMBER());
		stepElemParams.put(wmsconstants.PS_LOB, PSBatchConstants.LOB_PRENEED);
		stepElemParams.put(wmsconstants.PS_PolicyNo, dto.getPLAN_NUMBER());
		stepElemParams.put(wmsconstants.PS_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE);
		stepElemParams.put(wmsconstants.PS_TRANSACTION_TYPE,this.transType);
		stepElemParams.put(wmsconstants.PS_ScanDate,this.scanDateForStepElem);
		stepElemParams.put(wmsconstants.PS_MultipleTransaction, new Boolean(false));
		stepElemParams.put(wmsconstants.PS_AGENT_ID, dto.getAGE_INF_CODE());
		stepElemParams.put(wmsconstants.PS_CC_AbbrevName, "Policy Plan Accounting");
		stepElemParams.put(wmsconstants.PS_CustomerCenterID, "PA" );
		return stepElemParams;
	}
	
	private HashMap getPsFolderParams(PrismCreateWorkItemDTO dto){
		HashMap psFolderParams = new HashMap();
		psFolderParams.put(wmsconstants.PS_F_PolicyNo, dto.getPLAN_NUMBER());
		psFolderParams.put(wmsconstants.PS_F_ClientFName ,dto.getCLIENT_FIRST_NAME());
		psFolderParams.put(wmsconstants.PS_F_ClientLName ,dto.getCLIENT_LAST_NAME());
		psFolderParams.put(wmsconstants.PS_F_ClientMName,dto.getCLIENT_MIDDLE_NAME());
		psFolderParams.put(wmsconstants.PS_F_ClientNo,dto.getCLIENT_NUMBER());
		psFolderParams.put(wmsconstants.PS_F_LOB,wmsconstants.PS_LOB_PRENEED_IND_ID);
		return psFolderParams;
	}
	
	private HashMap getPsTransFolderParams(PrismCreateWorkItemDTO dto){
		HashMap psTransFolderParams = new HashMap();
		psTransFolderParams.put(wmsconstants.PS_F_LOB, PSBatchConstants.LOB_PRENEED);
		psTransFolderParams.put(wmsconstants.PS_F_ScanDate, this.scanDateForFolder);
		psTransFolderParams.put(wmsconstants.PS_F_ScannedBy, PSBatchConstants.PS_F_BATCH_SCANNEDBY_VALUE);
		psTransFolderParams.put(wmsconstants.PS_F_PSTransType, this.transType);
		psTransFolderParams.put(wmsconstants.PS_F_AgentID, dto.getAGE_INF_CODE());
		psTransFolderParams.put(wmsconstants.PS_F_MultipleTransaction, new Boolean("false"));
		psTransFolderParams.put(wmsconstants.PS_F_DisbCategory, "NDISB");
		psTransFolderParams.put(wmsconstants.PS_F_DocCapSiteID, "PA");
		psTransFolderParams.put(wmsconstants.PS_F_ProcessStatus, "Created");
		
		return psTransFolderParams;
	}

	private PrismCreateWorkItemDTO getDetailsFromPrism(String planNumber) {
		System.out.println("START OF getDetailsFromPrism");
		PrismCreateWorkItemDAO dao = new PrismCreateWorkItemDAOImpl();
		PrismCreateWorkItemDTO dto = dao.getPrismIndividualPlanDTO(planNumber);			
		System.out.println("END OF getDetailsFromPrism");
		return dto;
	}
	
	private Folder createPSTransFolder(HashMap hm, Folder policyFolder) {
		System.out.println("START OF createPSTransFolder... hm size: "+hm.size());
		System.out.println("SCAN DATE FOR FOLDER: "+hm.get(wmsconstants.PS_F_ScanDate));
		String planNumber = (String) hm.get(wmsconstants.PS_F_PolicyNo);
		System.out.println("PLAN NUMBER: "+planNumber);
		StringBuffer psTransFolderName = new StringBuffer();		
		psTransFolderName.append(planNumber);
		psTransFolderName.append("_");
		psTransFolderName.append(transType);
		psTransFolderName.append("_");
		psTransFolderName.append(this.appendDate);
		Folder psTransFolder = null;
		try{
			psTransFolder = policyFolder.addSubFolder(psTransFolderName.toString(), wmsconstants.PS_F_Tran_Folder, cedp.createProperties(hm), null);
		}catch(Exception e){
			e.printStackTrace();
		}
		return psTransFolder;
	}

	private Folder createPSFolderAndPSTransFolder(PrismCreateWorkItemDTO dto) {
		System.out.println("Start of createPSFolderAndPSTransFolder");
		HashMap psFolderParams = this.getPsFolderParams(dto);
		System.out.println("PS FOLDER PARAMS: "+psFolderParams.size());
		this.hmKeys(psFolderParams);
		Folder psTransFolder = null;
		try {			
			Folder folder = (Folder)cedp.getFNObjectByPath(BaseObject.TYPE_FOLDER,"//"+wmsconstants.PS_F_POLICY_SERVICING);			
			System.out.println("Adding PSFolder with Plan Number: "+psFolderParams.get(wmsconstants.PS_F_PolicyNo));
			Folder policyFolder = folder.addSubFolder((String)psFolderParams.get(wmsconstants.PS_F_PolicyNo), wmsconstants.PS_Folder, cedp.createProperties(psFolderParams), null);
			psFolderParams.putAll(this.getPsTransFolderParams(dto));
			psTransFolder = this.createPSTransFolder(psFolderParams, policyFolder);			
		} catch (Exception e) {
			e.printStackTrace();			
		}		
		return psTransFolder;
	}

	public Folder getPSFolder(String planNumber){
		System.out.println("START OF getPSFolder");
		Folder policyFolder = null;
		try{
			policyFolder = (Folder)cedp.getFNObjectByPath(BaseObject.TYPE_FOLDER, "//"+wmsconstants.PS_F_POLICY_SERVICING+"//"+planNumber);
			System.out.println("Policy Folder: "+policyFolder);
			policyFolder.getName();
			System.out.println(planNumber+" PSFolder exists!");
			return policyFolder;
		}catch(BadReferenceException e){
			System.out.println(planNumber+" PSFolder doesn't exist, creating ...");
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}			
	}
	
	protected VWAttachment convertFolderToAttachment(Folder folder) throws VWException{
		VWAttachment att = new VWAttachment();
		att.setLibraryType(VWLibraryType.LIBRARY_TYPE_CONTENT_ENGINE);
		System.out.println("COMPONENTRB: "+componentRB);
		att.setLibraryName(componentRB.getString("OBJECT_STORE_NAME"));
		att.setType(VWAttachmentType.ATTACHMENT_TYPE_FOLDER);
		System.out.println("FOLDER NAME: "+folder.getName());
		att.setAttachmentName(folder.getName());
		att.setId(folder.getId());		
		return att;
	}
	
	public static void main(String[] args){
		new CreateWorkitems();
		PSPrismUtil ps = new PSPrismUtil();
		ps.processItems();
		
	}
	
	private void hmKeys(HashMap hm){
		Set keys = hm.keySet();
		Iterator iter = keys.iterator();
		while(iter.hasNext()){
			String key = (String)iter.next();
			System.out.println("KEY: "+key+" VALUE: "+hm.get(key));
		}
	}
}	
