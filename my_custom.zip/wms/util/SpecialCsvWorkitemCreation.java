package ph.com.sunlife.wms.util;

import java.io.IOException;

import ph.com.sunlife.wms.batch.CsvWorkitemCreation;
import ph.com.sunlife.wms.constants.PSBatchConstants;

public class SpecialCsvWorkitemCreation extends CsvWorkitemCreation {
	
	public SpecialCsvWorkitemCreation(String companyCode) {
		super(companyCode, PSBatchConstants.SPECIAL_CSV_FILE_PATH);
	}
	
	public void processSpecialCsv() throws IOException {
		CommonUtil.printLog("##### Start SpecialCsvWorkitemCreation.processSpecialCsv #####");
		isCheckCreationDateFromFile = true;
		isCheckPolicyCWIHistory = true;
		getHolidayWeekendList();
		processItems();
		CommonUtil.printLog("##### End SpecialCsvWorkitemCreation.processSpecialCsv #####");
	}
}