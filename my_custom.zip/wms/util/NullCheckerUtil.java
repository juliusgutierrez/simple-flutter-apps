package ph.com.sunlife.wms.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * This class contains all the utilities for checking different kinds of objects.
 * 
 * @author IF16 - Cristopher Mendoza
 * @since August 3, 2016
 */
public class NullCheckerUtil {
	
	public static boolean isNotEmpty(String param){
		return (param != null && !param.trim().equalsIgnoreCase(""));
	}
	
	public static boolean isNullOrEmpty(String aString){
		return aString==null || aString.trim().isEmpty();
	}
	
	public static boolean isNullOrEmpty( final Collection< ? > c ) {
	    return c == null || c.isEmpty();
	}

	public static boolean isNullOrEmpty( final Map< ?, ? > m ) {
	    return m == null || m.isEmpty();
	}
	
	public static boolean isNullOrEmpty( final HashMap< ?, ? > hm ) {
	    return hm == null || hm.isEmpty();
	}
}