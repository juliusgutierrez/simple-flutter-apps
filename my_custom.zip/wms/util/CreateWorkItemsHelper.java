package ph.com.sunlife.wms.util;

import org.apache.commons.dbutils.DbUtils;
import java.io.File;
import java.io.FilenameFilter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.MutablePair;
import org.apache.commons.lang3.tuple.Pair;

import ph.com.sunlife.wms.constants.PSBatchConstants;
import ph.com.sunlife.wms.dto.PSReportColumnMapDTO;
import ph.com.sunlife.wms.util.db.WmsDbManager;

//_____________________________BatchCreateWorkitems.properties______________________________
//__________________________________________SLOCPI_____________________________________________________
//## Directory/File Paths - Start ##
//reports.folder.path=\\\\SV5181\\data1\\data\\WFMSINT\\ING_Reports_Input
//log.folder.path=\\\\SV5181\\data1\\data\\AT\\FILEARCH\\WFMS\\PH
//status.folder.path=\\\\SV5181\\data1\\data\\WFMSINT\\ING_Reports_Input\\unprocessed
//processed.folder.path=\\\\SV5181\\data1\\data\\WFMSINT\\ING_Reports_Input\\processed
//reports.folder.path.backup=\\\\SV5181\\data1\\data\\WFMSINT\\INGENIUM_REPORT_BACKUP
//## Directory/File Paths - End ##



//_____________________________BatchCreateWorkitems.properties______________________________
//__________________________________________SLGFI_____________________________________________________

//## Directory/File Paths - Start ##
//reports.folder.path=\\\\SV5181\\DATA1\\data\\WFMSINT\\SLGFI\\ING_Reports_Input
//log.folder.path=\\\\SV5181\\data1\\data\\AT\\FILEARCH\\WFMS\\PH
//status.folder.path=\\\\SV5181\\data1\\data\\WFMSINT\\ING_Reports_Input\\unprocessed
//processed.folder.path=\\\\SV5181\\data1\\data\\WFMSINT\\ING_Reports_Input\\processed
//reports.folder.path.backup=\\\\SV5181\\data1\\data\\WFMSINT\\INGENIUM_REPORT_BACKUP
//## Directory/File Paths - End ##


//_____________________________BatchCreateWorkitems.properties______________________________
//## O/S Disbursement -- Start ##
//ppa.reports=OD-CL-PPA;BER;PD-UCT;PD-UER;SS534;APP-EX;APP-OV;APP-MS;SA-POP
//ppc.reports=OD-CL-PPC;
//reinstatement.txn.type=CR;SRO-LIFE;
//os.disb.clring.txn.type=OD-CL-PPC;
//completion.statuses=Deny;Cancel;Complete;Approve;Approved;Approved for Finance;Cancelled;Approved Awaiting Requirements
//## O/S Disbursement -- End ##

//## Sun Synergy Batch -- start ##
//cif.link.server=UDCLIF01
//## Sun Synergy Batch -- end ##

/**
 *
 * @author i694
 * Added by: OLUND
 */
public class CreateWorkItemsHelper {

	private static final String SELECT_FROM_PS_REPORT_TXN_MAP_SLOCPI = "SELECT REPORT_ID, PSTXNTYPE_TRANS_ID FROM Ps_Report_Txn_Map where Active = 1";
	private static final String SELECT_FROM_PS_REPORT_TXN_MAP_SLGFI = "SELECT REPORT_ID, PSTXNTYPE_TRANS_ID FROM Ps_Report_Txn_Map where SLGFI_Active = 1";
	private static final String SELECT_FROM_PS_REPORT_TXN_MAP_CHECK_STATUS = "SELECT REPORT_ID, PSTXNTYPE_TRANS_ID FROM Ps_Report_Txn_Map where CHECK_STATUS = 0";
	private static final String SELECT_FROM_PS_REPORT_TXN_MAP_REPORT_IDS = "SELECT REPORT_ID, PSTXNTYPE_TRANS_ID FROM Ps_Report_Txn_Map where Active = 1 and report_id in ((?))";
	private static final String SELECT_FROM_PS_REPORT_TXN_MAP_TRANS_TYPES = "SELECT PSTXNTYPE_TRANS_ID FROM Ps_Report_Txn_Map where report_id = '(?)'";
	private static final String SELECT_FROM_PS_REPORT_COLUMN_MAP = "SELECT DISTINCT REPORT_ID, COLUMN_NAME, OFFSET, LENGTH from Ps_Report_Column_Map order by REPORT_ID desc";
	private static final String SELECT_FROM_PS_REPORT_COLUMN_MAP_REPORT_IDS = "SELECT DISTINCT REPORT_ID, COLUMN_NAME, OFFSET, LENGTH from Ps_Report_Column_Map where report_id in ((?)) order by REPORT_ID desc";
	private static final String COLUMN_NAME_KEY = "COLUMN_NAME";
	private static final String OFFSET_KEY = "OFFSET";
	private static final String LENGTH_KEY = "LENGTH";
	private static final String REPORT_ID_KEY = "REPORT_ID";
	private static final String PSTXNTYPE_TRANS_ID_KEY = "PSTXNTYPE_TRANS_ID";

	private void createDirectoryIfNeeded(String directoryName) {
		System.out.println("##### Inside CreateWorkItemsHelper.createDirectoryIfNeeded #####");
		File theDir = new File(directoryName);

		// if the directory does not exist, create it
		if (!theDir.exists())
		{
			System.out.println("creating directory: " + directoryName);
			theDir.mkdir();
		}
		else
		{
			System.out.println("Directory existed!" + directoryName);
		}
		System.out.println("##### Leaving CreateWorkItemsHelper.createDirectoryIfNeeded #####");
	}


	/**
	 * @author i694
	//  Method to move flat files from
	//  reports.folder.path=\\\\SV5182\\data1\\data\\WFMSINT\\ING_Reports_Input 
	//  and reports.folder.path=\\\\SV5182\\DATA1\\data\\WFMSINT\\SLGFI\\ING_Reports_Input 
	//  to \\\\SV5182\\data1\\data\\WFMSINT\\INGENIUM_REPORT_BACKUP
	 **/	
//	public void willTransferNotValidFileToBackUpFolder() {
//		System.out.println("##### Inside CreateWorkItemsHelper.willTransferNotValidFileToBackUpFolder #####");
//		try {
//			//1. Get the report ids in Ps_Report_Txn_Map table
//			Map<String,String> listOfReportId = getPSReportTxnMap();
//			//2. Get the bundles for directory
//			ResourceBundle batchCreateWorkitemsProperties = ResourceBundle.getBundle("com.ph.sunlife.component.properties.BatchCreateWorkitems");
//			//3.Set the path for processing
//			File reportsFolderPath = new File(batchCreateWorkitemsProperties.getString("reports.folder.path"));
//			System.out.println("Clean this directory : " + reportsFolderPath.toString());
//
//
//			//4.get the back up path value in WMSparam table for PSBatchCreateWorkitems
//			File backUpDirectory = new File(getReportsFolderBackUpPath());
//			//4.1 create Directory if needed
//			createDirectoryIfNeeded(backUpDirectory.toString());
//
//			if (!"".equals(String.valueOf(backUpDirectory)) && backUpDirectory.toString().length() > 1){//This is to assure that the path was successfully retrieved from the database
//				backUpDirectory = new File(backUpDirectory.toString());
//				StringBuilder out = new StringBuilder();
//				out.append("\n get the back up path value in WMSparam table for PSBatchCreateWorkitems");
//				out.append("\n Backup directory: " + backUpDirectory.toString());
//				out.append("\n");
//				System.out.println(out.toString());
//			}
//			//Get into configuration file
//			else
//			{
//				backUpDirectory = new File(batchCreateWorkitemsProperties.getString("reports.folder.path.backup"));//\\\\SV5181\\data1\\data\\WFMSINT\\INGENIUM_REPORT_BACKUP
//				StringBuilder out = new StringBuilder();
//				out.append("\n get the back up path value in resource bundle for PSBatchCreateWorkitems");
//				out.append("\n Clean up " + backUpDirectory.toString());
//				out.append("\n");
//				System.out.println(out.toString());
//			}
//			String[] files = reportsFolderPath.list(); //get the list of files
//			if (files.length > 0) {//make sure that there is a file in the directory
//				for (int i = 0; i < files.length; i++) {
//					File file = new File(reportsFolderPath.getPath()+"\\"+files[i]);
//					//Process only if normal file
//					if (file.isFile()){
//						//Check if valid for work item creation
//						if (files[i].contains("_")) {//"_" is standard in ingenium report (file name)
//							try {
//								String reportId = files[i].substring(0, files[i].indexOf("_"));//get only the report ID from the file name
//								//System.out.println("Get the transaction type of each reportid : " + listOfReportId.get(reportId));
//								//Report id should be check first before transferring to back up folder
//								//Only those that are not found in list of valid report id will be transfered in the back up folder
//								if (!listOfReportId.containsKey(reportId)){
//									//Start transferring the not valid file for work item creation
//									file.renameTo(new File(backUpDirectory, file.getName()));
//									System.out.println(file.getName() + " have been moved to " + backUpDirectory);
//								}
//							}catch (Exception e) {
//								System.out.println(e.toString());
//								System.out.println("Skipping exception caught while getting report Id in file name.");
//							}
//						}
//					}
//				}
//			}
//			else
//			{
//				System.out.println("No available files in " + reportsFolderPath.toString());
//			}
//		}catch(Exception e){
//			System.out.println("Exception caught while moving files to backup folder.");
//			e.printStackTrace(System.out);
//		}
//		System.out.println("##### Leaving CreateWorkItemsHelper.willTransferNotValidFileToBackUpFolder #####");
//	}

	// inner class, generic extension filter
	// for future reference, if you want to filter list of files by extension name
	private class GenericExtFilter implements FilenameFilter {
		private String ext;

		public GenericExtFilter(String ext) {
			this.ext = ext;
		}

		public boolean accept(File dir, String name) {
			return (name.endsWith(ext));
		}
	}

	/**
	 * @author i694
	 *Helper method that will retrieve the report ids in Ps_Report_Txn_Map table only once and put it in a map collection. 
	 *Once the records were successfully retrieved, the program will now validate every id of the report not 
	 *in the database but in the collection.
	 *@return rows
	 */
	public Map<String,String> getPSReportTxnMap(String companyCode){
		System.out.println("##### Inside CreateWorkItemsHelper.getPSReportTxnMap #####");
		Map<String,String> rows = null;
		Connection connection = null;
		PreparedStatement prepareStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();

			if(PSBatchConstants.PS_COMPANY_SLOCPI.equalsIgnoreCase(companyCode)){
				prepareStatement =  connection.prepareStatement(SELECT_FROM_PS_REPORT_TXN_MAP_SLOCPI);
			} else if(PSBatchConstants.PS_COMPANY_SLGFI.equalsIgnoreCase(companyCode)){
				prepareStatement =  connection.prepareStatement(SELECT_FROM_PS_REPORT_TXN_MAP_SLGFI);
			}

			rs = prepareStatement.executeQuery();
			if (rs != null) {
				rows = new HashMap<String,String>();//initialize only there is a result
				while(rs.next()){
					String reportId = rs.getString("REPORT_ID");
					String psTransactionTypeId = rs.getString("PSTXNTYPE_TRANS_ID");
					rows.put(reportId,psTransactionTypeId);
				}	
			}
		}catch(Exception e) {
			e.printStackTrace(System.out);
			System.out.println("Exception caught while getting REPORT_ID in Ps_Report_Txn_Map table.");
		}
		finally{
			if (rs != null) {try {rs.close();} catch (SQLException e) { /* ignored */}}
			if (connection != null) {try {prepareStatement.close();} catch (SQLException e) { /* ignored */}}
			if (connection != null) {try {connection.close();} catch (SQLException e) { /* ignored */}}
		}
		System.out.println("##### Leaving CreateWorkItemsHelper.getPSReportTxnMap #####");
		return rows;
	}

	public List<String> getReportsForStatusChecking(){
		System.out.println("##### Inside CreateWorkItemsHelper.getReportsForStatusChecking #####");
		List<String> rows = null;
		Connection connection = null;
		PreparedStatement prepareStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();

			prepareStatement =  connection.prepareStatement(SELECT_FROM_PS_REPORT_TXN_MAP_CHECK_STATUS);


			rs = prepareStatement.executeQuery();
			if (rs != null) {
				rows = new ArrayList<String>();//initialize only there is a result
				while(rs.next()){
					String reportId = rs.getString("REPORT_ID");
					String psTransactionTypeId = rs.getString("PSTXNTYPE_TRANS_ID");
					rows.add(reportId);
				}
			}
		}catch(Exception e) {
			e.printStackTrace(System.out);
			System.out.println("Exception caught while getting REPORT_ID in Ps_Report_Txn_Map table.");
		}
		finally{
			DbUtils.closeQuietly(connection, prepareStatement, rs);
		}
		System.out.println("##### Leaving CreateWorkItemsHelper.getReportsForStatusChecking #####");
		return rows;
	}

	public Map<String,String> getPSReportTxnMapReportIds(String repordIds){
		CommonUtil.printLog("##### Start CreateWorkItemsHelper.getPSReportTxnMapReportIds #####");
		Map<String,String> rows = null;
		Connection connection = null;
		PreparedStatement preparedStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();

			String query = SELECT_FROM_PS_REPORT_TXN_MAP_REPORT_IDS.replace("(?)", repordIds);
			CommonUtil.printLog("CreateWorkItemsHelper", "getPSReportTxnMapReportIds", "SQL to get the PS_REPORT_TXN_MAP: " + query);

			preparedStatement =  connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			if (rs != null) {
				rows = new HashMap<String,String>();
				while(rs.next()){
					String reportId = rs.getString(REPORT_ID_KEY);
					String psTransactionTypeId = rs.getString(PSTXNTYPE_TRANS_ID_KEY);
					if( StringUtils.isNotBlank(reportId) && StringUtils.isNotBlank(psTransactionTypeId) ) {
						rows.put(reportId,psTransactionTypeId);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally{
			DbUtils.closeQuietly(connection, preparedStatement, rs);
		}
		CommonUtil.printLog("##### End CreateWorkItemsHelper.getPSReportTxnMapReportIds #####");
		return rows;
	}

	public List<String> getPSReportTxnMapTransTypes(String repordIds){
		CommonUtil.printLog("##### Start CreateWorkItemsHelper.getPSReportTxnMapTransTypes #####");
		Connection connection = null;
		PreparedStatement preparedStatement =  null;
		List<String> transTypes = null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();

			String query = SELECT_FROM_PS_REPORT_TXN_MAP_TRANS_TYPES.replace("(?)", repordIds);
			CommonUtil.printLog("CreateWorkItemsHelper", "getPSReportTxnMapTransTypes", "SQL to get the PS_REPORT_TXN_MAP: " + query);

			preparedStatement =  connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			if (rs != null) {
				transTypes = new ArrayList<String>();
				while(rs.next()){
					transTypes.add(rs.getString(PSTXNTYPE_TRANS_ID_KEY));
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally{
			DbUtils.closeQuietly(connection, preparedStatement, rs);
		}
		CommonUtil.printLog("##### End CreateWorkItemsHelper.getPSReportTxnMapReportIds #####");
		return transTypes;
	}

	public Map<String,String> getlistOfPSReportColumnMapby(){
		System.out.println("##### Inside CreateWorkItemsHelper.getlistOfPSReportColumnMapby #####");
		Map<String,String> rows = null;
		Connection connection = null; 
		PreparedStatement preparedStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();
			preparedStatement =  connection.prepareStatement(SELECT_FROM_PS_REPORT_COLUMN_MAP);
			rs = preparedStatement.executeQuery();
			if (rs != null) {
				rows = new HashMap<String,String>();//initialize only there is a result
				while(rs.next()){
					String REPORT_ID = rs.getString("REPORT_ID");
					String COLUMN_NAME = rs.getString("COLUMN_NAME");
					String OFFSET = rs.getString("OFFSET");
					String LENGTH = rs.getString("LENGTH");
					String mapKey = String.valueOf(REPORT_ID+COLUMN_NAME).toUpperCase();
					String mapValue = OFFSET+"-"+LENGTH;
					rows.put(mapKey,mapValue);
				}
			}
		}catch(Exception e) {
			System.out.println("Exception caught while getting REPORT_ID in Ps_Report_Txn_Map table.");
			e.printStackTrace(System.out);
		}
		finally{
			if (rs != null) {try {rs.close();} catch (SQLException e) { /* ignored */}}
			if (connection != null) {try {preparedStatement.close();} catch (SQLException e) { /* ignored */}}
			if (connection != null) {try {connection.close();} catch (SQLException e) { /* ignored */}}
		}
		System.out.println("##### Leaving CreateWorkItemsHelper.getlistOfPSReportColumnMapby #####");
		return rows;
	}

	public Map<String, Map<String, Pair<Integer, Integer>>> getMapPSReportColumnMapByReportIds(String reportIds) {
		CommonUtil.printLog("##### Start CreateWorkItemsHelper.getMapPSReportColumnMapByReportIds #####");
		Map<String, Map<String, Pair<Integer, Integer>>> map = null;
		Connection connection = null;
		PreparedStatement preparedStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		try {
			connection = wmsDbManager.getConnection();

			String query = SELECT_FROM_PS_REPORT_COLUMN_MAP_REPORT_IDS.replace("(?)", reportIds);
			CommonUtil.printLog("CreateWorkItemsHelper", "getListPSReportColumnMapByReportIds", "SQL to get the PS_REPORT_COLUMN_MAP: " + query);
			preparedStatement =  connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
			if (rs != null) {

				map = new HashMap<String, Map<String, Pair<Integer, Integer>>>();

				while(rs.next()){

					Map<String, Pair<Integer, Integer>> mapPair = new HashMap<String, Pair<Integer, Integer>>();
					String columnName = rs.getString(COLUMN_NAME_KEY);

					Pair<Integer, Integer> pair = new MutablePair<Integer, Integer>(rs.getInt(OFFSET_KEY), rs.getInt(LENGTH_KEY));

					mapPair.put(columnName, pair);
					String reportId = rs.getString(REPORT_ID_KEY);

					if(!map.isEmpty() && map.get(reportId) != null) {
						map.get(reportId).put(columnName, pair);
					}else {
						map.put(reportId, mapPair);
					}
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally{
			DbUtils.closeQuietly(connection, preparedStatement, rs);
		}
		CommonUtil.printLog("##### End CreateWorkItemsHelper.getMapPSReportColumnMapByReportIds #####");
		return map;
	}

	/**
	 * @author i694
	 * Method to check if the path is available in WMSParam
	 * @return String
	 */
	private String getReportsFolderBackUpPath() {
		System.out.println("##### Inside CreateWorkItemsHelper.getReportsFolderBackUpPath #####");
		Connection connection = null; 
		PreparedStatement prepareStatement =  null;
		ResultSet rs = null;
		WmsDbManager wmsDbManager = new WmsDbManager();
		String sql = "select WMSP_Value from WMSParam where WMSP_ParamField = 'reports.folder.path.backup'";
		String path = "";
		try {
			connection = wmsDbManager.getConnection();
			prepareStatement =  connection.prepareStatement(sql);
			rs = prepareStatement.executeQuery();
			if (rs != null) {
				while(rs.next()){
					path = rs.getString("WMSP_Value");
				}	
			}
		}catch(Exception e) {
			e.printStackTrace(System.out);
			System.out.println("Exception caught while getting Reports Folder BackUp Path.");
			return path = "";
		}
		finally {
			if (rs != null) {try {rs.close();} catch (SQLException e) { /* ignored */}}
			if (prepareStatement != null) {try {prepareStatement.close();} catch (SQLException e) { /* ignored */}}
			if (connection != null) {try {connection.close();} catch (SQLException e) { /* ignored */}}
		}
		System.out.println("##### Leaving CreateWorkItemsHelper.getReportsFolderBackUpPath #####");
		return path;
	}


//	public static void main(String[] args) {
//		//System.setProperty("-Djavax.net.ssl.trustStore","SunLifeSigners.jks");
//		//System.setProperty("java.security.auth.login.config", "jaas.conf.WSI");
//
//		CreateWorkItemsHelper createWorkItemsHelper = new CreateWorkItemsHelper();
//		createWorkItemsHelper.willTransferNotValidFileToBackUpFolder();
//		Map<String,String> listOfPSReportColumnMap = createWorkItemsHelper.getlistOfPSReportColumnMapby();
//
//		//loop a Map
//		for (Map.Entry<String, String> entry : listOfPSReportColumnMap.entrySet()) {
//			System.out.println("Key : " + entry.getKey() + " ============== Value : " + entry.getValue());
//		}
//
//		String data = listOfPSReportColumnMap.get("CSBM9441Source System");
//		String[] oofsetAndLength = data.split("-");
//
//		int offset = Integer.valueOf(oofsetAndLength[0])-1;
//		int length = Integer.valueOf(oofsetAndLength[1]);
//
//		System.out.println("OFFSET = " + offset);
//		System.out.println("LENGTH = " + length);
//
//	}

}
