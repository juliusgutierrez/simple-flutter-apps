package ph.com.sunlife.wms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;


public class DateUtil {

	public static final String REPORT_DATE_FORMAT = "yyyyMMdd";
	public static final String YEAR_YYYY_FORMAT = "yyyy";
	public static final String CURRENT_DATE_FORMAT = "yyyy-MM-dd";
	public static final String WICREATE_DATE_FORMAT =  "dd-MMM-yyyy";
	private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat(CURRENT_DATE_FORMAT);
	private static SimpleDateFormat reportDateFormat = new SimpleDateFormat(REPORT_DATE_FORMAT);
	public static Calendar cal = Calendar.getInstance();
	public static String bfpReportDate = WmsParamUtil.getBFPReportDate();

	public static String formatDate(Date date){
		simpleDateFormat.applyPattern("yy-MM-dd");
		return simpleDateFormat.format(date);
	}

	public static Date parseDate(String date) throws ParseException{
		return simpleDateFormat.parse(date);
	}

	public static String getTodayDateFormatYYYYMMDD(){
		return simpleDateFormat.format(bfpReportDate);
	}

	public static String getReportDateFormatYYYYMMDD(){
		Date reportDate = null;
		try {
			reportDate = simpleDateFormat.parse(bfpReportDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return reportDateFormat.format(reportDate);
	}

	public static boolean isWeekend(Date reportDate){
		if (reportDate == null){ // to avoid null pointer exception
			return false;
		}
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		gregorianCalendar.setTime(reportDate);
		return isSaturday(gregorianCalendar) || isSunday(gregorianCalendar);
	}

	private static boolean isSaturday(GregorianCalendar gregorianCalendar){
		return gregorianCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY;
	}

	private static boolean isSunday(GregorianCalendar gregorianCalendar){
		return gregorianCalendar.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY;
	}

	public static Date getParsedToDate(String format, String date) {
		simpleDateFormat.applyPattern(format);
		try {
			return simpleDateFormat.parse(date);
		} catch (ParseException e) {
			CommonUtil.printLog("Error parsing String ["+date+"] to Date object.");
			e.printStackTrace();
		}

		return null;
	}

	public static String getCurrentYear() {
		simpleDateFormat.applyPattern(YEAR_YYYY_FORMAT);
		return simpleDateFormat.format(new Date());
	}

	public static String getDateToBFPReportDateFormat(String date) {

		try {
			simpleDateFormat.applyPattern(WICREATE_DATE_FORMAT);
			Date d = simpleDateFormat.parse(date);

			simpleDateFormat.applyPattern(CURRENT_DATE_FORMAT);
			return simpleDateFormat.format(d);
		}catch(ParseException pe) {
			CommonUtil.printLog("Encountered parsing error of date: ["+date+"] with error message ["+pe.getMessage()+"]");
		}catch(Exception e) {
			CommonUtil.printLog("Encountered Exception error of date: ["+date+"] with error message ["+e.getMessage()+"]");
			e.printStackTrace();
		}

		return StringUtils.EMPTY;
	}
}