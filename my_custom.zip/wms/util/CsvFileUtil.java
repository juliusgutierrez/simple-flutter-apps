package ph.com.sunlife.wms.util;

import org.apache.commons.lang.StringUtils;
import ph.com.sunlife.wms.constants.PSBatchConstants;

/**
 * 
 * @author p344
 * This class is a sub class of FileUtil
 */
public final class CsvFileUtil extends FileUtil {
	
	private CsvFileUtil(){
		
	}	
	
	public static boolean isValidCsvFile(String fileName) {

		if(fileName == null)
			return false;

		return fileName.toUpperCase().endsWith(PSBatchConstants.CSV_FILE_EXTENSION);
	}

	public static String removeCsvExtension(String csv) {
		return csv.replace(PSBatchConstants.CSV_FILE_EXTENSION, StringUtils.EMPTY);
	}
}